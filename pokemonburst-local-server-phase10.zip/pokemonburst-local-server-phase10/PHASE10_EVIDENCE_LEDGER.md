# Phase 10 Evidence Ledger

| ID | Claim | Evidence | Status |
|---|---|---|---|
| P10-E001 | Real client sends 2001 | User-provided raw WS trace | PROVEN |
| P10-E002 | Real client sends 2005 immediately after 2001 | User-provided raw WS trace | PROVEN |
| P10-E003 | Real client sends 2020 immediately after 2005 | User-provided raw WS trace | PROVEN |
| P10-E004 | Old Phase 10 leaves 2005 unhandled | User-provided server log | PROVEN |
| P10-E005 | Old Phase 10 leaves 2020 unhandled | User-provided server log | PROVEN |
| P10-E006 | Old Phase 10 2001 response had empty server lists | Existing source + 30-byte TX observed in user log | PROVEN |
| P10-E007 | Empty server catalog is consistent with `undefined` rows | Screenshot + protocol schema | STRONGLY SUPPORTED |
| P10-E008 | 2001/2002 local server catalog fix is schema-valid | Local dependency-free dispatch test | PROVEN |
| P10-E009 | 2005 empty notice response is schema-valid | Local dependency-free dispatch test | PROVEN |
| P10-E010 | 2020 empty config response is schema-valid | Local dependency-free dispatch test | PROVEN |
| P10-E011 | 2024 target platform is 330 | Captured 2024 CDN index evidence | PROVEN |
| P10-E012 | Phase 10 full WebSocket runtime was proven in the 2026-09-18 model environment | At that time, `ws` was unavailable and install failed | REJECTED (historical status; current dependency state is E016) |

## Current unknowns

- Whether the real browser accepts the new 2001 server entry.
- Whether the client sends 2004 after selecting the entry.
- Whether 2005/2020 require non-empty production data.
- Whether 2004 is accepted and leads to 3001.

## Current tree audit (2026-09-27)

| ID | Claim | Evidence | Status |
|---|---|---|---|
| P10-E013 | The current `src/handlers/dispatch.mjs` handles 2005 and 2020 | Source inspection: 2005 sends `notice_list=[]`; 2020 sends `config_list=[]` | PROVEN (source only) |
| P10-E014 | The current 2001 handler returns a single `Local Burst` server row | Source inspection: `serverId`, `serverName`, and `status=1` | PROVEN (source only) |
| P10-E015 | The current listener uses port 30004 and defaults `PLAT_ID` to 330 | `src/server.mjs` constants | PROVEN (source only) |
| P10-E016 | Current checkout has the `ws` runtime dependency installed | `npm ls --depth=0` reports `ws@8.21.3` | PROVEN (dependency present; server not started in this audit) |
| P10-E017 | The reported 2005/2020 `[UNHANDLED]` lines reflect the previously observed runtime, not the currently inspected handler source | Compare the user-provided trace with current dispatch switch | STRONGLY SUPPORTED; a fresh browser run is needed to identify which tree/process is running |
| P10-E018 | Current Phase 10 server completes its WebSocket protocol/boot integration test | Started current `src/server.mjs` on port 30004; `npm test` passed through 2001, 2002, 2005, 2020, 2004, 3001, 3003, 3004, 3011, 3017 | PROVEN (local integration test; not real-browser validation) |
| P10-E019 | Current dispatcher returns schema-encoded responses for 2001, 2002, 2004, 2005, and 2020 | `node test-startup-prelogin.mjs` output `[PASS]` | PROVEN (mock dispatcher test) |

### Current test boundaries

- `npm test` runs `src/test-phase10.mjs`, which is a WebSocket integration test and expects a server at `ws://127.0.0.1:30004` (or `URL`). It covers 2001, 2002, 2005, 2020, 2004, 3001, 3003, 3004, 3011, and 3017.
- `node test-startup-prelogin.mjs` directly exercises the dispatcher with a mock WebSocket; it does not start a listener or prove real browser compatibility. Its `port: 30001` is only a fixture value and is not the live Phase 10 port.
- The 2026-09-27 initial tree inspection was source-only. Afterward, both commands above were run: the mock dispatcher check and the full local WebSocket integration test passed. The test server started for integration testing was stopped afterward.
- Real-browser behavior is still unverified. In particular, the earlier browser's `undefined` display and which process/tree produced `[UNHANDLED]` require a fresh browser run against this exact checkout.
