# Pokémon Burst Local Server Phase 10

This phase merges the older replacement server's generic PacketCfg codec and 1,385-opcode registry into the clean local server baseline.

## Included
- generic schema-driven encoder/decoder
- PacketCfg `opcodes.json` + `types.json`
- 7-byte packet framing and TCP/WebSocket reassembly
- persistent local JSON account state
- known boot handlers: 2001, 2002, 2004, 2005, 2020, 3001, 3003, 3004, 3005, 3011, 3017, 3999
- unknown opcodes are logged, not fabricated
- protocol/boot regression test

## Run
```bash
npm install
npm start
```

Default endpoint: `ws://0.0.0.0:30004`

**Final game WebSocket port: `30004`. Do not change it.**

Set `ADVERTISE_HOST` when the client is not on the same machine.

## Validation commands

For the real WebSocket integration test, keep the server running in Terminal 1:

```bash
cd ~/pokemonburst-local-server-phase10
npm install
npm start
```

Then run this in Terminal 2:

```bash
cd ~/pokemonburst-local-server-phase10
npm test
```

Expected result: `Phase 10 protocol/boot test passed.` The test connects to
`ws://127.0.0.1:30004` by default and exercises the login, server-list, notice,
config, and boot sequence. To target another address, set `URL` for the test.

The mock-dispatcher check can be run separately without starting the server:

```bash
cd ~/pokemonburst-local-server-phase10
node test-startup-prelogin.mjs
```

Expected result: `[PASS] Phase10 startup/pre-login handlers: 2001, 2002, 2004,
2005, 2020`. Its port 30001 is a test fixture only; the server's actual port
remains 30004. H5SDK (8081) and CDN (8090) are separate processes and are not
started by either command. A passing source-level or local integration test
does not prove the real browser accepts the reconstructed values; confirm that
with a fresh browser run and server logs.

## Important
The registry bundled here is the older reconstructed registry. The 2024 client has a one-entry difference, so this is a compatibility bridge for Phase 10, not a claim that every opcode is identical to the 2024 build.
