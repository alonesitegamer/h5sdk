import WebSocket from "ws";
import { encodePacket, frameBuffer, decodePacket } from "./protocol-frame.mjs";
import { loadRegistry, encodeFields, decodeFields } from "./protocol/codec.mjs";

const {opcodes, types} = loadRegistry();
const u = (n)=>{if(!opcodes[String(n)]) throw new Error(`missing opcode ${n}`)};
[2001,2002,2004,2005,2020,3001,3003,3004,3011,3017,3999].forEach(u);

function waitFor(ws, opcode, timeout=3000){
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error(`timeout ${opcode}`)),timeout);
    const on=(data)=>{try{const ps=frameBuffer(Buffer.from(data)).packets; for(const raw of ps){const p=decodePacket(raw); if(p.opcode===opcode){clearTimeout(timer);ws.off("message",on);resolve(p);return}}}catch(e){clearTimeout(timer);ws.off("message",on);reject(e)}};
    ws.on("message",on);
  });
}
async function req(ws, opcode, obj){
  const pending = waitFor(ws, opcode);
  const body=encodeFields(opcodes[String(opcode)].c ?? [], obj, types);
  ws.send(encodePacket(opcode, 0, body));
  return pending;
}
const ws=new WebSocket(process.env.URL??"ws://127.0.0.1:30004");
await new Promise((res,rej)=>{ws.once("open",res);ws.once("error",rej)});
await req(ws,2001,{plat_id:330,game_channel_id:"10336",acc_id:"phase10",verify_time:1,sign:"local",channel:"local"});
await req(ws,2002,{large_server_id:1n});
await req(ws,2005,{});
await req(ws,2020,{});
await req(ws,2004,{server_id:1});
const p3001=waitFor(ws,3001);
const p3003=waitFor(ws,3003);
ws.send(encodePacket(3001,0,encodeFields(opcodes["3001"].c,{plat_id:330,server_id:1,game_channel_id:"10336",acc_id:"phase10",md5:"local",os:1,relogin:0,version:20241024736n},types)));
await p3001; await p3003;
const p3011=waitFor(ws,3011); await req(ws,3004,{}); await p3011;
await req(ws,3017,{lang:"en"});
console.log("Phase 10 protocol/boot test passed."); ws.close();
