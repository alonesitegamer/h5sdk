export class ClientSession {
  constructor(ws, config) {
    this.ws = ws;
    this.config = config;
    this.stamp = 0;
    this.state = "CONNECTED";
    this.accountId = "";
    this.playerId = null;
    this.platformId = config.platId;
    this.channel = "";
    this.gameChannelId = config.gameChannelId;
    this.serverId = config.serverId;
    this.authenticated = false;
  }
  nextStamp() {
    const s = this.stamp;
    this.stamp = this.stamp >= 127 ? 0 : this.stamp + 1;
    return s;
  }
}
