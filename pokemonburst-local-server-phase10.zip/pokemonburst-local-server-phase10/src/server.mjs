import { WebSocketServer } from "ws";
import fs from "node:fs";
import path from "node:path";
import { frameBuffer, decodePacket } from "./protocol-frame.mjs";
import { loadRegistry } from "./protocol/codec.mjs";
import { ClientSession } from "./session/session.mjs";
import { makeDispatcher } from "./handlers/dispatch.mjs";

const HOST = process.env.HOST ?? "0.0.0.0";
const PORT = 30004; // FINAL game WebSocket port. Do not change.
const config = {
  serverId: Number(process.env.SERVER_ID ?? 1),
  serverName: process.env.SERVER_NAME ?? "Local Burst",
  gameChannelId: process.env.GAME_CHANNEL_ID ?? "10336",
  platId: Number(process.env.PLAT_ID ?? 330),
  maxLevel: Number(process.env.MAX_LEVEL ?? 100),
  openServerDay: Number(process.env.OPEN_SERVER_DAY ?? 1),
  advertiseHost: process.env.ADVERTISE_HOST ?? "127.0.0.1",
  port: PORT,
};

const dbPath = path.resolve(process.env.DB ?? path.join(process.cwd(), "data", "server.json"));
function loadState() {
  try { return JSON.parse(fs.readFileSync(dbPath, "utf8")); }
  catch { return { nextRoleId: 1000001, accounts: {} }; }
}
const state = loadState();
state.save = () => {
  fs.mkdirSync(path.dirname(dbPath), {recursive:true});
  const tmp = `${dbPath}.part`;
  const json = JSON.stringify(state, (k,v)=>typeof v === "bigint" ? v.toString() : v, 2);
  fs.writeFileSync(tmp, json);
  fs.renameSync(tmp, dbPath);
};
const registry = loadRegistry();
const dispatch = makeDispatcher(registry, state, config);

const wss = new WebSocketServer({ host: HOST, port: PORT });
let connectionId = 0;
wss.on("listening", () => console.log(`Pokémon Burst phase10 server listening on ws://${HOST}:${PORT} server=${config.serverId} channel=${config.gameChannelId} plat=${config.platId}`));
wss.on("connection", (ws, req) => {
  const id = ++connectionId;
  const session = new ClientSession(ws, config);
  let buffer = Buffer.alloc(0);
  console.log(`[+] connection=${id} from=${req.socket.remoteAddress}`);
  ws.on("message", (data, isBinary) => { 
    const raw = Buffer.from(data);

console.log(
  `[WS RX RAW] connection=${id} binary=${isBinary} bytes=${raw.length} hex=${raw.subarray(0,64).toString("hex")}`
);   

    if (!isBinary) return console.log(`[WS] ignoring text frame connection=${id}`);
    try {
      buffer = Buffer.concat([buffer, Buffer.from(data)]);
      const framed = frameBuffer(buffer);
      buffer = framed.remainder;
      for (const raw of framed.packets) {
        const packet = decodePacket(raw);

        console.log(
          `[RX] connection=${id} opcode=${packet.opcode} flags=${packet.flags} bytes=${raw.length}`
        );

        console.dir(packet, { depth: 4 });

        dispatch(session, packet);
      }
    } catch (err) {
      console.error(`[!] connection=${id} protocol error`, err);
      ws.close(1002, "protocol error");
    }
  });
  ws.on("close", (code, reason) => console.log(`[-] connection=${id} code=${code} state=${session.state} reason=${reason}`));
});
