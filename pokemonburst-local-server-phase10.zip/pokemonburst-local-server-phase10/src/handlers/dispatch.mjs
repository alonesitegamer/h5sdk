import { decodeFields, encodeFields } from "../protocol/codec.mjs";
import { buildDefaultObject } from "../protocol/defaults.mjs";
import { encodePacket } from "../../src/protocol-frame.mjs";

export function makeDispatcher(registry, state, config) {
  const { opcodes, types } = registry;
  return function dispatch(session, packet) {
    const cfg = opcodes[String(packet.opcode)];
    const name = cfg?.m ?? "UNKNOWN";
    console.log(`[RX] opcode=${packet.opcode} ${name} stamp=${packet.stamp} bytes=${packet.payload.length}`);
    if (!cfg) {
      console.warn(`[SKIP] unknown opcode ${packet.opcode}`);
      return;
    }
    let req = {};
    if (cfg.c?.length) req = decodeFields(cfg.c, packet.payload, types);

    switch (packet.opcode) {
      case 2001:
        session.state = "ACCOUNT_LOGIN";
        session.platformId = Number(req.plat_id ?? config.platId);
        session.gameChannelId = String(req.game_channel_id ?? config.gameChannelId);
        session.accountId = String(req.acc_id ?? "local");
        session.channel = String(req.channel ?? "");
        ensureAccount(state, session.accountId);
        return send(session, opcodes, types, 2001, {
          result: 0,
          new_server: [{server_id: config.serverId, name: config.serverName, status: 1}],
          login_history: [],
          large_server_list: [],
          game_channel_id: session.gameChannelId,
        });
      case 2002:
        return send(session, opcodes, types, 2002, {
          large_server_id: req.large_server_id ?? 1n,
          server_list: [{server_id: config.serverId, name: config.serverName, status: 1}],
        });
      case 2004:
        session.serverId = config.serverId;
        return send(session, opcodes, types, 2004, {
          result: 0,
          acc_id: session.accountId,
          md5: "local",
          ip: config.advertiseHost,
          port: config.port,
          plat_id: config.platId,
        });
      case 3001:
        session.state = "GAME_LOGIN";
        session.authenticated = true;
        if (!session.accountId) session.accountId = String(req.acc_id ?? "local");
        ensureAccount(state, session.accountId);
        send(session, opcodes, types, 3001, { result: 0 });
        return send(session, opcodes, types, 3003, {});
      case 3004: {
        session.state = "LOADED";
        const acct = ensureAccount(state, session.accountId || "local");
        const role = buildDefaultObject("simple_role", types);
        Object.assign(role, {
          role_id: BigInt(acct.playerId),
          name: acct.name,
          srv_id: config.serverId,
          srv_name: config.serverName,
          power: BigInt(acct.power),
          vip_lev: acct.vipLevel,
          lev: acct.level,
          guild_name: acct.guildName,
          team_name: acct.teamName,
          fashion_use_list: [], title_list: [], attr_list: [], medal_list: [], token_list: [], joint_team_dun: [],
          taoist_id: 0,
        });
        send(session, opcodes, types, 3004, { role });
        return send(session, opcodes, types, 3011, {});
      }
      case 2005:
        return send(session, opcodes, types, 2005, {
          notice_list: [],
        });
      case 2020:
        return send(session, opcodes, types, 2020, {
          config_list: [],
        });
      case 3005:
        return send(session, opcodes, types, 3005, {
          open_server_day: config.openServerDay,
          now_time: Math.floor(Date.now()/1000),
          max_lev: config.maxLevel,
        });
      case 3017:
        return send(session, opcodes, types, 3017, { result: 0, lang: String(req.lang ?? "en") });
      case 3003:
      case 3011:
        console.log(`[INFO] ignored client delivery of server-push opcode ${packet.opcode}`);
        return;
      case 3006:
        session.state = "OFFLINE";
        return;
      case 3999:
        return send(session, opcodes, types, 3999, { unix_time: Math.floor(Date.now()/1000) });
      default:
        console.log(`[UNHANDLED] ${packet.opcode} ${name}`);
    }
  };
}

function ensureAccount(state, accountId) {
  const key = String(accountId || "local");
  if (!state.accounts[key]) {
    const playerId = state.nextRoleId++;
    state.accounts[key] = { accountId: key, playerId, createdAt: Date.now(), name: `Trainer${String(playerId).slice(-4)}`, level: 1, power: 0, vipLevel: 0, guildName: "", teamName: "" };
    saveState(state);
  }
  return state.accounts[key];
}

function saveState(state) {
  if (!state.save) return;
  state.save();
}

function send(session, opcodes, types, opcode, obj) {
  const cfg = opcodes[String(opcode)];
  if (!cfg?.s) throw new Error(`Missing server schema for opcode ${opcode}`);
  const payload = encodeFields(cfg.s, obj, types);
  session.ws.send(encodePacket(opcode, session.nextStamp(), payload));
  console.log(`[TX] opcode=${opcode} ${cfg.m ?? ""} bytes=${payload.length}`);
}
