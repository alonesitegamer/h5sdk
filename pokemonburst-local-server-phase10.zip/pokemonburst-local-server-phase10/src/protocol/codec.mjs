import { readFileSync } from "node:fs";
import { resolve } from "node:path";
export class Writer {
    b = [];
    u8(v) { const x = Buffer.alloc(1); x.writeUInt8(v & 255); this.b.push(x); }
    i8(v) { const x = Buffer.alloc(1); x.writeInt8(v); this.b.push(x); }
    u16(v) { const x = Buffer.alloc(2); x.writeUInt16BE(v >>> 0); this.b.push(x); }
    i16(v) { const x = Buffer.alloc(2); x.writeInt16BE(v); this.b.push(x); }
    u32(v) { const x = Buffer.alloc(4); x.writeUInt32BE(v >>> 0); this.b.push(x); }
    i32(v) { const x = Buffer.alloc(4); x.writeInt32BE(v); this.b.push(x); }
    u64(v) { const x = Buffer.alloc(8); x.writeBigUInt64BE(v); this.b.push(x); }
    i64(v) { const x = Buffer.alloc(8); x.writeBigInt64BE(v); this.b.push(x); }
    f64(v) { const x = Buffer.alloc(8); x.writeDoubleBE(v); this.b.push(x); }
    string(v) { const x = Buffer.from(v, "utf8"); if (x.length > 65535)
        throw Error("string too long"); this.u16(x.length); this.b.push(x); }
    raw(x) { this.b.push(x); }
    arrayLen(n) { if (n < 0 || n > 32767)
        throw Error("array length"); if (n < 255)
        this.u8(n);
    else {
        this.u8(255);
        this.i16(n);
    } }
    out() { return Buffer.concat(this.b); }
}
export class Reader {
    b;
    o;
    constructor(b, o = 0) {
        this.b = b;
        this.o = o;
    }
    need(n) { if (this.o + n > this.b.length)
        throw Error(`truncated payload: need ${n}, remaining ${this.b.length - this.o}`); }
    u8() { this.need(1); return this.b.readUInt8(this.o++); }
    i8() { this.need(1); return this.b.readInt8(this.o++); }
    u16() { this.need(2); const v = this.b.readUInt16BE(this.o); this.o += 2; return v; }
    i16() { this.need(2); const v = this.b.readInt16BE(this.o); this.o += 2; return v; }
    u32() { this.need(4); const v = this.b.readUInt32BE(this.o); this.o += 4; return v; }
    i32() { this.need(4); const v = this.b.readInt32BE(this.o); this.o += 4; return v; }
    u64() { this.need(8); const v = this.b.readBigUInt64BE(this.o); this.o += 8; return v; }
    i64() { this.need(8); const v = this.b.readBigInt64BE(this.o); this.o += 8; return v; }
    f64() { this.need(8); const v = this.b.readDoubleBE(this.o); this.o += 8; return v; }
    string() { const n = this.u16(); this.need(n); const s = this.b.subarray(this.o, this.o + n).toString("utf8"); this.o += n; return s; }
    arrayLen() { const n = this.u8(); return n === 255 ? this.i16() : n; }
}
export function loadRegistry() {
    const candidates = [
        resolve(process.cwd(), "../protocol-data/pokemonburst_protocol_extracted"),
        resolve(process.cwd(), "protocol-data/pokemonburst_protocol_extracted"),
        resolve(process.cwd(), "../protocol-data"),
    ];
    const base = candidates.find((p) => {
        try {
            return Boolean(readFileSync(resolve(p, "opcodes.json"), "utf8"));
        }
        catch {
            return false;
        }
    });
    if (!base) {
        throw new Error("PacketCfg registry not found. Expected ../protocol-data/pokemonburst_protocol_extracted/opcodes.json");
    }
    return {
        opcodes: JSON.parse(readFileSync(resolve(base, "opcodes.json"), "utf8")),
        types: JSON.parse(readFileSync(resolve(base, "types.json"), "utf8"))
    };
}
function primitiveWrite(w, t, v) {
    switch (t) {
        case "int8":
            w.i8(Number(v));
            break;
        case "uint8":
            w.u8(Number(v));
            break;
        case "int16":
            w.i16(Number(v));
            break;
        case "uint16":
            w.u16(Number(v));
            break;
        case "int32":
            w.i32(Number(v));
            break;
        case "uint32":
            w.u32(Number(v));
            break;
        case "int64":
            w.i64(BigInt(v));
            break;
        case "uint64":
            w.u64(BigInt(v));
            break;
        case "number":
        case "float64":
        case "double":
            w.f64(Number(v));
            break;
        case "string":
            w.string(String(v ?? ""));
            break;
        default: return false;
    }
    return true;
}
function primitiveRead(r, t) {
    switch (t) {
        case "int8": return r.i8();
        case "uint8": return r.u8();
        case "int16": return r.i16();
        case "uint16": return r.u16();
        case "int32": return r.i32();
        case "uint32": return r.u32();
        case "int64": return r.i64();
        case "uint64": return r.u64();
        case "number":
        case "float64":
        case "double": return r.f64();
        case "string": return r.string();
        default: return undefined;
    }
}
export function encodeFields(fields, value, types) {
    const w = new Writer();
    for (const [name, type, ...extra] of fields)
        encodeValue(w, type, value?.[name], extra, types);
    return w.out();
}
function encodeValue(w, type, v, extra, types) {
    const p = primitiveWrite(w, type, v);
    if (p)
        return;
    if (type === "array") {
        if (!Array.isArray(v))
            throw Error("array field is not an array");
        w.arrayLen(v.length);
        for (const item of v)
            encodeValue(w, String(extra[0]), item, [], types);
        return;
    }
    const fields = types[type];
    if (!fields)
        throw Error(`unknown schema type ${type}`);
    w.raw(encodeFields(fields, v ?? {}, types));
}
export function decodeFields(fields, payload, types) {
    const r = new Reader(payload), out = {};
    for (const [name, type, ...extra] of fields)
        out[name] = decodeValue(r, type, extra, types);
    if (r.o !== payload.length)
        throw Error(`trailing payload bytes: ${payload.length - r.o}`);
    return out;
}
function decodeValue(r, type, extra, types) {
    const p = primitiveRead(r, type);
    if (p !== undefined)
        return p;
    if (type === "array") {
        const n = r.arrayLen(), a = [];
        for (let i = 0; i < n; i++)
            a.push(decodeValue(r, String(extra[0]), [], types));
        return a;
    }
    const fields = types[type];
    if (!fields)
        throw Error(`unknown schema type ${type}`);
    const out = {};
    for (const [name, t, ...e] of fields)
        out[name] = decodeValue(r, t, e, types);
    return out;
}
