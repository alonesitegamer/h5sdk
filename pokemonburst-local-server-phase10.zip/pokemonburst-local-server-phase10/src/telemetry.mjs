import http from "node:http";

const HOST = "0.0.0.0";

function readBody(req) {
  return new Promise((resolve) => {
    let body = "";

    req.on("data", chunk => {
      body += chunk;
    });

    req.on("end", () => resolve(body));
  });
}

function send(res, status = 200, body = "OK") {
  res.writeHead(status, {
    "Content-Type": "text/plain; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "*"
  });

  res.end(body);
}

function createTelemetryServer(port, name) {
  const server = http.createServer(async (req, res) => {
    if (req.method === "OPTIONS") {
      return send(res, 204, "");
    }

    const url = new URL(req.url, `http://${req.headers.host}`);

    console.log(
      `[${name}] ${req.method} ${url.pathname}${url.search}`
    );

    if (req.method === "GET") {
      console.log(
        `[${name}] query=`,
        Object.fromEntries(url.searchParams.entries())
      );

      return send(res, 200, "OK");
    }

    if (req.method === "POST") {
      const body = await readBody(req);

      console.log(
        `[${name}] POST body:`,
        body.slice(0, 4000)
      );

      return send(res, 200, "OK");
    }

    return send(res, 405, "Method Not Allowed");
  });

  server.listen(port, HOST, () => {
    console.log(
      `[+] ${name} listening on http://${HOST}:${port}`
    );
  });
}

createTelemetryServer(30098, "30098");
createTelemetryServer(30099, "30099");