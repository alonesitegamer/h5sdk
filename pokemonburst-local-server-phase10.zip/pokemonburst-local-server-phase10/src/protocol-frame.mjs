
export function encodePacket(opcode, stamp, payload = Buffer.alloc(0)) {
  if (!Buffer.isBuffer(payload)) payload = Buffer.from(payload);
  const length = 7 + payload.length;
  const out = Buffer.alloc(length);
  out.writeUInt32BE(length, 0);
  out.writeUInt16BE(opcode, 4);
  out.writeUInt8(stamp & 0x7f, 6);
  payload.copy(out, 7);
  return out;
}

export function frameBuffer(buffer) {
  const packets = [];
  let offset = 0;

  while (buffer.length - offset >= 7) {
    const length = buffer.readUInt32BE(offset);
    if (length < 7) throw new Error(`Invalid packet length: ${length}`);
    if (buffer.length - offset < length) break;

    packets.push(buffer.subarray(offset, offset + length));
    offset += length;
  }

  return { packets, remainder: buffer.subarray(offset) };
}

export function decodePacket(packet) {
  if (packet.length < 7) throw new Error("Packet shorter than 7 bytes");
  const length = packet.readUInt32BE(0);
  if (length !== packet.length) {
    throw new Error(`Length mismatch: header=${length}, actual=${packet.length}`);
  }
  return {
    length,
    opcode: packet.readUInt16BE(4),
    stamp: packet.readUInt8(6),
    payload: packet.subarray(7)
  };
}

export function readInt8(buf, offset) {
  return { value: buf.readInt8(offset), offset: offset + 1 };
}
export function readUInt8(buf, offset) {
  return { value: buf.readUInt8(offset), offset: offset + 1 };
}
export function readInt16(buf, offset) {
  return { value: buf.readInt16BE(offset), offset: offset + 2 };
}
export function readUInt16(buf, offset) {
  return { value: buf.readUInt16BE(offset), offset: offset + 2 };
}
export function readInt32(buf, offset) {
  return { value: buf.readInt32BE(offset), offset: offset + 4 };
}
export function readUInt32(buf, offset) {
  return { value: buf.readUInt32BE(offset), offset: offset + 4 };
}
export function readInt64(buf, offset) {
  return { value: buf.readBigInt64BE(offset), offset: offset + 8 };
}

export function readString(buf, offset) {
  const len = buf.readUInt16BE(offset);
  offset += 2;
  const end = offset + len;
  if (end > buf.length) throw new Error("String exceeds payload");
  return {
    value: buf.subarray(offset, end).toString("utf8"),
    offset: end
  };
}

export function writeString(value) {
  const data = Buffer.from(String(value), "utf8");
  if (data.length > 0xffff) throw new Error("String too long");
  const out = Buffer.alloc(2 + data.length);
  out.writeUInt16BE(data.length, 0);
  data.copy(out, 2);
  return out;
}

export function concat(parts) {
  return Buffer.concat(parts);
}
