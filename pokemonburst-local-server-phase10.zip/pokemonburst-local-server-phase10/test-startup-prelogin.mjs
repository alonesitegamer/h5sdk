import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { encodeFields, decodeFields, loadRegistry } from './src/protocol/codec.mjs';
import { encodePacket, decodePacket } from './src/protocol-frame.mjs';
import { makeDispatcher } from './src/handlers/dispatch.mjs';

const {opcodes, types} = loadRegistry();
const sent = [];
const ws = { send: b => sent.push(Buffer.from(b)) };
const state = { nextRoleId: 1000001, accounts: {}, save() {} };
const config = {
  serverId: 1,
  serverName: 'Local Burst',
  gameChannelId: '10336',
  platId: 330,
  maxLevel: 100,
  openServerDay: 1,
  advertiseHost: '127.0.0.1',
  port: 30001,
};
const dispatch = makeDispatcher(loadRegistry(), state, config);

function request(opcode, obj) {
  const body = encodeFields(opcodes[String(opcode)].c ?? [], obj, types);
  dispatch({ws, nextStamp: () => 0, state:'CONNECTED', accountId:'', serverId:1}, {
    opcode, stamp: 0, payload: body
  });
}

const session = { ws, nextStamp: (() => { let n=0; return () => n++; })(), state:'CONNECTED', accountId:'', serverId:1 };
function sendRequest(opcode, obj) {
  const body = encodeFields(opcodes[String(opcode)].c ?? [], obj, types);
  dispatch(session, { opcode, stamp: 0, payload: body });
}

sendRequest(2001, {plat_id:330, game_channel_id:'10336', acc_id:'phase10-fix', verify_time:1, sign:'local', channel:'local'});
assert.equal(sent.at(-1).readUInt16BE(4), 2001);
let decoded = decodeFields(opcodes['2001'].s, sent.at(-1).subarray(7), types);
assert.equal(decoded.result, 0);
assert.equal(decoded.new_server.length, 1);
assert.equal(decoded.new_server[0].server_id, 1);
assert.equal(decoded.new_server[0].name, 'Local Burst');
assert.equal(decoded.new_server[0].status, 1);

sendRequest(2002, {large_server_id:1n});
decoded = decodeFields(opcodes['2002'].s, sent.at(-1).subarray(7), types);
assert.equal(decoded.server_list.length, 1);
assert.equal(decoded.server_list[0].server_id, 1);

sendRequest(2005, {});
decoded = decodeFields(opcodes['2005'].s, sent.at(-1).subarray(7), types);
assert.deepEqual(decoded.notice_list, []);

sendRequest(2020, {});
decoded = decodeFields(opcodes['2020'].s, sent.at(-1).subarray(7), types);
assert.deepEqual(decoded.config_list, []);

sendRequest(2004, {server_id:1});
decoded = decodeFields(opcodes['2004'].s, sent.at(-1).subarray(7), types);
assert.equal(decoded.plat_id, 330);
assert.equal(decoded.port, 30001);

console.log('[PASS] Phase10 startup/pre-login handlers: 2001, 2002, 2004, 2005, 2020');
