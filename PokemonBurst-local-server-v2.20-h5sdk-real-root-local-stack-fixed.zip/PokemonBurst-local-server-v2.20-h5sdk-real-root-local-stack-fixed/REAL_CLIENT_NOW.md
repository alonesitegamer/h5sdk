# v2.1 — Real Client, Now

We are done with synthetic login tests.

## 1. Keep the replacement server running

Use the terminal where the server is already listening:

```bash
cd ~/pokemonburst-replacement-server-v2.1/server
npm install
npm run dev:local
```

Do not start a second copy on port 30001.

## 2. Patch a LOCAL COPY of the extracted client tree

The package now contains:

```text
tools/patch_client_tree.py
```

Usage:

```bash
python3 tools/patch_client_tree.py \
  /path/to/client-copy \
  /path/to/client-copy-ryure
```

Default replacement:

```text
mon-1.frstinta.com:30001
        ↓
ryure:30001
```

The tool recursively searches common text/bundle/config files and reports
exactly which files it changed.

## 3. Launch that local client copy

Keep the server terminal visible.

We are NOT expecting the first run to fully work.

The first useful result is one of:

```text
[+] connection state=CONNECTED
[RX] opcode=...
```

or a clear client-side connection/bootstrap error.

## 4. If there is NO server connection

Immediately search the copied client tree:

```bash
grep -Rni --binary-files=without-match \
  -E 'mon-1\.frstinta\.com|:30001|ws://|wss://' \
  /path/to/client-copy-ryure | head -100
```

That tells us whether another endpoint is still embedded.

## 5. If the server DOES receive traffic

Stop changing anything else.

Copy the server log from the first connection through the first failure.

That first real opcode/error is the next engineering target.

## 6. Do not patch production

Use only the copied/local client tree for this experiment.
