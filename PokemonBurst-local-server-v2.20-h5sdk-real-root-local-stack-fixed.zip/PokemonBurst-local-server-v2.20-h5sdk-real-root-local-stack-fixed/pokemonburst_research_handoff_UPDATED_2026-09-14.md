# Pokémon Burst H5 CDN / Local Server Research Handoff

## 0. Main goal

The main goal of this project is to make the recovered Pokémon Burst H5 client run as locally and reproducibly as possible while preserving the original game's server-side behavior where necessary.

The current direction is:

```text
Original game client
        |
        +---- resource requests ----> local HTTP resource mirror
        |                              (target: 127.0.0.1:8090)
        |
        +---- game/login WebSocket --> replacement/local game server
                                       (target previously discussed: :30001)
```

The resource side is now substantially understood and an English resource mirror has already been built.

The remaining major task is client integration: make the game's resource-loading pipeline point at the local mirror without breaking the WebSocket/game-server path.

This document is intended as a handoff to another AI/chat so work can continue without repeating the investigation.

---

# 1. Target / important paths

## CDN

```text
https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/
```

## Version

```text
20241024736
```

## Captured local client tree

```text
/home/ryure/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w
```

Set conveniently:

```bash
ROOT=~/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w
```

## Version map

```text
$ROOT/versionAutoGen.20241024736__v_20241024736.js
```

The file exposes a large `window.VersionManager` object.

Confirmed:

```text
VersionManager entries: 40,562
```

The version map format is:

```text
logical resource -> 7/8 hex CRC
```

Example:

```text
resource/assets_en/bones/effect/b3004_ske.json -> a62d73f
```

---

# 2. Initial CDN behavior discovered

Attempting to access a directory directly fails:

```text
curl -I 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/resource/'
HTTP/2 403
```

So the CDN does not provide an ordinary directory listing.

An explicit object request can work.

The key discovery was that the public CDN filename convention is NOT the same as the filename convention used by the captured filesystem.

## Captured/local filename convention

Examples:

```text
b3004_ske_a62d73f__v_20241024736.json
bar_fight_0005_20d5399d__v_20241024736.png
```

## Public CDN convention confirmed

For the English asset tree:

```text
<logical path with resource/>
<basename>_<VersionManager CRC>.<extension>?v=<version>
```

Example:

```text
resource/assets_en/bones/effect/b3004_ske_a62d73f.json?v=20241024736
```

The `__v_20241024736` suffix is NOT present in the public CDN filename in the confirmed cases.

---

# 3. Strong CDN proof: complete b3004 DragonBones bundle

The following public CDN objects were independently tested and returned HTTP 200:

```text
resource/assets_en/bones/effect/b3004_ske_81a1dfbc.dbbin?v=20241024736
```

size:

```text
3292 bytes
```

```text
resource/assets_en/bones/effect/b3004_ske_a62d73f.json?v=20241024736
```

size:

```text
4984 bytes
```

```text
resource/assets_en/bones/effect/b3004_tex_773ad33a.json?v=20241024736
```

size:

```text
810 bytes
```

```text
resource/assets_en/bones/effect/b3004_tex_fb984669.png?v=20241024736
```

size:

```text
36609 bytes
```

This was important because the local capture lacked the `.json` skeleton file while having the related files.

The four-file bundle therefore demonstrated that:

```text
VersionManager CRC
        +
English resource path
        +
public filename transformation
        +
?v=version
```

can retrieve actual live CDN objects.

---

# 4. Runtime / code findings

The game uses Egret/RES-style resource loading.

The game creates and registers a custom version controller:

```text
new e.MyVersionConstroller
RES.registerVersionController(e.Constroller)
```

This happens during game launch.

The resource-loading path therefore does NOT simply concatenate a hard-coded CDN URL.

The runtime has functions including:

```text
getVirtualUrl
_getURL
```

and `RES` delegates URL transformation to the registered version controller.

A discovered `_getURL()` implementation uses logic equivalent to:

```text
if window.useCrc:
    if window.VersionManager[e]:
        insert "_" + VersionManager[e] before extension
    otherwise add ?v=window.version

then optional channel-specific resource-root logic

then optional delayUpdateResVersion transformation
```

The relevant behavior is visible in the supplied controller search output.

Important implementation detail:

```text
window.useCrc
window.VersionManager
window.version
window.wxResRoot
window.ucResRoot
window.vivoResRoot
window.huaweiResRoot
window.oppoResRoot
window.delayUpdateResVersion
```

are meaningful to resource URL construction.

There is also a `replaceRes` table inside `MyVersionConstroller`, mapping groups of paths such as:

```text
bones/char/...
bones/effect/...
bonesImg/...
gameui/...
icon/...
```

to logical resource categories.

This suggests resource URL construction has multiple stages.

Do NOT blindly replace every `https://` or every CDN string in minified JS.

The preferred target is the version-controller/resource-root layer.

---

# 5. Game server / network behavior

The launch code reads `window.SERVER_CONFIG` and selects server addresses.

The game protocol can become:

```text
ws
```

or:

```text
wss
```

depending on HTTP/HTTPS/runtime conditions.

The earlier local-server work has used:

```text
:30001
```

as the replacement game/login server target.

Important separation:

```text resource HTTP
        !=
game WebSocket
```

The goal is to redirect resource traffic locally while keeping the game/server communication independently controlled.

---

# 6. Resource manifests

Two major manifests were investigated.

## default manifest

```text
resource/default.res_18f57742__v_20241024736.json
```

It contains:

```text
4674 resources
```

Example entries:

```text
{'url': 'config.json', 'type': 'json', 'name': 'config_json'}

{'url': 'assets/simple/ToggleSwitch/handle.png',
 'type': 'image',
 'name': 'handle_png'}
```

## config manifest

```text
resource/config_ec56b6a1__v_20241024736.json
```

It contains 10 resources, including:

```text
config/cq_0.json
config/cq_1.json
config/cq_2.json
config/cq_3.json
config/cq_4.json
```

Important namespace mismatch discovered:

Manifest URLs use:

```text
assets/gameui/...
config/cq_0.json
```

while VersionManager keys use:

```text
resource/assets/gameui/...
resource/config/cq_0.json
```

This mismatch caused an early resolver to incorrectly conclude that many manifest resources had no VersionManager mapping.

---

# 7. Phase 1 through Phase 3 results

## Phase 1

Purpose:

Match captured physical files against the 40,562 VersionManager entries.

Result:

```text
Physical files: 3,377
Logical map: 40,562
Direct: 0
Basename+hash: 3,755
Loose hash: 12
Missing: 36,795
Resolved: 3,767 / 40,562
Resolution rate: 9.29%
```

Phase 1 was analysis-only.

Outputs:

```text
resource-index.json
resource-index.csv
missing.txt
ambiguous.txt
```

Key lesson:

Do not interpret raw physical-file count as resource completeness.

---

## Missing-family analysis

Missing resources were heavily concentrated in:

```text
resource/assets
resource/assets_ru
resource/assets_pt
resource/assets_sp
resource/assets_ko
resource/assets_tw
resource/assets_de
resource/assets_fr
resource/assets_en
resource/config_br
```

At one point the unresolved base `resource/assets` subset had:

```text
9225 .png
2656 .json
1080 .dbbin
182 .jpg
28 .wav
26 .fnt
20 .mp3
5 .ogg
3 .tmf
1 .rar
```

The exact counts came from the captured `missing.txt`.

---

## Shared CRC analysis

Among unresolved base asset entries:

```text
13,226 unresolved base entries
75 had a CRC already present locally
```

Those 75 broke down as:

```text
73 png
1 dbbin
1 json
```

VersionManager-wide deduplication:

```text
40,562 logical entries
36,195 unique CRC+extension pairs
4,367 potential alias reductions
```

There were:

```text
2,280 shared CRC groups
6,647 logical entries in those shared groups
4,367 extra aliases
```

This matters because one downloaded object may satisfy multiple logical names.

---

# 8. Phase 2 / 2.1 / 2.2

Phase 2 attempted manifest-to-physical-path resolution.

Initial Phase 2 result:

```text
Manifest resources: 4,684
no_path: 4,684
```

Reason: manifests use a different namespace from VersionManager keys.

Phase 2.1 then produced:

```text
Version map entries : 40,562
Manifest resources : 4,684
no_version_map     : 3,907
exact              : 756
same_basename      : 18
same_hash_any_path : 3
```

Phase 2.2 kept the namespace correction and checked multiple physical naming rules.

It did not dramatically improve overall coverage.

Lesson:

Static manifest reconciliation alone is not enough to recover the full CDN corpus.

---

# 9. Phase 3 master reconciliation

Phase 3 compared all 40,562 VersionManager entries against the physical capture.

Result:

```text
unresolved            36,717
exact                  3,343
relocated_exact_name     406
crc_shared_extension      90
relocated_hash_match       6

Resolved: 3,845 / 40,562
Resolution rate: 9.48%

Shared CRC values: 2,280
```

Outputs:

```text
master-reconciliation.csv
exact.txt
relocated_exact_name.txt
relocated_hash_match.txt
crc_shared_extension.txt
unresolved.txt
shared-crc.json
summary.json
```

The conclusion was that brute-force static reconciliation would be inefficient.

---

# 10. Language resources

A discovered file:

```text
resource/i18n/language_res_6b8131e__v_20241024736.json
```

contains:

```text
2,536 entries
```

The entries are relative resource names, such as:

```text
gameui/59_island/bg_island_0006.png
icon/act/icon_yk_0001.png
icon/item/80075.png
```

Initial naive comparison against `resource/<key>` gave zero VersionManager hits because the language resources are a namespace-relative list.

After using the correct `resource/assets/` namespace, VersionManager coverage became:

```text
2,489 / 2,536
```

with 47 missing from the base VM comparison.

Variant coverage was then checked across:

```text
en
ru
pt
sp
ko
tw
de
fr
```

VersionManager coverage per language map:

```text
en 2499/2536 = 98.54%
ru 2492/2536 = 98.26%
pt 2509/2536 = 98.94%
sp 2460/2536 = 97.00%
ko 2481/2536 = 97.83%
tw 2474/2536 = 97.56%
de 2496/2536 = 98.42%
fr 2474/2536 = 97.56%
```

Physical capture availability was very asymmetric.

The local snapshot had:

```text
assets_en directory: 566 files
assets_ru: missing
assets_pt: missing
assets_sp: missing
assets_ko: missing
assets_tw: missing
assets_de: missing
assets_fr: missing
```

Therefore the current practical target is ENGLISH ONLY.

---

# 11. Phase 5: local CDN emulator

A local HTTP server was built.

Conceptually:

```text
Client request
      |
      v
Local CDN emulator
      |
      +-- exact local capture
      |
      +-- relocated local capture by basename
      |
      +-- upstream explicit URL
              |
              v
            cache
```

Default local port:

```text
8090
```

It supports:

```text
HEAD
GET
CORS
cache headers
SQLite request logging
exact local serving
basename/relocated serving
upstream fetch fallback
```

Example:

```bash
python3 ~/pokemonburst-phase5-local-cdn/tools/phase5_local_cdn_emulator.py \
  --mirror /home/ryure/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w \
  --port 8090 \
  --upstream 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/'
```

Important Phase 5 bug was fixed:

```text
self.db
```

was replaced with the proper server-level reference.

---

# 12. Phase 5 proof

A known English local file returned:

```text
HTTP/1.0 200 OK
Content-Type: image/png
Content-Length: 4606
```

The relocated base request:

```text
resource/assets/bar_fight_0005_20d5399d__v_20241024736.png
```

also returned:

```text
HTTP/1.0 200 OK
```

and was resolved from:

```text
resource/assets/gameui/1_fight/buff/
bar_fight_0005_20d5399d__v_20241024736.png
```

This confirmed the local emulator can tolerate physical path differences.

---

# 13. Important Phase 5 failed assumption

The original emulator upstream fallback generated:

```text
<basename>_<crc>__v_<version>.<ext>
```

This was WRONG for public CDN requests.

A manual CDN test:

```text
.../b3004_ske_a62d73f__v_20241024736.json
```

returned:

```text 404
```

But:

```text
.../b3004_ske_a62d73f.json?v=20241024736
```

returned:

```text 200
```

Therefore:

```text
__v_<version>
```

belongs to the captured/local filename convention.

It should NOT be added to the public CDN URL.

---

# 14. Phase 6 CDN URL verifier

Phase 6 was created to validate the public URL naming rule.

The first run produced 100/100 404s.

This was a verifier bug: it accidentally stripped the `resource/` prefix.

After fixing that, the exact same 100-resource sample produced:

```text
HTTP_200: 100
HTTP_404: 0
HTTP_OTHER: 0
NETWORK_ERROR: 0
```

The 100 entries covered:

```text bones/effect/*.ske.dbbin
bones/effect/*.ske.json
bones/effect/*_tex.json
bones/effect/*_tex.png
bones/title/*.json
bones/title/*.png
```

This is strong empirical evidence that the public English naming convention works broadly.

Correct formula:

```text
https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/
resource/assets_en/
<logical-dir>/
<basename>_<CRC>.<extension>
?v=20241024736
```

---

# 15. Phase 7: English bulk mirror

Phase 7 was then built as a resumable downloader.

Purpose:

Process English VersionManager entries:

```text
resource/assets_en/
```

using the verified public CDN rule.

Features:

```text
reuses matching files from existing capture
downloads missing files
8 workers
retry/backoff
atomic .part downloads
SQLite bookkeeping
CSV report
SHA-256
resume support
sample mode
dry-run mode
```

Output:

```text
~/pokemonburst-english-mirror/
```

Main files:

```text
resource/assets_en/
resources.sqlite
resource-report.csv
```

Recommended command used:

```bash
python3 ~/pokemonburst-phase7-english-mirror/tools/phase7_english_mirror.py \
  --source /home/ryure/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w \
  --version-map /home/ryure/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/versionAutoGen.20241024736__v_20241024736.js \
  --out ~/pokemonburst-english-mirror \
  --cdn 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/' \
  --workers 8 \
  --delay 0.05 \
  --retries 4 \
  --referer 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/index.html?zzh5=1&dd=000000000000000&af_id=&g=10336&options=null&p=smileonexjlbt_android_ios'
```

---

# 16. Phase 7 final result

There were:

```text
3,298 English VersionManager candidates
```

Final statuses:

```text
DOWNLOADED           2,703
SEEDED_FROM_CAPTURE    573
ALREADY_PRESENT         20
HTTP_403                 1
ERROR                   1
```

Therefore:

```text
3,296 / 3,298 successfully represented
```

This is approximately:

```text
99.94%
```

The mirror's actual file count:

```text
3296
```

The reported disk usage:

```text
50M
```

The two remaining exceptions:

```text
resource/assets_en/gameui/1_fight/float/float_font/#.png
CRC a4a1e6be
HTTP 403

resource/assets_en/gameui/1_fight/float/float_font/%.png
CRC 24056c13
HTTP 400
```

These should be investigated later. They are special-character filenames and may need URL encoding or another runtime-specific transformation.

Do NOT let those two exceptions block client integration.

---

# 17. Current local resource mirror status

Current English mirror:

```text
~/pokemonburst-english-mirror/
```

Contains:

```text
3296 files
~50 MB
```

The local CDN emulator was successfully tested against this clean mirror.

Example:

```bash
curl -I \
'http://127.0.0.1:8090/resource/assets_en/bones/effect/b3004_ske_a62d73f.json?v=20241024736'
```

returned:

```text
HTTP/1.0 200 OK
Content-Type: application/json
Content-Length: 4984
```

So the local mirror itself works.

---

# 18. Phase 8 current investigation

The current task is to test the already-inserted `MyVersionConstroller.getVirtualUrl()` resource-origin patch against the real client.

The first idea was to search for a simple global:

```text
resourceRoot
remoteRoot
cdn root
```

No single obvious hard-coded web CDN root was found in the initial search.

The more useful discovery was the actual runtime controller.

Relevant source behavior:

```text
new e.MyVersionConstroller
RES.registerVersionController(e.Constroller)
```

and the `_getURL()` logic described above.

The runtime also contains channel/resource-root functions:

```text
getWxRemoteRoot
getQQRemoteRoot
getTTRemoteRoot
getBLRemoteRoot
getQGameResRoot
```

and a `replaceRes` mapping inside the custom controller.

There is an `AssetAdapter` which uses:

```text
RES.hasRes
kdyg.ResMgr.getRes
kdyg.ResMgr.getResAsync
kdyg.ResMgr.getResByUrl
```

which confirms resource loading eventually passes through the resource manager/controller system.

---

# 19. Critical code excerpt discovered in the controller investigation

One relevant loading helper constructs:

```text
resource/assets/bones/effect/<name>_ske.json
resource/assets/bones/effect/<name>_tex.json
resource/assets/bones/effect/<name>_tex.png
```

and feeds them through `_getURL()`.

The `_getURL()` function has behavior equivalent to:

```text
if window.wxResRoot:
    build from wxResRoot
else if Q-game resource root:
    build from that
else if window.useCrc:
    use VersionManager CRC
    apply optional mz/uc roots
else:
    add ?v=window.version

then:
if window.delayUpdateResVersion:
    replace assets/ with assets<suffix>/
    replace config folder similarly
```

This strongly suggests the custom URL transformation itself is the correct patch point.

Source citation from the previously uploaded controller report:

```text
fileciteturn96file1L8-L9
```

and:

```text
fileciteturn95file1L10-L10
```

The custom `replaceRes` structure is also visible in the controller output:

```text
fileciteturn95file2L11-L15
```

---

# 20. What NOT to do

Do not:

```text
blindly replace every CDN string in minified JS
```

Do not:

```text
replace WebSocket/server endpoints while trying to solve resources
```

Do not:

```text
assume __v_<version> belongs in public CDN URLs
```

Do not:

```text
crawl all 40,562 resources blindly
```

Do not:

```text
spend more time statically resolving the 36k unresolved entries
```

The English resource mirror is already 99.94% complete.

---

# 21. Best current architecture

The preferred end-state is:

```text
                         BROWSER / GAME
                               |
                    +----------+----------+
                    |                     |
                 HTTP(S)                 WS/WSS
                    |                     |
                    v                     v
           LOCAL RESOURCE CDN        LOCAL/REPLACEMENT
              127.0.0.1:8090            GAME SERVER
                    |                     |
                    v                     v
       ~/pokemonburst-english-mirror    :30001
```

The client should generate resource requests like:

```text
http://127.0.0.1:8090/resource/assets_en/..._<CRC>.<ext>?v=20241024736
```

while the game connection remains separately configured.

---

# 22. Future task roadmap

## Phase 8 — Client resource-controller integration

Priority: HIGH

Objectives:

1. Locate exact `MyVersionConstroller.getVirtualUrl()` implementation. **DONE.**
2. Determine the smallest patch that changes only resource HTTP URLs. **PATCH INSERTED IN WORKING JS.**
3. Preserve:
   - VersionManager CRC behavior
   - query string versioning
   - WebSocket/server URLs
   - channel logic where required.
4. Route the generated resource URL to:
   ```text
   http://127.0.0.1:8090/
   ```
5. Launch the client and monitor actual resource requests.

The key desired change is conceptually:

```text
normal final resource URL
        ↓
http://127.0.0.1:8090/<same resource path>
```

not a global string replacement.

---

## Phase 8.1 — Observe real browser requests

Use DevTools/network logging or a controlled local launch.

Goal:

Collect actual request URLs and compare:

```text
logical resource
VersionManager CRC
generated request URL
local mirror path
HTTP status
```

This can reveal any remaining transformation not yet modeled.

---

## Phase 8.2 — Handle the two remaining special English assets

Investigate:

```text
#.png
%.png
```

Possible areas:

```text URL encoding
runtime escaping
special resource-name transformation
```

Do this after normal client boot works.

---

## Phase 9 — Offline English mode

Once the client runs entirely from the local mirror:

```text
disable upstream fallback
```

and make the local CDN return a clear 404 for genuinely absent objects.

Success means:

```text
resource traffic to original CDN → zero
```

during normal operation.

---

## Phase 10 — Resource request capture / automatic reconciliation

Add request logging to the local CDN and automatically append:

```text
actual requested URL
logical path
status
local mapping
```

This lets gameplay itself discover resources that were not represented in the initial mirror.

The original Phase 5 design explicitly envisioned:

```text
first launch:
local hits + upstream misses

after playing:
cache grows

repeat launch:
more local hits
fewer upstream fetches

eventually:
upstream fetches approach zero
```

This turns real game usage into a discovery mechanism.

Reference:

```text
fileciteturn97file4L128-L147
```

---

## Phase 11 — Update/version support

The CDN build is versioned by:

```text
20241024736
```

Future work:

```text new versionAutoGen
new CRC map
new resource manifests
delta/reconciliation
```

Keep versioned mirrors separate.

Suggested structure:

```text
~/pokemonburst-mirrors/
    20241024736/
        resource/assets_en/
        resources.sqlite
        resource-report.csv
```

---

# 23. Useful commands

## Start local CDN against clean English mirror

```bash
python3 ~/pokemonburst-phase5-local-cdn/tools/phase5_local_cdn_emulator.py \
  --mirror ~/pokemonburst-english-mirror \
  --port 8090 \
  --upstream 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/'
```

## Test local mirror

```bash
curl -I \
'http://127.0.0.1:8090/resource/assets_en/bones/effect/b3004_ske_a62d73f.json?v=20241024736'
```

## Count English mirror files

```bash
find ~/pokemonburst-english-mirror/resource/assets_en \
-type f | wc -l
```

## Measure mirror size

```bash
du -sh ~/pokemonburst-english-mirror
```

## Audit Phase 7 database

```bash
sqlite3 \
~/pokemonburst-english-mirror/resources.sqlite \
'SELECT status, COUNT(*) FROM resources GROUP BY status ORDER BY COUNT(*) DESC;'
```

## Show current exceptions

```bash
sqlite3 \
~/pokemonburst-english-mirror/resources.sqlite \
"SELECT logical, crc, url, status, http_status, error
 FROM resources
 WHERE status NOT IN ('DOWNLOADED','SEEDED_FROM_CAPTURE','ALREADY_PRESENT')
 ORDER BY logical;"
```

## VersionManager entry count

```bash
python3 - <<'PY'
import re
from pathlib import Path

p = Path.home() / "Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/versionAutoGen.20241024736__v_20241024736.js"
s = p.read_text(encoding="utf-8", errors="ignore")
pairs = re.findall(r'"([^"]+)":"([0-9a-f]{7,8})"', s, re.I)

print(len(pairs))
PY
```

---

# 24. Phase package references

The previous phase packages/documentation were:

```text
PHASE1_README.md
PHASE2_README.md
PHASE2_2_README.md
PHASE3_README.md
PHASE5_README.md
PHASE6_README.md
PHASE7_README.md
```

Each phase had a corresponding tool directory under the user's home directory.

The uploaded readmes establish the intended flow and terminology.

Phase 1 reference:

```text
fileciteturn97file0L5-L8
```

Phase 2 reference:

```text
fileciteturn97file1L3-L8
```

Phase 2.2 reference:

```text
fileciteturn97file2L3-L8
```

Phase 3 reference:

```text
fileciteturn97file3L5-L12
```

Phase 5 reference:

```text
fileciteturn97file4L5-L22
```

Phase 6 reference:

```text
fileciteturn97file5L3-L12
```

Phase 7 reference:

```text
fileciteturn97file6L3-L11
```

---


# 25.1 Latest Phase 8 findings: exact controller patch point

The exact `MyVersionConstroller.getVirtualUrl()` implementation has now been located in:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js
```

The current working copy contains this newly inserted resource-routing branch:

```js
t.prototype.getVirtualUrl=function(t,o){
    var i=window.version;
    if(t&&t.indexOf("resource/assets_en/")===0){
      var _localRoot="http://127.0.0.1:8090/";
      return _localRoot+t+"?v="+i;
    }
    ...
}
```

This means the current client patch is intentionally scoped only to logical URLs beginning with:

```text
resource/assets_en/
```

The tested transformation is:

```text
resource/assets_en/bones/effect/b3004_ske.json
        ↓
http://127.0.0.1:8090/resource/assets_en/bones/effect/b3004_ske.json?v=20241024736
```

A backup of the original JS was created before modifying the working copy:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js.phase8-original
```

The active patched file is:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js
```

## Important refinement: `_getURL()` is a second resource path

The controller investigation also found another helper named `_getURL()` in the loading/update code. It independently constructs resource URLs and performs CRC insertion.

Its relevant behavior is approximately:

```text
if wx/qgame root exists:
    use that root

else if useCrc:
    look up VersionManager[e]
    insert "_" + CRC before extension
    apply optional Meizu / UC root

else:
    append ?v=window.version

then optionally:
    apply delayUpdateResVersion
```

Therefore, the new `getVirtualUrl()` branch should cover normal `RES` requests, but `_getURL()` must still be observed during startup because some loading/UI resources may use that helper directly.

Do not assume the first patch covers every request until actual client network traffic confirms it.

## Current Phase 8 working-copy state

```text
[PATCHED]
MyVersionConstroller.getVirtualUrl()
    resource/assets_en/* → http://127.0.0.1:8090/resource/assets_en/*?v=version

[BACKUP]
main.min_59e25df4__v_20241024736.js.phase8-original

[PROVEN]
local CDN serves:
    b3004_ske_a62d73f.json → HTTP 200
    Content-Length: 4984

[PROVEN]
English mirror:
    3,296 files
    ~50 MB
    3,296 / 3,298 English VersionManager candidates represented

[KNOWN REMAINING]
#.png → HTTP 403
%.png → HTTP 400
```

## Immediate next test after the patch

Do not start the replacement game server merely to test resource routing.

Start the local CDN:

```bash
python3 ~/pokemonburst-phase5-local-cdn/tools/phase5_local_cdn_emulator.py \
  --mirror ~/pokemonburst-english-mirror \
  --port 8090 \
  --upstream 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/'
```

Then launch the client from the patched working tree.

Monitor the CDN emulator output. The first objective is to see requests such as:

```text
GET /resource/assets_en/...
```

arriving on port 8090.

If requests still go to `cdn.xjlgmkk.com`, investigate `_getURL()`, `UserCfg.getTranslateRes()`, or a later URL/root transformation rather than globally replacing CDN strings.

If requests arrive on 8090 and normal loading proceeds, resource routing is working and the remaining failures can be separated into:

```text
resource HTTP
vs.
game/login WebSocket
```

Only after resource routing is confirmed should `:30001` be brought into the test.

## Exact evidence from controller search

The controller search located:

```text
t.prototype.getVirtualUrl=function(t,o)
```

and the `_getURL()` helper with:

```text
window.useCrc
window.VersionManager
window.version
window.wxResRoot
window.ucResRoot
window.vivoResRoot
window.huaweiResRoot
window.oppoResRoot
window.delayUpdateResVersion
```

The custom controller is instantiated during launch and registered with `RES`:

```text
new e.MyVersionConstroller
RES.registerVersionController(e.Constroller)
```

This remains the preferred architectural choke point for resource URL routing.

---


# 25. Current state at handoff

```text
[COMPLETE]
VersionManager parsed                40,562
English candidates                    3,298
English mirror successful             3,296
English mirror physical files         3,296
Mirror size                            ~50 MB

[PROVEN]
Public English CDN naming rule        YES
100/100 Phase 6 CDN sample            YES
b3004 four-file bundle                YES
Local CDN exact serving               YES
Local CDN relocated serving           YES
Resumable English downloader          YES

[CURRENT]
Client resource-root/controller patch IN PROGRESS
Game server integration               NOT YET THE RESOURCE BLOCKER

[KNOWN EXCEPTIONS]
#.png                                  HTTP 403
%.png                                  HTTP 400
```

---

# 26. The next AI should do this first

Do NOT restart Phase 1.

Do NOT rerun Phase 6.

Do NOT redownload English resources.

Start from:

```text
~/pokemonburst-english-mirror/
```

and investigate the exact `MyVersionConstroller.getVirtualUrl()` implementation in:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js
```

The target is a minimal resource-URL patch so the game uses:

```text
http://127.0.0.1:8090/
```

for its resource origin while leaving the game server connection separate.

The custom controller is the most promising choke point.

Once that patch works:

```text
launch client
→ watch local CDN logs
→ confirm HTTP resource traffic appears on :8090
→ then start / connect :30001
→ resolve remaining runtime issues
```

The project has moved from "Can we discover the CDN?" to "Can we make the client consume the mirror?"

That is the current frontier.


---

# 27. Latest continuation status

The CDN/resource acquisition side is no longer the main uncertainty.

The current client working copy now contains a targeted resource-origin patch:

```text
resource/assets_en/*
        ↓
MyVersionConstroller.getVirtualUrl()
        ↓
http://127.0.0.1:8090/resource/assets_en/*?v=20241024736
```

The next required evidence is actual client network traffic.

The most useful next artifact is a startup request log showing:

```text
timestamp
request path
HTTP status
resource URL
```

from the local CDN emulator during a real client launch.

Do not restart the large-scale VersionManager/CDN discovery phases unless the client proves to request resources outside the recovered English mirror.

The project is now in **runtime integration / observation mode**.

# 28. Latest Phase 8 continuation: corrected public URL rule and controller routing

## 28.1 Public CDN URL rule is now experimentally validated

The public English CDN naming rule was verified on a 100-resource Phase 6 sample with:

```text
HTTP_200   100
HTTP_404     0
HTTP_OTHER  0
NETWORK     0
```

The verified public form is:

```text
https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/
resource/assets_en/<logical-dir>/<basename>_<CRC>.<extension>?v=20241024736
```

This differs from the local capture filename convention, which may contain:

```text
_<CRC>__v_<version>
```

The `__v_<version>` portion must not be assumed to belong in the public CDN filename.

## 28.2 Complete b3004 bundle proof

The following four English resources all returned HTTP 200 directly from the public CDN:

```text
resource/assets_en/bones/effect/b3004_ske_81a1dfbc.dbbin?v=20241024736
resource/assets_en/bones/effect/b3004_ske_a62d73f.json?v=20241024736
resource/assets_en/bones/effect/b3004_tex_773ad33a.json?v=20241024736
resource/assets_en/bones/effect/b3004_tex_fb984669.png?v=20241024736
```

Known response sizes:

```text
b3004_ske.dbbin : 3292 bytes
b3004_ske.json  : 4984 bytes
b3004_tex.json  :  810 bytes
b3004_tex.png   : 36609 bytes
```

This bundle was especially useful because the local capture originally lacked the skeleton JSON while related files existed.

## 28.3 English mirror completion status

Phase 7 processed the full English VersionManager asset candidate set:

```text
English candidates         3,298
Downloaded                 2,703
Seeded from capture          573
Already present               20
HTTP 403                       1
Other error                    1
```

Therefore:

```text
Successfully represented: 3,296 / 3,298
Coverage: approximately 99.94%
Physical files: 3,296
Disk usage: approximately 50 MB
```

Mirror:

```text
~/pokemonburst-english-mirror/
```

Main bookkeeping files:

```text
~/pokemonburst-english-mirror/resources.sqlite
~/pokemonburst-english-mirror/resource-report.csv
```

Remaining exceptions:

```text
resource/assets_en/gameui/1_fight/float/float_font/#.png
CRC a4a1e6be
HTTP 403

resource/assets_en/gameui/1_fight/float/float_font/%.png
CRC 24056c13
HTTP 400
```

These two should not block normal client integration.

## 28.4 Local CDN is proven against the clean mirror

The local CDN emulator has been run against:

```text
~/pokemonburst-english-mirror
```

on port `8090`.

Known-good test:

```bash
curl -I \
'http://127.0.0.1:8090/resource/assets_en/bones/effect/b3004_ske_a62d73f.json?v=20241024736'
```

Expected/observed:

```text
HTTP/1.0 200 OK
Content-Type: application/json
Content-Length: 4984
Access-Control-Allow-Origin: *
Cache-Control: public, max-age=315360000
```

This demonstrates that the clean mirror can serve an object using the public URL form.

## 28.5 Exact runtime choke point found

The game creates and registers its custom controller during startup:

```text
new e.MyVersionConstroller
RES.registerVersionController(e.Constroller)
```

The custom controller implements `getVirtualUrl()`.

The discovered controller logic has the important structure:

```text
getVirtualUrl(t, o)
    ↓
if resource/assets_en/*
    ↓
VersionManager[logical resource]
    ↓
insert _<CRC> before extension
    ↓
return resource URL
```

The controller also has `getChannelRes()` and a large `replaceRes` table for classes of resources including `bones`, `bonesImg`, `gameui`, and `icon`.

The relevant evidence is in the uploaded controller search output:

```text
fileciteturn97file0L5-L13
```

The search output also shows the custom controller being registered as an Egret/RES version controller.

## 28.6 Current client patch

A targeted branch has been inserted into the working `getVirtualUrl()` implementation so that English assets are routed to the local CDN:

```js
if(t&&t.indexOf("resource/assets_en/")===0){
    var _localRoot="http://127.0.0.1:8090/";
    return _localRoot+t+"?v="+i;
}
```

Intended result:

```text
resource/assets_en/bones/effect/b3004_ske.json
        ↓
http://127.0.0.1:8090/resource/assets_en/bones/effect/b3004_ske.json?v=20241024736
```

The patch is deliberately scoped to `resource/assets_en/` and does not intentionally modify server/WebSocket URLs.

A backup of the original JS was created before patching:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js.phase8-original
```

Active working file:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js
```

## 28.7 Important second URL path: `_getURL()`

The same controller investigation found a separate loading helper named `_getURL()`.

It constructs resources such as:

```text
resource/assets/bones/effect/<name>_ske.json
resource/assets/bones/effect/<name>_tex.json
resource/assets/bones/effect/<name>_tex.png
```

and independently handles:

```text
window.useCrc
window.VersionManager
window.version
window.wxResRoot
window.ucResRoot
window.vivoResRoot
window.huaweiResRoot
window.oppoResRoot
window.delayUpdateResVersion
```

Therefore the `getVirtualUrl()` patch must be validated with real browser/network traffic. Some startup/UI resources may bypass it through `_getURL()`.

The discovered `_getURL()` implementation is visible in the controller report, including its CRC insertion and resource-root branches:

```text
fileciteturn96file1L8-L9
```

## 28.8 Current runtime test procedure

Start only the local resource CDN first:

```bash
python3 ~/pokemonburst-phase5-local-cdn/tools/phase5_local_cdn_emulator.py \
  --mirror ~/pokemonburst-english-mirror \
  --port 8090 \
  --upstream 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/'
```

Do not start the replacement game server merely to test resource routing.

Then launch the patched client.

The first evidence to collect is the local CDN console showing requests such as:

```text
GET /resource/assets_en/...
```

or equivalent local traffic.

Interpretation:

```text
Requests to 127.0.0.1:8090
    => resource routing patch is active

Requests still going to cdn.xjlgmkk.com
    => another resource URL path still bypasses getVirtualUrl()
```

If resource requests are local but gameplay/login fails later, treat that separately as a game/login WebSocket issue.

## 28.9 Current architecture

```text
                         GAME CLIENT
                             |
                 +-----------+-----------+
                 |                       |
              HTTP(S)                 WS/WSS
                 |                       |
                 v                       v
        LOCAL RESOURCE CDN        LOCAL / REPLACEMENT
          127.0.0.1:8090              GAME SERVER
                 |                       |
                 v                       v
   ~/pokemonburst-english-mirror     :30001
```

The two channels should remain logically independent.

## 28.10 Current project status

```text
[COMPLETE]
VersionManager parsing                 40,562
English VersionManager candidates       3,298
English mirror                          3,296 files
English mirror coverage                 ~99.94%
Public CDN naming rule                  validated
Phase 6 sample                          100/100 HTTP 200
Phase 7 bulk acquisition                completed
Local CDN                               serving mirror

[IN PROGRESS]
Phase 8 client resource integration

[KNOWN]
getVirtualUrl() choke point              located
English resource routing patch           inserted
_getURL() secondary path                 located

[NOT YET REQUIRED FOR RESOURCE TEST]
Replacement game server :30001

[REMAINING CDN EXCEPTIONS]
#.png                                     HTTP 403
%.png                                     HTTP 400
```

## 28.11 Next action for the next AI/chat

Do not restart the discovery phases.

Do not redownload the English mirror.

The next task is to launch the patched client while the local CDN is running and observe whether actual English resource requests hit port `8090`.

If local requests appear, continue by resolving only the resources that still bypass the patch.

If no local requests appear, inspect `_getURL()` and any later resource-root transformation rather than making a global CDN-string replacement.

Once HTTP resource traffic is confirmed locally, only then proceed to the game/login server side.


# 29. Latest verified Phase 8 state (2026-08-29)

## 29.1 Phase 7 mirror is complete enough for runtime work

The English acquisition phase is finished for practical purposes:

```text
VersionManager English candidates : 3,298
DOWNLOADED                       : 2,703
SEEDED_FROM_CAPTURE              :   573
ALREADY_PRESENT                  :    20
HTTP_403                         :     1
ERROR                            :     1
Successful representation        : 3,296 / 3,298
Physical mirror files            : 3,296
Mirror size                      : ~50 MB
```

Mirror:

```text
~/pokemonburst-english-mirror/
```

The two remaining resources are:

```text
resource/assets_en/gameui/1_fight/float/float_font/#.png
    CRC a4a1e6be
    HTTP 403

resource/assets_en/gameui/1_fight/float/float_font/%.png
    CRC 24056c13
    HTTP 400
```

These are not currently blocking normal resource integration.

## 29.2 The public CDN URL transformation is experimentally established

The public English CDN accepts the CRC filename form without the local `__v_<version>` suffix:

```text
resource/assets_en/<dir>/<basename>_<CRC>.<ext>?v=20241024736
```

A 100-resource Phase 6 sample produced 100/100 HTTP 200 responses after correcting the verifier's accidental removal of the `resource/` prefix.

The complete `b3004` DragonBones bundle was also independently verified with HTTP 200 for its `.dbbin`, skeleton JSON, texture JSON, and PNG objects.

## 29.3 Exact runtime URL code discovered

The current client uses an Egret/RES resource pipeline and registers a custom controller during startup:

```text
new e.MyVersionConstroller
RES.registerVersionController(e.Constroller)
```

The controller exposes `getVirtualUrl()`. The supplied controller investigation also found a separate `_getURL()` helper used by other loading paths.

The relevant `_getURL()` behavior includes:

```text
window.wxResRoot
window.vivoResRoot / window.huaweiResRoot / window.oppoResRoot
window.useCrc
window.VersionManager
window.version
window.ucResRoot
window.delayUpdateResVersion
```

It inserts the VersionManager CRC before the extension and then applies root/channel transformations.

The controller report also contains the large `replaceRes` table for `bones`, `bonesImg`, `gameui`, `icon`, and other resource classes.

Evidence source:

```text
fileciteturn96file1L8-L9
fileciteturn95file2L11-L15
```

## 29.4 Current targeted client patch

The working copy of:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js
```

contains a targeted `getVirtualUrl()` branch intended to route only English asset requests to the local resource server:

```js
if(t && t.indexOf("resource/assets_en/") === 0){
    var _localRoot = "http://127.0.0.1:8090/";
    return _localRoot + t + "?v=" + i;
}
```

Intended transformation:

```text
resource/assets_en/bones/effect/b3004_ske.json
        ↓
http://127.0.0.1:8090/resource/assets_en/bones/effect/b3004_ske.json?v=20241024736
```

Original backup:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js.phase8-original
```

Important: this patch is a working-copy experiment. It is not yet considered proven until real browser/client traffic is observed on port 8090.

## 29.5 Local CDN against clean mirror is proven

The emulator was run against:

```text
~/pokemonburst-english-mirror
```

Port:

```text
8090
```

Known-good request:

```bash
curl -I \
'http://127.0.0.1:8090/resource/assets_en/bones/effect/b3004_ske_a62d73f.json?v=20241024736'
```

Observed:

```text
HTTP/1.0 200 OK
Content-Type: application/json
Content-Length: 4984
Access-Control-Allow-Origin: *
Cache-Control: public, max-age=315360000
```

Therefore the local mirror and local HTTP server are ready for client integration testing.

## 29.6 Resource and game-server channels remain separate

Do not start or modify the replacement game server merely to test HTTP resource routing.

The intended architecture remains:

```text
GAME CLIENT
   |
   +---- HTTP resource requests ---> 127.0.0.1:8090
   |
   +---- WS/WSS game/login -------> local/replacement server :30001
```

The resource test should be performed first with only the local CDN running.

## 29.7 Immediate next action

1. Start the local CDN against the clean English mirror:

```bash
python3 ~/pokemonburst-phase5-local-cdn/tools/phase5_local_cdn_emulator.py \
  --mirror ~/pokemonburst-english-mirror \
  --port 8090 \
  --upstream 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/'
```

2. Launch the patched client.

3. Watch the CDN emulator console and/or browser DevTools Network panel.

4. Confirm whether real requests appear as:

```text
GET /resource/assets_en/...
```

against `127.0.0.1:8090`.

5. If local HTTP requests appear, keep the resource work focused on remaining bypasses.

6. If requests still go to the original CDN, inspect `_getURL()` and other direct loaders rather than performing a global URL replacement.

7. Only after HTTP resource routing is confirmed should the `:30001` server be brought into the test.

## 29.8 What the next AI should NOT repeat

```text
Do NOT restart Phase 1 discovery.
Do NOT rerun Phase 2/2.1/2.2 reconciliation.
Do NOT rerun Phase 3 master reconciliation.
Do NOT redownload the 3,298 English assets.
Do NOT rerun the 100-file CDN naming verifier unless the URL rule itself changes.
Do NOT globally replace cdn.xjlgmkk.com in minified JS.
```

The project has already moved beyond CDN discovery. The remaining problem is runtime consumption of the completed local English mirror.

## 29.9 Current evidence hierarchy

```text
PROVEN
  VersionManager inventory                  40,562
  English candidate set                    3,298
  Public English CDN naming rule            YES
  100/100 Phase 6 sample                   YES
  b3004 four-file CDN bundle               YES
  Phase 7 mirror                           3,296 files
  Local CDN mirror serving                 YES

IN PROGRESS
  Client -> 127.0.0.1:8090 resource routing

NOT YET TESTED IN THIS PHASE
  Full client startup with patched resource routing
  Complete offline mode
  Replacement game server integration
```

## 29.10 Latest controller evidence

The controller investigation confirms that the custom controller is registered before the main resource loading starts, and the game has a separate helper that constructs URLs using the VersionManager and resource-root variables. fileciteturn95file1L10-L10 fileciteturn96file1L8-L9

The newly uploaded controller search artifact used for this handoff is:

```text
~/pokemonburst-phase8-version-controller.txt
```

The next AI/chat can therefore begin directly with the runtime test instead of repeating static URL discovery.


---

# 30. Latest progress update — 2026-09-01

This section records the latest evidence supplied after the original Phase 8 handoff.

## 30.1 New controller search evidence

A new search artifact was supplied containing the relevant minified controller code from:

```text
$ROOT/js/main.min_59e25df4__v_20241024736.js
```

The extracted `_getURL()` logic confirms the following sequence in the original client:

```text
getChannelRes()
    ↓
UserCfg.getTranslateRes()
    ↓
if window.useCrc:
    VersionManager lookup
    ↓
    insert "_" + CRC before extension
    ↓
    add ?v=<version>
    ↓
    ConfusionsManager lookup
    ↓
    channel-specific resource-root handling
else:
    platform/resource-root handling
```

The same search also confirms that the client has a separate `.phase8-original` backup and a `.phase8-backup` copy of the JS file.

## 30.2 Important implication for the Phase 8 patch

The newly supplied evidence reinforces that `getVirtualUrl()` / `_getURL()` is the correct architectural interception point.

The client does not simply store one universal CDN string and concatenate paths everywhere. Resource URLs are assembled dynamically from:

```text
logical resource path
VersionManager CRC
version query parameter
ConfusionsManager
platform/channel resource roots
```

Therefore the local redirect should remain narrowly scoped to the English resource namespace:

```text
resource/assets_en/
```

and should preserve the remainder of the generated URL semantics.

## 30.3 Current patch status

The working-copy patch documented in Section 29.4 remains:

```js
if(t && t.indexOf("resource/assets_en/") === 0){
    var _localRoot = "http://127.0.0.1:8090/";
    return _localRoot + t + "?v=" + i;
}
```

Target:

```text
resource/assets_en/<path>
        ↓
http://127.0.0.1:8090/resource/assets_en/<path>?v=20241024736
```

This is still an experimental runtime patch.

It has NOT yet been promoted to "proven client integration" because the decisive test is observing actual browser/client resource requests reaching:

```text
127.0.0.1:8090
```

## 30.4 Latest evidence status

```text
PROVEN
  VersionManager inventory                  40,562
  English candidate set                    3,298
  Public English CDN naming rule            YES
  Phase 6 CDN sample                        100/100 HTTP 200
  Phase 7 English mirror                    3,296 files
  English mirror representation             99.94%
  Local CDN emulator                        WORKING
  Local b3004 resource request              HTTP 200
  Runtime URL construction point            CONFIRMED

NOT YET PROVEN
  Patched client -> 127.0.0.1:8090
  Full client startup using local resources
  Zero upstream resource traffic
  Offline English mode
  Replacement WebSocket/game server integration
```

## 30.5 Immediate next test

Run only the local resource server first:

```bash
python3 ~/pokemonburst-phase5-local-cdn/tools/phase5_local_cdn_emulator.py \
  --mirror ~/pokemonburst-english-mirror \
  --port 8090 \
  --upstream 'https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/'
```

Then launch the patched client and observe:

```text
DevTools → Network
```

and/or the local CDN emulator log.

Expected evidence:

```text
GET /resource/assets_en/...
Host: 127.0.0.1:8090
```

If that happens, Phase 8 has crossed the important boundary from static code analysis into verified runtime resource routing.

If it does not happen, do not globally replace the CDN domain. Instead inspect the remaining URL-generation/direct-loader paths.

## 30.6 Special-character assets remain deferred

The two English assets that previously failed the Phase 7 mirror remain:

```text
resource/assets_en/gameui/1_fight/float/float_font/#.png
resource/assets_en/gameui/1_fight/float/float_font/%.png
```

with:

```text
#.png -> CRC a4a1e6be -> HTTP 403
%.png -> CRC 24056c13 -> HTTP 400
```

These should be investigated only after ordinary client resource routing works.

Likely investigation areas remain:

```text
URL encoding
runtime escaping
special resource-name transformation
ConfusionsManager/resource-name rewriting
```

They must not block the first local-boot test.

## 30.7 Current project position

The project is now firmly in:

```text
PHASE 8
Client resource-controller integration
        ↓
NEXT
Real client/network observation
        ↓
THEN
Offline English resource mode
        ↓
THEN
Game WebSocket/server integration
```

The CDN/resource-discovery work is considered complete enough for runtime testing.

The next useful evidence is no longer another static inventory. It is an actual request trace from the patched client.


---

# 31. Latest supporting artifact: `loading.min` resource-controller evidence

This section records the newly supplied `pokemonburst-confusions-window.txt` artifact so the handoff retains the relevant runtime evidence instead of losing it between chats.

## 31.1 Source file

The supplied artifact points to:

```text
/home/ryure/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/js/loading.min_970e4440__v_20241024736.js
```

The file contains the game's loading-layer implementation and an independent `VersionController`.

## 31.2 Loading controller registration

During construction of `LoadingCls`, the client creates a `VersionController` and registers it with Egret/RES:

```js
_this._controller = new VersionController;
RES.registerVersionController(_this._controller);
```

This is important because it proves that the loading subsystem itself participates in the same URL-transformation architecture.

## 31.3 Loading assets that pass through `getVirtualUrl()`

The loading screen defines resources such as:

```text
resource/assets/gameui/0_login/loginBg.jpg
resource/assets/gameui/0_login/bar_LoginPanel_0002.png
resource/assets/gameui/0_login/bar_LoginPanel_0001.png
resource/assets/gameui/0_login/word_login_0001.png
resource/assets/gameui/0_login/home_btn_qlhc.png
```

The loading image helper calls:

```js
this._controller.getVirtualUrl(url)
```

before creating the image resource.

Therefore, `getVirtualUrl()` is not only a theoretical game-resource choke point. The startup/loading UI demonstrably invokes it.

## 31.4 Loading DragonBones resources

The loading screen also constructs DragonBones resource paths dynamically:

```text
resource/assets/bones/effect/<name>_ske.json
resource/assets/bones/effect/<name>_tex.json
resource/assets/bones/effect/<name>_tex.png
```

These are passed through the same controller path.

The loader then:

1. requests the skeleton JSON,
2. requests the texture-atlas JSON,
3. requests the texture PNG,
4. parses the DragonBones skeleton,
5. builds the armature,
6. adds it to the DragonBones world clock,
7. plays the animation.

This is especially relevant to the previously verified `b3004` bundle.

## 31.5 `_getJson()` also routes JSON through the controller

The loading implementation contains:

```js
url = url && url.indexOf("json") > 0
    ? this._controller.getVirtualUrl(url)
    : url;
```

It then performs an Egret `HttpRequest` with `GET`.

The loader has retry behavior:

```text
default retry count: 3
request timeout: 12 seconds
retry on JSON parse failure
retry on IO error
```

This means startup JSON requests can be observed independently of normal `RES` asset requests, and a failed local resource can generate repeated traffic.

## 31.6 The loading file contains a second `VersionController` implementation

The supplied artifact also exposes:

```js
VersionController.prototype.getVirtualUrl=function(url,root){
    var version=window["version"];
    ...
}
```

Its behavior is materially important:

```text
if window.useCrc:
    if window.VersionManager[url]:
        insert "_" + CRC before extension
    else:
        append ?v=<version>

    if window.ConfusionsManager:
        replace URL using ConfusionsManager[url]

    if window.mz:
        apply Meizu resource root

    else if window.uc:
        apply UC resource root

else:
    use platform-specific resource root when available
    otherwise append ?v=<version>

finally:
    optionally apply delayUpdateResVersion
```

The exact variables visible in this implementation include:

```text
window.version
window.useCrc
window.VersionManager
window.ConfusionsManager
window.mz
window.uc
window.ucResRoot
window.vivoResRoot
window.huaweiResRoot
window.oppoResRoot
window.youkuResRoot
window.douyinResRoot
window.wxResRoot
window.delayUpdateResVersion
window.configFolder
```

## 31.7 Important distinction: there are multiple controller contexts

The newly supplied loading artifact uses:

```text
VersionController
```

while the main game bundle investigation identified:

```text
MyVersionConstroller
```

and the main game's controller is registered with:

```text
RES.registerVersionController(...)
```

Therefore, the project should not assume that patching one minified JS file automatically covers every resource request.

The current evidence supports this model:

```text
                 GAME CLIENT
                     |
          +----------+----------+
          |                     |
      Main game RES          Loading layer
          |                     |
 MyVersionConstroller       VersionController
          |                     |
          +----------+----------+
                     |
             URL transformation
                     |
          resource HTTP request
```

The next runtime test must determine which controller handles each observed request.

## 31.8 `ConfusionsManager` is a real URL-rewriting stage

The supplied loading artifact contains:

```js
if(window["ConfusionsManager"]){
    var confusion_url=window["ConfusionsManager"][url];
    url=confusion_url||url;
}
```

This confirms that `ConfusionsManager` is not merely an unused data object. It actively participates in URL resolution.

This has two consequences:

1. A logical resource name may be rewritten before the final HTTP URL is produced.
2. A local redirect should be placed carefully so it does not accidentally bypass required resource-name rewriting.

For the English local mirror, the preferred strategy remains to preserve the logical path and redirect the final English resource origin rather than globally replacing arbitrary CDN strings.

## 31.9 Channel/platform resource roots are conditional

The loading controller explicitly checks platform/channel-specific roots.

Examples visible in the code include:

```text
Meizu
UC
Vivo
Huawei
Oppo
Youku
Douyin
WeChat
```

The logic generally distinguishes:

```text
useCrc == true
```

from:

```text
useCrc == false
```

and may choose a platform resource root before adding the version query.

Therefore:

```text
resource URL construction
```

and:

```text
game/login server selection
```

must continue to be treated as separate systems.

## 31.10 State/error telemetry is also separate

The loading artifact contains startup state/error reporting using endpoints resembling:

```text
https://mon-baiz-5.ipyaoguai.com:30098/
https://mon-baiz-5.ipyaoguai.com:30099/error
```

The code sends state markers such as:

```text
engine_load
login_bg_load
source_load
```

and can POST error information.

These telemetry endpoints are not resource CDN endpoints and should not be conflated with the local resource-server test.

The immediate Phase 8 goal remains resource traffic only.

## 31.11 Exact implication for the current patch

The existing experimental branch:

```js
if(t && t.indexOf("resource/assets_en/") === 0){
    var _localRoot = "http://127.0.0.1:8090/";
    return _localRoot + t + "?v=" + i;
}
```

is intentionally narrow.

However, the new loading evidence means the following must be checked during runtime:

```text
A. Main RES resources
   -> MyVersionConstroller.getVirtualUrl()

B. Loading JSON/resources
   -> VersionController.getVirtualUrl()

C. Other direct loaders
   -> possible direct URL construction

D. ConfusionsManager
   -> logical URL rewrite before/around final URL construction

E. Platform/channel roots
   -> conditional final-origin changes
```

Do not declare the patch complete until actual network traffic confirms which paths are being used.

## 31.12 New recommended runtime logging matrix

During the first patched-client launch, record at minimum:

```text
timestamp
controller/path if inferable
logical URL
VersionManager CRC if applicable
ConfusionsManager result if applicable
final URL
host
path
query string
HTTP status
local/remote
resource type
```

A compact interpretation table:

| Observation | Meaning |
|---|---|
| `127.0.0.1:8090/resource/assets_en/...` | Local English routing is active |
| Original CDN for `assets_en` | A resource path bypassed the patched controller |
| Original CDN with a transformed path | Inspect `ConfusionsManager`, channel roots, or `_getURL()` |
| Local 8090 requests followed by successful loading | Resource path is functioning |
| Local 8090 requests but loading retries | Check filename/CRC/path mapping and response body |
| Resource loading succeeds but login fails | Treat as separate WS/WSS/server issue |
| Telemetry requests remain remote | Expected unless telemetry is separately redirected |

## 31.13 Updated immediate test sequence

Use this order:

```text
1. Start only the local CDN on :8090
        |
2. Launch the patched client
        |
3. Watch local CDN logs / DevTools Network
        |
4. Record first resource requests
        |
5. Determine whether requests use:
       - main controller
       - loading controller
       - direct loader
        |
6. Fix only the bypassing resource path(s)
        |
7. Confirm normal English resource loading
        |
8. Only then test offline/no-upstream mode
        |
9. Only after HTTP resources are stable, test :30001
```

## 31.14 New evidence does not change the completed phases

The newly supplied `loading.min` artifact strengthens the controller findings but does not invalidate earlier results.

Still considered complete:

```text
VersionManager inventory                 40,562
English candidates                         3,298
English mirror files                       3,296
English representation                     ~99.94%
Public CDN naming rule                     validated
Phase 6 sample                             100/100 HTTP 200
Local CDN emulator                         working
Local b3004 request                        HTTP 200
```

Still in progress:

```text
Patched client -> local resource CDN
Full client startup with local resources
Offline English mode
```

Still separate/not yet required for HTTP-resource validation:

```text
Replacement game/login server :30001
```

Still deferred:

```text
#.png  -> HTTP 403
%.png  -> HTTP 400
```

## 31.15 Source artifact integrity note

The supplied `pokemonburst-confusions-window.txt` is a one-line extracted representation of the original `loading.min_970e4440__v_20241024736.js`. It should be retained with the project handoff because it captures the concrete loading-layer implementation that was used to establish the secondary `VersionController` path.

The current handoff should therefore be read as:

```text
Phase 1-7: resource discovery/acquisition complete enough
Phase 8: controller-level runtime integration
             |
             +-- main MyVersionConstroller path
             |
             +-- loading VersionController path
             |
             +-- observe actual network traffic
```

---

# 32. Consolidated current state

As of 2026-09-01, the project is no longer primarily a CDN-discovery problem.

The strongest current conclusion is:

```text
The English resource corpus has been recovered to practical completeness.
The local CDN works.
The public CDN naming rule is experimentally verified.
The client has identifiable URL-controller choke points.
The remaining uncertainty is which controller/direct-loader path
produces each real startup request.
```

The next decisive artifact should be a real startup network/request trace from the patched client.

Do not restart the earlier discovery phases unless that trace demonstrates that the client requests a resource family not represented by the current English mirror.

---

# 35. CONSOLIDATED CURRENT STATE + ANTI-HALLUCINATION CONTRACT (2026-09-14)

This section supersedes older contradictory status notes where they conflict with later verified evidence.

## 35.1 Authoritative objective

Rebuild a locally runnable version of the recovered 2024 Pokémon Burst / Monster H5 client and the minimum web/server ecosystem it actually requires.

Target client:

```text
20241024736
```

This is the actual recovered game ecosystem, not a generic English CDN. The captured repository contains:

```text
h5sdk.camjm.space
cdn.xjlgmkk.com
api.camjm.space
game3.xjlgmkk.com
mjzkstatic.zkmaiji.com
www.paypal.com
```

Do not assume every host needs a complete implementation. Reproduce only routes actually exercised by the client, based on evidence.

## 35.2 Hard user constraints

```text
1. Use the actual recovered/extracted assets.
2. Do not silently substitute an unrelated/generic CDN.
3. Current chosen base:
   /mnt/data/PokemonBurst-local-server-v2.20-h5sdk-real-root-local-stack-fixed(2).zip
4. DO NOT TOUCH nginx/ in that base.
5. Do not silently switch to v2.20.4 or another base.
6. Preserve existing working implementations unless evidence requires a change.
7. Prefer small, reversible changes.
8. Never present an inference as a verified fact.
9. Never invent a protocol response, server behavior, request order, endpoint, or asset mapping.
10. Never declare success from transport-level evidence alone.
11. Use real browser/client traces as the primary guide for runtime protocol reconstruction.
12. Keep resource HTTP, H5SDK/API, game WebSocket, telemetry, and payment/SDK services separate.
```

## 35.3 Current local topology

```text
8080   recovered game/client container HTTP
8090   local resource CDN / Nginx
8081   local H5SDK web/API bootstrap service
30001  replacement game/login WebSocket
30004  optional game3 endpoint; semantics not fully proven
30098  local stateMark / compatibility telemetry HTTP
30099  local error telemetry HTTP
```

Do not collapse these services without evidence.

## 35.4 Authoritative protocol inventory

```text
opcodes.json   = 1,385 entries
types.json     =   650 named types
packetcfg.json = 2,035 combined entries
```

`1,386` is an obsolete documentation error and must not be repeated as the authoritative opcode count.

Framing:

```text
uint32 BE packet length
uint16 BE opcode
uint8  stamp
payload
```

Strings are UTF-8 with a big-endian uint16 byte-length prefix.

Known schemas include:

```text
2001 ACCOUNT_LOGIN
2002 server-list path
2004 SERVER_CHOOSE
3001 GAME_LOGIN
3003 SERVER_LOAD_SUCCESS
3004 CLIENT_LOAD_SUCCESS
3005 SERVER_TIME_INFO
3011 SERVER_PUSH_FINISH
3017 LANG_CHANGE
3999 HEARTBEAT
```

The exact field schemas are already preserved in the protocol JSON and must be consulted rather than recreated from memory.

## 35.5 REAL browser login frontier

The real browser has now produced:

```text
2001 ACCOUNT_LOGIN
2005 LOGIN_NOTICE_LIST
2020 acc_config_list
2004 SERVER_CHOOSE
client closes/reconnects
```

This is authoritative runtime evidence.

Do NOT assume the older synthetic sequence:

```text
2001 -> 2002 -> 2004 -> 3001
```

is the production order.

Exact observed 2004 request:

```text
0000000b 07d4 0400000001
```

Decode:

```text
length    = 11
opcode    = 2004
stamp     = 4
server_id = 1
```

Current unresolved boundary:

```text
2004 response
    ↓
client accepts response
    ↓
expected 3001 GAME_LOGIN
```

A structurally valid 2004 response is NOT proof that the browser accepted it.

## 35.6 2005 and 2020

Both are real browser requests with empty observed payloads.

Current status:

```text
2005 request observed       YES
2005 exact response         NOT PROVEN

2020 request observed       YES
2020 exact response         NOT PROVEN
```

Do not invent large response objects to force progress.

Correct method:

```text
observe request
→ determine minimum required response
→ send it
→ observe next client state
```

## 35.7 H5SDK evidence

Decoded SDK configuration:

```json
{
  "SDK_URL": "",
  "APIK": "qOsvWAGZ7Qc8gUjo"
}
```

The signing algorithm was reconstructed and generated the exact browser signature:

```text
f861df6ddc7fc7dfaf1cf700a3f6dc6e
```

Therefore signing is not the known blocker.

Recovered SDK endpoints include:

```text
h5User/login
h5User/fcmIfOpen
h5User/randomAccount
h5User/reg
h5User/role
h5User/logout
h5Game/active
h5Game/announcement
h5Tool/language
sdkControl/replacement
```

The original SDK uses `mjsdkapi://` and H5 `postMessage` communication.

The local H5 parent bridge is functioning sufficiently for investigation. Observed console evidence included:

```text
[LOCAL H5] parent bridge installed
[LOCAL H5] mjlogin message
[LOCAL H5] sending login response
初始化返回数据 {uid: '103184345', code: 'local-test-code'}
```

`103184345` is a local test identity, not a production account.

## 35.8 GitHub repository correction

Correct current repository:

```text
alonesitegamer/h5sdk
```

Do not revert to the old:

```text
alonesitegamer/over-power-champion-quest
```

The repository preserves multiple original host buckets, but host presence alone does not prove a route is needed for first boot.

## 35.9 Resource recovery status

English VersionManager candidates:

```text
3,298
```

Phase 7:

```text
DOWNLOADED             2,703
SEEDED_FROM_CAPTURE      573
ALREADY_PRESENT           20
HTTP_403                   1
ERROR                      1
```

Successfully represented:

```text
3,296 / 3,298
~99.94%
```

Known exceptions:

```text
#.png -> CRC a4a1e6be -> HTTP 403
%.png -> CRC 24056c13 -> HTTP 400
```

Do not let these two unrelated exceptions derail protocol reconstruction.

Public CDN naming was experimentally verified:

```text
resource/assets_en/<logical-dir>/<basename>_<CRC>.<ext>?v=20241024736
```

Do not add the local capture suffix:

```text
__v_20241024736
```

to public CDN URLs unless direct evidence requires it.

## 35.10 Resource controller evidence

The client uses Egret/RES and registers controller(s) including:

```text
MyVersionConstroller
VersionController
```

The loading layer calls `getVirtualUrl()`, and another `_getURL()` path independently constructs URLs.

Relevant variables include:

```text
window.version
window.useCrc
window.VersionManager
window.ConfusionsManager
window.wxResRoot
window.ucResRoot
window.vivoResRoot
window.huaweiResRoot
window.oppoResRoot
window.delayUpdateResVersion
```

Therefore controller-level interception is preferred over global CDN-string replacement.

The experimental patch was scoped to:

```text
resource/assets_en/
```

and routes that namespace to:

```text
http://127.0.0.1:8090/
```

The local resource server and real browser resource traffic are already sufficiently working that CDN discovery is no longer the main blocker.

## 35.11 Nginx protection

`nginx/` is READ-ONLY for this project unless the user explicitly changes the instruction.

Never:

```text
edit nginx/
regenerate nginx/
replace nginx configs
"clean up" nginx/
switch nginx implementations
```

If nginx appears to be the only solution, explain the need and ask first.

## 35.12 Game3 / 30004 evidence boundary

The captured client contains:

```text
window.SERVER_CONFIG = ["game3.xjlgmkk.com:30004"]
```

A tiny captured game3 response object exists.

What is proven:

```text
30004 appears in captured configuration     PROVEN
captured game3 object exists                PROVEN
exact live 30004 transport                  UNKNOWN
exact live 30004 protocol                   UNKNOWN
30004 required for current login            UNKNOWN
```

Never invent an HTTP, WebSocket, REST, or binary protocol for 30004 without evidence.

## 35.13 Telemetry

Real browser state marks observed include:

```text
engine_load
login_bg_load
main_constructor
source_load
game_launch_begin
game_newsdk_begin
game_newsdk_end
game_launch_constructor
game_init_panel
gamecfg_readfromsetting
gamesdk_create
conn_login
base_config_load
gamesdk_init_begin
gamesdk_login_begin
gamesdk_login_end
gamesdk_init_ok
game_launch_onstartgame
init_sdk
before_click_login_button
touched_btn_start_game
click_login_button
```

Telemetry progression is useful evidence, but telemetry success is not game-protocol success.

## 35.14 Evidence hierarchy

Use these labels:

```text
PROVEN
  Directly observed, decoded, tested, or present in exact source.

STRONGLY SUPPORTED
  Multiple independent clues support it, but direct runtime proof is missing.

HYPOTHESIS
  Plausible explanation requiring a test.

UNKNOWN
  No reliable evidence yet.

REJECTED
  An earlier belief contradicted by later evidence.
```

Never silently promote:

```text
schema -> server behavior
static string -> runtime usage
transport success -> application success
hypothesis -> fact
```

## 35.15 Mandatory server reconstruction loop

```text
1. Observe real request.
2. Capture raw bytes where applicable.
3. Decode with authoritative schema.
4. Identify minimum response required.
5. Send only evidence-supported data.
6. Observe next client action/state.
7. Compare with original/captured behavior if possible.
8. Implement the smallest change.
9. Run regression tests.
10. Record what became proven.
```

## 35.16 Change-control

Before changing any file:

```text
1. Say why the file is relevant.
2. State the evidence supporting the change.
3. Make the smallest reversible modification.
4. Preserve a backup for recovered/minified artifacts.
5. Run the narrowest relevant test.
6. Report exact files changed and actual results.
```

No broad "while we're here" rewrites.

## 35.17 No-loop rule

If the user says:

```text
next
```

perform the next concrete evidence-gathering or implementation action.

Do not respond with another roadmap that merely says what should be inspected.

If something cannot be done, state the exact blocker.

## 35.18 No false completion

Do not say:

```text
fixed
done
proven
working
complete
```

unless evidence supports that exact claim.

Prefer:

```text
implemented but untested
schema verified
runtime observed
partially working
not yet proven
```

## 35.19 Current immediate investigation

The next investigation target is:

```text
2004 response
    ↓
browser-side acceptance/rejection
    ↓
close/reconnect reason
    ↓
3001 GAME_LOGIN
```

Do not return to CDN discovery unless new browser evidence shows an unrecovered resource family.

## 35.20 Current one-line status

```text
CDN/resource recovery: sufficiently complete and runtime-usable.
H5SDK/local login bridge: functioning enough for investigation.
WebSocket transport: proven.
Real login protocol: partially reconstructed.
Current blocker: client closes/reconnects after 2004 before real-browser 3001.
Immediate target: explain the 2004 → 3001 boundary using evidence.
```

---

# 36. FUTURE-AI OPERATING CONTRACT

This section is intended to be pasted into a new AI/chat when continuing the project.

```text
You are continuing the Pokémon Burst H5 server rebuild.

READ:
- pokemonburst_research_handoff_updated_phase8_complete.md
- POKEMON_BURST_AI_RULES.md
- POKEMON_BURST_EVIDENCE_LEDGER.md

HARD CONSTRAINTS:
- Use the actual recovered 2024 client/assets.
- Current base is /mnt/data/PokemonBurst-local-server-v2.20-h5sdk-real-root-local-stack-fixed(2).zip
- NEVER TOUCH nginx/.
- Do not silently switch bases.
- Do not restart completed CDN discovery.
- Do not invent protocol behavior.
- Do not treat schemas as server behavior.
- Do not treat WebSocket 101 as application success.
- Do not claim success without runtime evidence.

AUTHORITATIVE COUNTS:
- 1,385 opcodes
- 650 named types
- 2,035 combined packet entries

CURRENT REAL CLIENT SEQUENCE:
2001 -> 2005 -> 2020 -> 2004 -> close/reconnect

CURRENT BLOCKER:
2004 response -> client acceptance -> expected 3001

TASK:
Perform the next concrete investigation. Do not give me a roadmap-only answer.

First:
1. Verify the selected base exists.
2. Treat nginx/ as read-only.
3. Inspect the current server code/tests.
4. Inspect 2005, 2020, and 2004 handling.
5. Capture exact response bytes and browser behavior if possible.
6. Determine why the browser closes/reconnects after 2004.
7. If evidence is insufficient, gather evidence instead of guessing.
8. If a change is justified, modify only the smallest non-nginx file(s).
9. Run the narrowest regression test and report actual results.

ANTI-HALLUCINATION RULE:
If evidence is insufficient, write:
"UNKNOWN - needs runtime/source evidence"

Never replace that with a plausible implementation.

A successful result means the real browser advances through a state transition supported by evidence, not merely that a guessed response makes it move.
```

## 37. ACTIVE WORK LOG - 2026-09-14

### 37.1 First evidence-backed fixes applied to the chosen base

Chosen base remains:

```text
/mnt/data/PokemonBurst-local-server-v2.20-h5sdk-real-root-local-stack-fixed(2).zip
```

Working extraction:

```text
/mnt/data/base220/PokemonBurst-local-server-v2.20-h5sdk-real-root-local-stack-fixed
```

Protected directory:

```text
nginx/
```

No nginx files were modified.

Changes made outside nginx:

1. Added opcode `2005` handling in `server/src/handlers/dispatch.ts`.
   - Request is runtime-proven.
   - Response schema is verified as `notice_list: array<login_notice_info>`.
   - Current local response is `notice_list: []`.
   - This is **implemented but not production-content-proven**.

2. Added opcode `2020` handling in `server/src/handlers/dispatch.ts`.
   - Request is runtime-proven.
   - Response schema is verified as `config_list: array<client_config>`.
   - Current local response is `config_list: []`.
   - This is **implemented but not production-content-proven**.

3. Updated `server/test-boot-chain.mjs` so the synthetic chain now exercises:
   `2001 -> 2002 -> 2005 -> 2020 -> 2004 -> 3001 ...`
   The test reflects the newly observed real-browser request order without claiming that this synthetic order is itself production behavior.

4. Fixed `server/test-route-2004.mjs` so its expected host/port comes from `ADVERTISE_HOST` / `ADVERTISE_PORT` instead of hard-coding `ryure:30001`.

### 37.2 Validation status

Node syntax checks passed for the modified JavaScript test files and existing H5SDK server file.

Full server tests were **not run** because this extracted base currently has no `server/node_modules/`. Installing dependencies was previously attempted and timed out. Therefore no runtime test is being claimed here.

### 37.3 Current blocker remains unchanged

The real browser still needs to be observed at:

```text
2004 response -> browser acceptance/rejection -> reconnect/close -> 3001
```

The new 2005/2020 handlers are deliberately minimal and must not be treated as the proven solution to the 2004 boundary.

### 37.4 Next investigation target

Capture or recover the exact browser-visible values and decision path around `2004`, especially:

- response `result`
- `acc_id`
- `md5`
- `ip`
- `port`
- `plat_id`
- the next WebSocket connection target
- whether the client sends `3001`
- browser close code / reason
- any client-side validation/error log immediately after `2004`

Do not replace this investigation with guesses about what `2004` "should" contain.

### 37.5 Validation update

After the dependency attempt, `server/node_modules/` exists but is incomplete: `tsx` and `tsc` are still missing. The existing protocol test suite was run successfully:

```text
npm test
5 tests passed, 0 failed
```

This validates the existing protocol-level tests only. It does **not** validate the TypeScript dispatch changes or a live WebSocket server.


# SECTION 37 - 2026-09-14 active fix log

## 37.1 Current concrete fix: 2004 platform alignment

The current 2024 target is not the historical 2022 client. The captured current
CDN bootstrap in `alonesitegamer/h5sdk` explicitly declares:

```text
window.platform = 330
window.sdkName = "Maiji_330_H5_A"
window.version = "20241024736"
```

The local replacement server still inherited `PLAT_ID=308` from the historical
client/source work. Because `2004 SERVER_CHOOSE` returns `plat_id`, this mismatch
is a credible client-acceptance failure at the exact current blocker boundary.

### Applied changes

- `config/server.env`: changed `PLAT_ID=308` to `PLAT_ID=330`.
- `server/src/handlers/dispatch.ts`: changed the 2004 fallback from 308 to 330.
- `server/test-route-2004.mjs`: now checks the returned `plat_id` against
  `PLAT_ID`, in addition to result/IP/port.
- `GITHUB_SOURCE_NOTES.md`: preserved the historical 308 evidence but explicitly
  marked it as old-client data and recorded the current 2024 platform evidence.
- `FIX_2026-09-14_PLATFORM_ALIGNMENT.md`: records this change and its evidence
  boundary.
- `POKEMON_BURST_AI_RULES.md`: appended the active work entry.
- `POKEMON_BURST_EVIDENCE_LEDGER.md`: added E019-E021.

### Evidence status

This is **STRONGLY SUPPORTED**, not PROVEN as the cause of the browser close.
The current client bootstrap proves platform 330 is the target platform. It does
not by itself prove that the 2004 response must contain 330, so live browser
evidence remains required.

### Validation status

- `nginx/` was not modified.
- `server/test-route-2004.mjs` passed Node syntax checking.
- TypeScript/live WebSocket execution is still blocked by the incomplete
  dependency tree (`tsx`/`tsc` unavailable in the current container).
- Therefore this fix has **not** been declared live-proven.

## 37.2 Next decisive runtime observation

Run the real 2024 browser against this exact build and capture:

```text
TX 2004
RX 2004 raw bytes
RX 2004 decoded fields
WebSocket close code/reason
whether a new connection appears
whether TX 3001 occurs
```

If 3001 appears, record E008/E009 accordingly and move to the next observed
packet. If it still closes before 3001, do not guess. Inspect the exact 2004
consumer in the 2024 client and compare each returned field, especially `result`,
`acc_id`, `md5`, `ip`, `port`, and `plat_id`.


## 37. 2026-09-14 LIVE FIX PASS

### 37.1 H5SDK login bug found and fixed
The local H5SDK server previously parsed the POST body correctly but then read `ct` and `ac` only from the URL query string. The real H5SDK login request sends these fields in the form body. This caused a valid local login request to fall through to `fail#1`.

The handler now resolves `ct` and `ac` from the parsed POST body first, with query parameters as fallback.

Runtime validation on the extracted base:
- `node --check h5sdk/server.mjs`: PASS
- local `node server.mjs`: PASS, listener reached 8081
- exact form-style login shape: PASS, returned local guest `state:1` response
- gate route: PASS, returned local 8090 CDN URL

### 37.2 Protocol regression
`node --test server/tests/protocol.test.mjs` passed all 5 tests.

### 37.3 TypeScript server limitation
The extracted server has a partial `node_modules` directory. `npm run build` fails because `@types/node` and `@types/ws` type definitions are missing. A subsequent `npm ci --ignore-scripts --no-audit --no-fund` timed out in the execution environment. Therefore the TypeScript WebSocket server changes are not claimed as runtime-tested here.

### 37.4 Next decisive investigation
Continue from the real browser's `2004` response acceptance boundary. Do not change nginx. Capture or reproduce the exact 2004 response, then determine whether the browser opens 30001, closes, or reconnects.

## 37. 2026-09-14 Browser reached server-selection UI

The latest real browser run is an important milestone. The H5SDK gate and local login succeed, and the 2024 game reaches its server-selection UI. The screenshot shows the panel itself rendering, but the server rows are `undefined`.

The local WebSocket implementation currently returns empty `new_server` and `login_history` arrays from `2001`. Client source evidence shows that after a successful `2001`, `GameLaunch._onMsgAccountLogin` stores those arrays, sets the server ID/name from `login_history[0] || new_server[0]`, and opens `EntrancePanel`. The protocol schema defines `server_info` as `server_id:int32`, `name:string`, `status:int8`.

The smallest evidence-supported fix is therefore to return one local server entry from `2001` and `2002`: `server_id=1`, `name="Local Server"`, `status=1`. This is a local reconstruction value, not a claim about the original production server catalog.

Validation so far: protocol regression suite 5/5 passes. TypeScript runtime is not yet proven in the container because `tsx` is missing from `node_modules`. Browser validation is the next required step.
