#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${H5SDK_PORT:-18081}"
TMP_LOG="$(mktemp)"
trap 'kill "$PID" 2>/dev/null || true; rm -f "$TMP_LOG"' EXIT
H5SDK_PORT="$PORT" node "$BASE_DIR/h5sdk/server.mjs" >"$TMP_LOG" 2>&1 &
PID=$!
for i in $(seq 1 50); do curl -fsS "http://127.0.0.1:$PORT/" >/dev/null 2>&1 && break || sleep 0.1; done
curl -fsS "http://127.0.0.1:$PORT/?ct=gate&g=10336&p=smileonexjlbt_android_ios&dd=000000000000000&af_id=&options=null" | grep -q '"state":1'
curl -fsS "http://127.0.0.1:$PORT/game" | grep -Eq '<!DOCTYPE html>|<html'
# Test the real static naming fallback when a captured root is available.
if [[ -f "$HOME/Downloads/h5sdk/h5sdk.camjm.space/static/game/mjinit__v_20220509.js" ]]; then
  curl -fsS "http://127.0.0.1:$PORT/static/game/mjinit.js?v=20220509" >/dev/null
fi
echo '[h5sdk] smoke test passed'
