#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
ROOT="${H5SDK_ROOT:-$HOME/Downloads/h5sdk/h5sdk.camjm.space}"
PORT="${H5SDK_PORT:-18081}"
H5SDK_ROOT="$ROOT" H5SDK_PORT="$PORT" node "$BASE/server.mjs" >/tmp/pokemonburst-h5sdk-smoke.log 2>&1 &
pid=$!
trap 'kill "$pid" 2>/dev/null || true' EXIT
sleep 0.5
curl -fsS -o /tmp/h5sdk-game.out "http://127.0.0.1:$PORT/game/?g=10336&c=4&p=smileonexjlbt_android_ios&pv=1.0&dd=000000000000000&dn=&dv=&du=&v=1.0.0&l=en&af_id=&options=null"
curl -fsS "http://127.0.0.1:$PORT/?ct=gate&g=10336&c=4&p=smileonexjlbt_android_ios&pv=1.0&dd=000000000000000&dn=&dv=&du=&v=1.0.0&l=en&af_id=&options=null"
echo
printf '[h5sdk] real-root smoke passed\n'
