#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
REAL_ROOT="${H5SDK_ROOT:-$HOME/Downloads/h5sdk/h5sdk.camjm.space}"
if [[ -d "$REAL_ROOT" ]]; then
  export H5SDK_ROOT="$REAL_ROOT"
  echo "[h5sdk] using real captured root: $H5SDK_ROOT"
else
  echo "[h5sdk] real root not found: $REAL_ROOT"
  echo "[h5sdk] falling back to bundled capture fixtures"
  export H5SDK_ROOT="$BASE_DIR/h5sdk/capture"
fi
exec "$BASE_DIR/h5sdk/start.sh"
