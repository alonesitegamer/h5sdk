import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const home = process.env.HOME || '';
const realRoot = path.join(home, 'Downloads', 'h5sdk', 'h5sdk.camjm.space');
const defaultRoots = [process.env.H5SDK_ROOT, realRoot, path.join(here, 'capture')].filter(Boolean);
const selectedRoot = defaultRoots.find(p => fs.existsSync(p)) || defaultRoots[0];
let root = path.resolve(selectedRoot);
// Captures may be stored either directly as h5sdk.camjm.space/* or
// as capture/h5sdk.camjm.space/*. Normalize both layouts.
const nestedHostRoot = path.join(root, 'h5sdk.camjm.space');
if (fs.existsSync(nestedHostRoot) && fs.statSync(nestedHostRoot).isDirectory()) root = nestedHostRoot;
const port = Number(process.env.H5SDK_PORT || 8081);

// 8081 is the captured H5SDK host. 8090 is the local game/CDN host.
// 30001 is the replacement game WebSocket and is referenced by the game HTML.
const cdnBase = process.env.H5SDK_CDN_BASE_URL || 'http://127.0.0.1:8090';
const cdnGamePath = process.env.H5SDK_CDN_GAME_PATH || 'index.html';
const exactGameHtml = 'game__g_10336_c_4_p_smileonexjlbt_android_ios_pv_1.0_dd_0000000000.html';

const types = {
  '.html':'text/html; charset=utf-8', '.htm':'text/html; charset=utf-8',
  '.js':'application/javascript; charset=utf-8', '.css':'text/css; charset=utf-8',
  '.json':'application/json; charset=utf-8', '.bin':'application/octet-stream',
  '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.gif':'image/gif',
  '.webp':'image/webp', '.svg':'image/svg+xml', '.woff':'font/woff', '.woff2':'font/woff2',
  '.ttf':'font/ttf', '.mp3':'audio/mpeg', '.mp4':'video/mp4'
};

function json(res, code, body) {
  const data = JSON.stringify(body);
  res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
  res.end(data);
}
function safeJoin(rel) {
  const f = path.resolve(root, rel.replace(/^\/+/,''));
  return f.startsWith(root + path.sep) || f === root ? f : null;
}
function versionCandidates(abs, q) {
  if (!abs) return [];
  const out = [], dir = path.dirname(abs), base = path.basename(abs);
  if (!fs.existsSync(dir)) return out;
  if (fs.existsSync(abs) && fs.statSync(abs).isFile()) out.push(abs);
  const ext = path.extname(base), stem = path.basename(base, ext), version = q?.get('v');
  const names = fs.readdirSync(dir);
  if (version) for (const n of [
    `${stem}__v_${version}${ext}`, `${stem}_v_${version}${ext}`,
    `${stem}__${version}${ext}`, `${stem}_${version}${ext}`
  ]) if (names.includes(n)) out.push(path.join(dir,n));
  for (const n of names) if (n.startsWith(stem + '__v_') && n.endsWith(ext)) out.push(path.join(dir,n));
  for (const n of names) if (n.startsWith(stem + '_v_') && n.endsWith(ext)) out.push(path.join(dir,n));
  return [...new Set(out)];
}
function findVersionedFile(abs, q) { return versionCandidates(abs,q)[0] || null; }
function serveFile(res, file, contentType) {
  fs.stat(file,(err,st)=>{
    if (err || !st.isFile()) return res.writeHead(404).end('Not found');
    res.writeHead(200, {'Content-Type':contentType || types[path.extname(file)] || 'application/octet-stream','Cache-Control':'no-cache'});
    fs.createReadStream(file).pipe(res);
  });
}
function serveCaptured(res, name, contentType, q) {
  const f=findVersionedFile(safeJoin(name),q);
  if (!f) return false;
  serveFile(res,f,contentType);
  return true;
}
function gateUrl(q) {
  const base=`${cdnBase.replace(/\/$/,'')}/${cdnGamePath.replace(/^\/+/,'')}`;
  return `${base}?zzh5=1&dd=${encodeURIComponent(q.get('dd') ?? '000000000000000')}&af_id=${encodeURIComponent(q.get('af_id') ?? '')}&g=${encodeURIComponent(q.get('g') ?? '10336')}&options=${encodeURIComponent(q.get('options') ?? 'null')}&p=${encodeURIComponent(q.get('p') ?? 'smileonexjlbt_android_ios')}`;
}
function bodyParams(req) {
  return new Promise(resolve=>{
    let data='';
    req.on('data',c=>{ data+=c; if(data.length>2_000_000) req.destroy(); });
    req.on('end',()=>{
      const type=String(req.headers['content-type'] || '').split(';',1)[0].trim().toLowerCase();
      try {
        if (!data) return resolve({});
        if (type === 'application/json') return resolve(JSON.parse(data));
        if (type === 'application/x-www-form-urlencoded' || type === '') {
          return resolve(Object.fromEntries(new URLSearchParams(data)));
        }
      } catch {}
      resolve({});
    });
    req.on('error',()=>resolve({}));
  });
}

const server=http.createServer(async (req,res)=>{
  const u=new URL(req.url || '/',`http://${req.headers.host || 'localhost'}`);
  const q=u.searchParams;
  console.log(`[h5sdk] ${req.method} ${u.pathname}${u.search}`);

  if ((req.method==='GET'||req.method==='HEAD') && u.pathname==='/' && q.get('ct')==='gate') {
    const url=gateUrl(q);
    console.log(`[h5sdk] gate -> ${url}`);
    return json(res,200,{state:1,data:{url},msg:''});
  }

  if (req.method==='POST') {
    const data=await bodyParams(req);
    console.log(`[h5sdk] POST params: ${JSON.stringify(data)}`);
    const ct=String(data.ct ?? q.get('ct') ?? ''), ac=String(data.ac ?? q.get('ac') ?? '');
    if (ct==='h5Tool' && ac==='language') return json(res,200,{state:1,data:{payment:{confirm:'Confirm',close:'Close'},h5:{game_error:'Game error'},game_error:'Game error'},msg:''});
    if (ct==='h5Game' && ac==='active') return json(res,200,{state:1,data:{kf_qq:'',image_code:false,dt:0,announce:0,id_no:'',accounts:[],pay_types:[]},msg:''});
    if (ct==='h5User' && ac==='login') {
      // Local-only guest session. The real H5SDK expects these fields before
      // it calls fcmIfOpen() and posts the mjlogin parent message.
      return json(res,200,{state:1,msg:'',data:{uid:'local_guest',code:'0',email:'',sdk_token:'local-token',auth:false}});
    }
    if (ct==='h5User' && ac==='fcmIfOpen') return json(res,200,{state:1,msg:'',data:{open:false}});
    if (ct==='h5User' && ac==='randomAccount') return json(res,200,{state:1,data:{account:'local_guest',password:'',acc_id:'local_guest'},msg:''});
    if (ct && ac) {
      const key=`index__ct_${ct}_ac_${ac}.bin`;
      if (serveCaptured(res,key,'application/json; charset=utf-8',q)) return;
    }
    return json(res,200,{state:0,msg:'fail#1'});
  }

  if (req.method!=='GET' && req.method!=='HEAD') return res.writeHead(405,{'Allow':'GET, HEAD, POST'}).end();
  if (u.pathname==='/favicon.ico') return res.writeHead(204).end();

  // The wrapper route serves the exact captured H5SDK game HTML from the H5SDK root.
  if (u.pathname==='/game' || u.pathname==='/game/' || u.pathname==='/game.html') {
    const f=safeJoin(exactGameHtml);
    if (f && fs.existsSync(f)) return serveFile(res,f,'text/html; charset=utf-8');
    const fallback=path.join(root,'game__g_10336_c_4_p_smileonexjlbt_android_ios_pv_1.0_dd_000000000000000.html');
    if (fs.existsSync(fallback)) return serveFile(res,fallback,'text/html; charset=utf-8');
    return res.writeHead(404).end('h5sdk wrapper capture missing');
  }

  if (u.pathname==='/' && q.get('ct') && q.get('ac')) {
    const key=`index__ct_${q.get('ct')}_ac_${q.get('ac')}.bin`;
    if (serveCaptured(res,key,'application/json; charset=utf-8',q)) return;
    return json(res,200,{state:0,msg:'fail#1'});
  }
  if (u.pathname==='/' && q.get('ct')) return json(res,200,{state:0,msg:'fail#1'});

  const rel=decodeURIComponent(u.pathname.replace(/^\/+/,''));
  const f=findVersionedFile(safeJoin(rel),q);
  if (f) return serveFile(res,f);
  res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});
  res.end(`h5sdk local route not captured: ${u.pathname}${u.search}\n`);
});

server.listen(port,'0.0.0.0',()=>{
  console.log(`[h5sdk] listening on http://0.0.0.0:${port}`);
  console.log(`[h5sdk] root: ${root}`);
  console.log(`[h5sdk] gate CDN: ${cdnBase}/${cdnGamePath}`);
  if (!fs.existsSync(root)) console.warn(`[h5sdk] WARNING: root does not exist: ${root}`);
});
