#!/usr/bin/env bash
set -euo pipefail

H5SDK_BASE="${H5SDK_BASE:-http://127.0.0.1:8081}"
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CDN_BASE="${CDN_BASE:-http://127.0.0.1:8090}"
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
H5SDK_PID=""

cleanup() {
  if [[ -n "$H5SDK_PID" ]] && kill -0 "$H5SDK_PID" 2>/dev/null; then
    kill "$H5SDK_PID" 2>/dev/null || true
    wait "$H5SDK_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

if ! curl -fsS --max-time 2 "$H5SDK_BASE/game/" >/dev/null 2>&1; then
  echo "[smoke] 8081 not running; starting local H5SDK..."
  "$ROOT_DIR/h5sdk/start.sh" >/tmp/pokemonburst-h5sdk-smoke.log 2>&1 &
  H5SDK_PID=$!

  for _ in $(seq 1 50); do
    if curl -fsS --max-time 1 "$H5SDK_BASE/game/" >/dev/null 2>&1; then
      break
    fi
    sleep 0.1
  done
fi

GAME_URL="$H5SDK_BASE/game/?g=10336&c=4&p=smileonexjlbt_android_ios&pv=1.0&dd=0000000000"
HTML=$(curl -fsS "$GAME_URL")
echo "$HTML" | grep -q '/static/game/jquery-2.2.4.min.js?v=20220509'
echo "$HTML" | grep -q '/static/game/md5.js?v=20220509'
echo "$HTML" | grep -q '/static/game/mjinit.js?v=20220509'
echo "$HTML" | grep -q '/static/game/platformJS/DATAWIN.js'

GATE=$(curl -fsS "$H5SDK_BASE/?ct=gate&g=10336&p=smileonexjlbt_android_ios&dd=000000000000000&af_id=&options=null")
echo "$GATE" | grep -q "$CDN_BASE/index.html"

# Seed the exact runtime manifest locally if the captured CDN tree is missing it.
if [[ "$CDN_BASE" == "http://127.0.0.1:8090" || "$CDN_BASE" == "http://localhost:8090" ]]; then
  if ! curl -fsS --max-time 2 "$CDN_BASE/resource/preload_b4ed6d75.json?v=20241024736" >/dev/null 2>&1; then
    "$ROOT_DIR/tools/seed_missing_runtime_resources.sh"
  fi
fi

curl -fsSI "$CDN_BASE/index.html" >/dev/null
curl -fsS "$CDN_BASE/index.html" | grep -q '127.0.0.1:30001'

echo '[smoke] 8081 wrapper -> local gate -> 8090 CDN -> 30001 config: PASS'
