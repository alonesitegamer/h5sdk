# h5sdk real-root host (v2.20)

This host serves the actual captured `h5sdk.camjm.space` tree when present.

Preferred root:

`~/Downloads/h5sdk/h5sdk.camjm.space`

The server resolves both exact filenames and captured versioned forms such as:

- `jquery-2.2.4.min.js?v=20220509` -> `jquery-2.2.4.min__v_20220509.js`
- `mjinit.js?v=20220509` -> `mjinit__v_20220509.js`
- `mjinit.js?v=20260826` -> `mjinit_v_20260826.js` when that form exists

The bundled `h5sdk/capture` directory is only a fallback smoke-test fixture. It is not intended to replace the real capture.

Run:

`./h5sdk/start.sh`

or:

`./h5sdk/install-and-start.sh`

Then test the full launch URL on port 8081.
