#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DEFAULT_ROOT="$HOME/Downloads/h5sdk/h5sdk.camjm.space"
# Prefer the real captured h5sdk tree. Only use bundled fixtures when the real tree is absent.
if [[ -n "${H5SDK_ROOT:-}" ]]; then
  export H5SDK_ROOT
elif [[ -d "$DEFAULT_ROOT" ]]; then
  export H5SDK_ROOT="$DEFAULT_ROOT"
elif [[ -d "$BASE_DIR/h5sdk/capture" ]]; then
  export H5SDK_ROOT="$BASE_DIR/h5sdk/capture"
fi
export H5SDK_PORT="${H5SDK_PORT:-8081}"
exec node "$BASE_DIR/h5sdk/server.mjs"
