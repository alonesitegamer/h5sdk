# Pokémon Burst Server Rebuild - AI RULES

## HARD RULES

1. Evidence before implementation.
2. Never invent protocol fields, response values, request order, endpoint behavior, or asset mappings.
3. Schema != server behavior.
4. Static string != runtime usage.
5. WebSocket 101 != application success.
6. Use real browser traces as the runtime oracle.
7. Current base:
   `/mnt/data/PokemonBurst-local-server-v2.20-h5sdk-real-root-local-stack-fixed(2).zip`
8. NEVER TOUCH `nginx/`.
9. Never silently switch bases.
10. Do not restart completed CDN discovery or redownload the English mirror without new evidence.
11. Current authoritative protocol counts:
    `1,385 opcodes + 650 named types = 2,035 combined entries`.
12. Real browser sequence:
    `2001 -> 2005 -> 2020 -> 2004 -> close/reconnect`.
13. Current blocker:
    `2004 response -> client acceptance -> 3001`.
14. Do not assume 2002 is mandatory.
15. Do not declare 2004 successful from schema correctness alone.
16. Keep resource HTTP, H5SDK/API, game WebSocket, telemetry, and third-party/payment services separate.
17. Make the smallest reversible change.
18. No "while we're here" rewrites.
19. If user says "next", perform the next concrete action rather than restating the roadmap.
20. If uncertain, say so.

## EVIDENCE LABELS

PROVEN = directly observed/decoded/tested/exact source.
STRONGLY SUPPORTED = multiple clues, no direct runtime proof.
HYPOTHESIS = plausible, needs test.
UNKNOWN = insufficient evidence.
REJECTED = contradicted by later evidence.

Never silently promote one evidence level into another.

## RECONSTRUCTION LOOP

observe request
-> capture raw bytes
-> decode with authoritative schema
-> identify minimum required response
-> respond
-> observe next state
-> implement smallest change
-> regression test
-> record evidence

## CURRENT RESOURCE FACTS

English candidates: 3,298
Represented: 3,296 (~99.94%)
Known exceptions:
- `#.png` -> HTTP 403
- `%.png` -> HTTP 400

Do not let these derail protocol work.

## REQUIRED CHANGE REPORT

For every modification report:

- file(s) changed
- why relevant
- evidence supporting change
- exact change
- test run
- actual result
- remaining unknowns

Never report a planned action as completed.

## ACTIVE WORK LOG: 2026-09-14

The current working extraction is the fixed v2.20 real-root local-stack base. `nginx/` is read-only and was not modified.

### Changes currently allowed/applied
- `server/src/handlers/dispatch.ts`: added schema-valid local responses for runtime-proven requests `2005` and `2020` using empty arrays.
- `server/test-boot-chain.mjs`: added 2005 and 2020 to the synthetic coverage path.
- `server/test-route-2004.mjs`: removed a stale hard-coded `ryure:30001` expectation and made the test follow the configured advertised endpoint.

### Important status label
The 2005/2020 empty responses are implementation probes, not recovered production behavior. Keep them explicitly marked as such until real response payloads are captured.

### Validation rule
Do not report the server as runtime-tested from this extraction until dependencies are available and the relevant test actually runs. Current state: syntax checks passed; full server tests blocked by missing `node_modules`.

### Current fix target
Continue at the real-browser `2004 -> 3001` boundary. The objective is to identify the exact reason the client does not proceed to 3001, using runtime/client evidence.

### Latest validation
`npm test` now runs and passed 5/5 protocol tests. The dependency tree is still incomplete (`tsx` and `tsc` are missing), so TypeScript build/runtime tests remain unvalidated.


## ACTIVE WORK LOG: 2026-09-14 - 2004 platform alignment

New evidence from the current `alonesitegamer/h5sdk` 2024 target shows the
actual CDN bootstrap sets `window.platform=330` and uses `Maiji_330_H5_A`. The
older `platform=308` value belongs to the historical pre-2024 source notes.

Implemented a narrow target-alignment fix outside `nginx/`:
- `config/server.env`: `PLAT_ID=330`
- `server/src/handlers/dispatch.ts`: default 2004 `plat_id=330`
- `server/test-route-2004.mjs`: now validates `plat_id` against `PLAT_ID`

Evidence level: **STRONGLY SUPPORTED**, not PROVEN for the live 2004 response.
The next runtime test must determine whether this allows the real client to send
3001. Do not promote this to PROVEN without browser evidence.


## LIVE VALIDATION RULE
When the working tree is available in the execution environment, test fixes locally before asking the user to test. Report separately: source syntax, unit/regression tests, service runtime, and browser/runtime proof. Never turn one category into another.

## H5SDK BODY/PARAMETER RULE
For H5SDK endpoints, inspect the captured request shape before choosing query vs POST-body parsing. The real login request carries `ct` and `ac` in the POST form body.

## FIX 2026-09-14: Empty server catalog renders undefined

### Evidence
- Real browser screenshot shows the server-selection UI populated with repeated `undefined` labels.
- Existing client source evidence shows `GameLaunch._onMsgAccountLogin` stores `new_server` / `login_history` and opens `EntrancePanel` after successful `2001`.
- The current local `2001` response returned both `new_server:[]` and `login_history:[]`.
- Protocol schema verifies `server_info = [server_id:int32, name:string, status:int8]`.

### Change
- `2001` now returns one schema-valid server: `{server_id:1,name:"Local Server",status:1}`.
- `2002` now returns the same local server instead of an empty `server_list`.

### Evidence level
**STRONGLY SUPPORTED / IMPLEMENTED.** The empty catalog is directly consistent with the visible `undefined` UI. The exact production server name/status is not recovered, so `Local Server` / `status=1` remain local reconstruction values.

### Validation
- `npm test`: 5/5 passed.
- TypeScript runtime/build remains **NOT RUNTIME-VALIDATED** because `tsx` is absent from the current container's `node_modules`.
- Browser validation is still required to prove that the visible `undefined` labels disappear and that clicking the local server reaches `2004`.
