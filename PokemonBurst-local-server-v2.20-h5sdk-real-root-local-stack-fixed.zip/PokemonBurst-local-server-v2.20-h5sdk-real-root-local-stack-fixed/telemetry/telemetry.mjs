import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
const HOST=process.env.HOST??'0.0.0.0';
const LOG_PORT=Number(process.env.LOG_PORT??30098), ERROR_PORT=Number(process.env.ERROR_PORT??30099);
const LOG_FILE=path.resolve(process.env.TELEMETRY_LOG??'./telemetry.log'), ERROR_FILE=path.resolve(process.env.TELEMETRY_ERROR_LOG??'./errors.log');
fs.mkdirSync(path.dirname(LOG_FILE),{recursive:true}); fs.mkdirSync(path.dirname(ERROR_FILE),{recursive:true});
const headers=(type='application/json; charset=utf-8')=>({'Content-Type':type,'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET,POST,OPTIONS','Access-Control-Allow-Headers':'Content-Type','Cache-Control':'no-store'});
const readBody=req=>new Promise(resolve=>{const a=[];req.on('data',c=>a.push(c));req.on('end',()=>resolve(Buffer.concat(a).toString('utf8')))});
function makeServer(kind,file){return http.createServer(async(req,res)=>{if(req.method==='OPTIONS'){res.writeHead(204,headers());return res.end()} const b=req.method==='POST'?await readBody(req):''; const u=new URL(req.url??'/',`http://${req.headers.host??'localhost'}`); const line=`${new Date().toISOString()} ${kind} ${req.method} ${u.pathname}${u.search}${b?` body=${b}`:''}\n`; fs.appendFileSync(file,line); console.log(line.trimEnd()); res.writeHead(200,headers());res.end('{}')})}
makeServer('STATE',LOG_FILE).listen(LOG_PORT,HOST,()=>console.log(`[+] 30098 listening on http://${HOST}:30098`));
makeServer('ERROR',ERROR_FILE).listen(ERROR_PORT,HOST,()=>console.log(`[+] 30099 listening on http://${HOST}:30099/error`));
