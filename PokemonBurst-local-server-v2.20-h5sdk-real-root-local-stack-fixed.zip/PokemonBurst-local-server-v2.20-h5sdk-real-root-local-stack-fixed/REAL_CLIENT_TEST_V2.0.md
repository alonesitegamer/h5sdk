# v2.0 — Real Client Hookup

## Official local endpoint

Use:

```text
ryure:30001
```

with:

```text
127.0.0.1 ryure
```

in `/etc/hosts`.

The replacement server actually binds to:

```text
127.0.0.1:30001
```

The hostname is only for the client-side endpoint.

## 1. Verify hostname

```bash
getent hosts ryure
```

Expected:

```text
127.0.0.1 ryure
```

If missing:

```bash
echo '127.0.0.1 ryure' | sudo tee -a /etc/hosts
```

## 2. Start server

```bash
cd ~/pokemonburst-replacement-server-v2.0/server
npm install
npm test
npm run check:registry
npm run check:endpoint
npm run dev:local
```

`check:endpoint` should report:

```text
[ENDPOINT] DNS: 127.0.0.1
[ENDPOINT] TCP reachable: ryure:30001
```

## 3. Patch a local client copy

Use the supplied local-only patch helper:

```bash
python3 tools/patch_local_endpoint.py \
  /path/to/client-copy/index.html \
  /path/to/client-copy/index-local.html
```

It changes:

```text
mon-1.frstinta.com:30001
```

to:

```text
ryure:30001
```

If the endpoint appears in a JS bundle rather than `index.html`, patch a COPY of
that bundle instead.

## 4. Run the client

Keep the server terminal visible.

The first useful evidence is server output such as:

```text
[RX] opcode=....
```

Do not assume the first client failure is a protocol failure. It may instead be:

- wrong scheme (`ws://` vs `wss://`)
- endpoint still present elsewhere in the bundle
- HTTP bootstrap still pointing at the original service
- TLS/certificate issue
- another required startup service

## 5. Real-client discovery rule

Once the client reaches our server, do not implement 1000+ handlers blindly.

Use this loop:

```text
real client request
        ↓
opcode
        ↓
PacketCfg schema
        ↓
client consumer
        ↓
minimal correct response
        ↓
next request
```

The first unknown/missing opcode after successful startup is the next
engineering target.
