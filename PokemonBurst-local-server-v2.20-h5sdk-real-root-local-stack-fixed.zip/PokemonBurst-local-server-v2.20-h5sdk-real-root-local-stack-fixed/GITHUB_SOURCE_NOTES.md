# GitHub Source Notes

Repository reviewed:

https://github.com/alonesitegamer/over-power-champion-quest

Useful source areas:

- `assets/index.html`
- `assets/js/main.min_d9762b67.js`
- `assets/js/socket.min_afab9be.js`
- `assets/resource/`
- `assets/versionAutoGen.2022111701.js`
- `AndroidManifest.xml`
- `classes.dex`
- `classes2.dex`
- `classes3.dex`
- `apktool.yml`

The repository is valuable because it contains the extracted game client itself,
not merely reports about it.

`assets/index.html` exposes local bootstrap configuration such as:

```text
platform=308
sdkName=QianXi_Android_A
version=2022111701
isOversea=true
SERVER_CONFIG=["mon-1.frstinta.com:30001"]
```

and a test/preview switch to port 30002 based on `pack_version`.

The `assets/js` directory contains the exact `main.min_d9762b67.js` bundle and
`socket.min_afab9be.js` transport bundle used by the reverse-engineering work.


## 2026-09-14 current-target correction

The repository referenced above is historical and is **not** the current 2024
H5SDK source. The current repository is `alonesitegamer/h5sdk`.

For target client `20241024736`, the captured CDN `index.html` explicitly sets:

```text
window.platform = 330
window.scid = 3
window.sdkName = Maiji_330_H5_A
window.version = 20241024736
window.SERVER_CONFIG = ["game3.xjlgmkk.com:30004"]
```

Therefore the old `platform=308` value above is historical evidence from the
older client and must not be used as the default for the 2024 target. The local
server default is now `PLAT_ID=330`. This is an evidence-based target-alignment
change, not proof that the production 2004 response used 330; live client
acceptance still needs to be observed.
