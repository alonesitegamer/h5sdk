# v1.0 — First End-to-End Protocol Test

## What changed

The smoke client now sends a real recovered packet:

```text
opcode = 3999
payload = empty
stamp = 0
length = 7
```

Expected bytes:

```text
00 00 00 07 0F 9F 00
```

The server should answer:

```text
uint32 length = 11
uint16 opcode = 3999
uint8 stamp = server-generated
uint32 unix_time
```

## Run

Terminal 1:

```bash
cd ~/pokemonburst-replacement-server-v1.0-project/server
npm install
npm test
npm run check:registry
npm run dev
```

Terminal 2:

```bash
cd ~/pokemonburst-replacement-server-v1.0-project/server
npm run smoke
```

Expected smoke output includes:

```text
[TEST] sending 3999 heartbeat
[TEST] received 11 bytes
[TEST] response ... opcode=3999 ... unix_time=...
[TEST] PASS: 3999 heartbeat round-trip
```

This is our first complete client→server→client protocol test.
