# NEXT CHAT PROMPT - POKÉMON BURST SERVER REBUILD

Read:
1. `pokemonburst_research_handoff_UPDATED_2026-09-14.md`
2. `POKEMON_BURST_AI_RULES.md`
3. `POKEMON_BURST_EVIDENCE_LEDGER.md`

You are continuing an existing investigation, not starting from scratch.

## HARD CONSTRAINTS

- Current base:
  `/mnt/data/PokemonBurst-local-server-v2.20-h5sdk-real-root-local-stack-fixed(2).zip`
- NEVER TOUCH `nginx/`.
- Do not silently switch to another base/version.
- Do not redo completed CDN discovery.
- Do not redownload the English mirror.
- Do not invent protocol responses.
- Do not treat schema as behavior.
- Do not treat WebSocket 101 as login success.
- Do not call something proven without evidence.

## AUTHORITATIVE FACTS

Target:
`20241024736`

Protocol:
`1,385 opcodes`
`650 named types`
`2,035 combined entries`

English mirror:
`3,296 / 3,298 candidates represented (~99.94%)`

Real browser sequence:
`2001 -> 2005 -> 2020 -> 2004 -> close/reconnect`

Exact 2004 request:
`0000000b 07d4 0400000001`
= length 11, opcode 2004, stamp 4, server_id 1.

Current blocker:
`2004 response -> browser acceptance -> expected 3001`

## DO THIS, NOT A ROADMAP

1. Verify the chosen base exists.
2. Treat `nginx/` as read-only.
3. Inspect current server code and tests.
4. Inspect exact 2005/2020/2004 handlers.
5. Capture or inspect exact response bytes and immediate browser behavior.
6. Determine the smallest evidence-supported reason for the close/reconnect.
7. If evidence is missing, gather it.
8. If a code change is justified, change only the smallest non-nginx file(s).
9. Run the narrowest relevant regression test.
10. Report:
   - what was inspected
   - evidence found
   - files changed
   - tests
   - actual result
   - remaining unknowns

## ANTI-HALLUCINATION CLAUSE

If evidence is insufficient, explicitly write:

`UNKNOWN - needs runtime/source evidence`

Do not fill the gap with a plausible response or invented backend behavior.

The goal is not to make the client advance by guessing.
The goal is to reproduce the real state transition one proven step at a time.

## CONTINUATION UPDATE

A first fix pass has now been applied outside `nginx/`:
- `2005` returns schema-valid `notice_list: []`
- `2020` returns schema-valid `config_list: []`
- synthetic boot coverage includes both
- stale hard-coded `ryure:30001` route-test expectation was fixed

Do not call those production-recovered responses. They are minimal implementation probes.

Full runtime tests are currently blocked because the chosen extraction has no `server/node_modules/`. Syntax checks passed.

NEXT: continue the real investigation at `2004 response -> browser acceptance -> 3001`. Capture exact response fields and the immediate browser close/reconnect behavior. Do not guess.

Latest validation: `npm test` passed 5/5. `tsx` and `tsc` remain missing, so live TypeScript server tests are still pending.


## Latest active fix (2026-09-14)

A concrete evidence-supported change has already been applied to the fixed base:
`PLAT_ID=330` for the 2024 target. Do not revert it to 308. The 2024 CDN index
explicitly declares platform 330 / `Maiji_330_H5_A`; 308 is historical client
evidence. This is STRONGLY SUPPORTED, not yet live-proven.

The next action is runtime verification of 2004 -> 3001. Capture raw 2004 RX,
decode every field, record WebSocket close code/reason and reconnect behavior,
and determine whether 3001 is emitted. If not, inspect the exact 2024 client
consumer. Keep changing the smallest non-nginx file supported by evidence.
Update the handoff, rules, ledger, and fix log after each concrete change.


## Latest checkpoint 2026-09-14
- E022: H5SDK POST login parsing fixed and runtime-proven locally.
- E023: H5SDK gate route runtime-proven locally.
- E024: protocol regression tests 5/5 pass.
- TypeScript server build is still blocked by incomplete dependencies.
- Next target remains the real 2004 -> client acceptance -> 30001 boundary.

## Latest concrete fix

The browser now visibly reaches the server-selection UI, but it renders `undefined` because the local `2001` response supplied empty `new_server` and `login_history` arrays. The next build returns one local server entry from `2001` and `2002`.

After packaging, test the browser and determine whether:
1. `undefined` rows become `Local Server`.
2. Clicking the server sends `2004`.
3. The client accepts the `2004` response and opens the game WebSocket.
4. `3001` arrives on the game-server listener.

Do not treat the server-name/status values as recovered production values. They are local reconstruction values chosen to satisfy the verified schema and observed UI failure.
