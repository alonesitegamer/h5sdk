# v1.8 — First Real-Client Preparation

## What we have proven

The replacement server successfully completes:

```text
2001
2002
2004
3001
3003
3004
3011
3017
```

inside one synthetic stateful session.

The next goal is to make the **real client** connect to the local replacement.

## Client endpoint evidence

The extracted client bootstrap previously exposed:

```text
mon-1.frstinta.com:30001
```

as the game-server endpoint.

For a local test, use a COPY of the client/bootstrap and replace only:

```text
mon-1.frstinta.com:30001
```

with:

```text
127.0.0.1:30001
```

Do not modify production endpoints or credentials.

## Direct local test

Start our replacement server on the same port expected by the client:

```bash
cd ~/pokemonburst-replacement-server-v1.8/server
npm install
npm test
npm run check:registry
npm run dev:game
```

Expected:

```text
Pokémon Burst replacement server v1.8: ws://127.0.0.1:30001
```

## If the client still targets the hostname

Use a LOCAL copy of the bootstrap/HTML and run:

```bash
python3 tools/patch_local_endpoint.py \
  /path/to/index.html \
  /path/to/local/index.html
```

For JS bundles, run the same script on the local copy of the bundle if the
endpoint is embedded there.

## `/etc/hosts` option

Only for a local disposable environment:

```text
127.0.0.1 mon-1.frstinta.com
```

This redirects that hostname locally, but it does not solve TLS if the client
uses `wss://` with a certificate for the original hostname. In that case use
Nginx/TLS later rather than weakening certificate validation.

## Important

The real client may still request additional server pushes, configuration,
HTTP bootstrap APIs, assets, or authentication data. That is expected.

The first real-client test should be treated as a discovery run:

```text
client
  ↓
local replacement
  ↓
first request we do not handle
  ↓
record opcode
  ↓
inspect PacketCfg + client consumer
  ↓
implement
  ↓
repeat
```

Do not add hundreds of handlers speculatively.
