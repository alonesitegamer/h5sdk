# v2.20 local stack

- H5SDK host: `http://127.0.0.1:8081`
- H5SDK real root: `~/Downloads/h5sdk/h5sdk.camjm.space/`
- `/game/` serves the captured `game__g_10336_c_4_p_smileonexjlbt_android_ios_pv_1.0_dd_0000000000.html` from that H5SDK root.
- `/static/game/*` is served from the H5SDK root and its versioned files.
- Gate returns the local CDN: `http://127.0.0.1:8090/index.html`.
- CDN root: `~/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/`
- Game WebSocket: `ws://127.0.0.1:30001` as configured by the captured game client.
- No public CDN or public DATAWIN URL is required by the deployed wrapper.

Run H5SDK with `./h5sdk/install-and-start.sh`. Configure nginx 8090 using `nginx/pokemonburst-local.conf`.
