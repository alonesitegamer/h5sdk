# v1.9 — Custom Local Endpoint

The developer said the newer endpoint can use any name.

For the local replacement test, we choose:

```text
pokemonburst.test:30001
```

`pokemonburst.test` is intended only as a local test hostname.

## 1. Start the replacement server

```bash
cd ~/pokemonburst-replacement-server-v1.9/server
npm install
npm test
npm run check:registry
npm run dev:local
```

Expected:

```text
Pokémon Burst replacement server v1.9: ws://127.0.0.1:30001
```

The hostname presented to the client is independent of the server's bind address.

## 2. Map the name locally

On Linux:

```bash
sudo nano /etc/hosts
```

Add:

```text
127.0.0.1 pokemonburst.test
```

Or:

```bash
echo '127.0.0.1 pokemonburst.test' | sudo tee -a /etc/hosts
```

Check:

```bash
getent hosts pokemonburst.test
```

Expected:

```text
127.0.0.1 pokemonburst.test
```

## 3. Patch a LOCAL copy of the client

Do not patch the original/production copy.

Example:

```bash
python3 tools/patch_local_endpoint.py \
  /path/to/local/index.html \
  /path/to/local/index-patched.html
```

Default replacement:

```text
mon-1.frstinta.com:30001
        ↓
pokemonburst.test:30001
```

If the newer endpoint already exists in the client, use the actual old/new
strings explicitly.

## 4. Important TLS note

This direct setup works only if the client is using plain:

```text
ws://pokemonburst.test:30001
```

If it requires:

```text
wss://pokemonburst.test:30001
```

a TLS certificate for `pokemonburst.test` is required. In that case put Nginx
or another local TLS terminator in front of the replacement server.

## 5. Why use a custom name?

It avoids confusing:

```text
production hostname
```

with:

```text
local replacement server
```

and makes logs/configuration much easier to reason about.
