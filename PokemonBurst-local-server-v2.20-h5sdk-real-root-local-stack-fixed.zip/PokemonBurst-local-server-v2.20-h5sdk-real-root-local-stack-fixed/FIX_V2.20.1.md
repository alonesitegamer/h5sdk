# v2.20.1 fix

- `h5sdk/smoke-full-local-stack.sh` no longer assumes port 8081 is already running.
- The smoke test starts the local H5SDK service when needed, waits for `/game/`, runs the checks, then cleans up only the process it started.
- Server package/version banner updated from the stale `2.13.0` / `v2.13-integrated` label to `2.20.1`.
