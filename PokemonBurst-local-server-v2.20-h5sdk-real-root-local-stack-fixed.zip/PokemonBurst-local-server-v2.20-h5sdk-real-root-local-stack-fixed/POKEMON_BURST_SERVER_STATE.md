# Pokémon Burst Replacement Server
## Project State / Knowledge / Handoff v0.5

## 1. Current objective

Build a **local replacement server** that can speak the surviving Pokémon Burst
client's gameplay protocol and progressively reproduce the client-visible game
state.

The project is intentionally being built in layers:

```text
Protocol
  ↓
Boot/login
  ↓
Initial synchronization
  ↓
Player state
  ↓
Gameplay handlers
  ↓
Persistence
```

This is a reconstruction project, not an attempt to reproduce undocumented
production-only security behavior.

---

# 2. Evidence hierarchy

### Confirmed from client source / extracted assets

- WebSocket gameplay transport exists.
- NetCenter is the schema/dispatch layer.
- NetService is the transport layer.
- Packet framing is known.
- Primitive serialization is known.
- Array encoding is known.
- `PacketCfg_json` is present in the extracted `cq_*.json` configuration.
- Numeric opcode schemas are known.
- Named/nested protocol types are known.
- Client message names and descriptions are known.
- The client has explicit boot/login opcodes.
- `3004` carries `simple_role`.
- `3011` is `SERVER_PUSH_FINISH`.
- `3017` is `LANG_CHANGE`.
- Static game configuration is extensive.

### Inferred / provisional

- Exact original server-side validation logic.
- Exact authentication acceptance rules.
- Which server-push packets are mandatory before `3011`.
- Which `simple_role` fields must be semantically non-zero for a particular
  client build.
- Runtime database structure.
- Battle simulation implementation.

---

# 3. Repository evidence

The supplied GitHub repository:

```text
https://github.com/alonesitegamer/over-power-champion-quest
```

contains the extracted game package, including:

```text
assets/
assets/index.html
assets/versionAutoGen.2022111701.js
assets/js/
assets/js/main.min_d9762b67.js
assets/js/socket.min_afab9be.js
assets/resource/
AndroidManifest.xml
classes.dex
classes2.dex
classes3.dex
apktool.yml
unknown/
```

The repository's `assets/js` directory contains the exact `main.min_d9762b67.js`
bundle identified by the reverse-engineering journal. The repository lists that
file at approximately 6.26 MB and also contains `socket.min_afab9be.js`.

The HTML bootstrap sets, among other values:

```text
platform = 308
sdkName = QianXi_Android_A
version = 2022111701
isOversea = true
SERVER_CONFIG = ["mon-1.frstinta.com:30001"]
```

and the page can switch to:

```text
mon-1.frstinta.com:30002
```

for a matching `pack_version` test condition.

---

# 4. Client architecture

Recovered architecture:

```text
UI
 ↓
Proxy.reqXXX()
 ↓
NetCenter.send()
 ↓
Packet
 ↓
NetService
 ↓
Egret WebSocket
 ↓
Game Server

Game Server
 ↓
Packet
 ↓
NetCenter._onReceivePacket()
 ↓
_readPacketMsg()
 ↓
_resXXX()
 ↓
Model
 ↓
UI
```

The client contains many feature-specific Proxy classes, including:

```text
RoleProxy
HeroProxy
FightProxy
GuildProxy
ArenaProxy
ShopProxy
ChatProxy
FriendProxy
Act*Proxy classes
```

---

# 5. Packet framing

Exact logical packet structure:

```text
offset 0   : uint32 BE total packet length
offset 4   : uint16 BE opcode
offset 6   : uint8 stamp
offset 7+  : payload
```

Header size:

```text
7 bytes
```

The stamp is assigned at transport-send time and wraps:

```text
0 → 1 → ... → 127 → 0
```

---

# 6. WebSocket reassembly

A WebSocket message does not have to represent exactly one logical game packet.

Replacement server therefore keeps an accumulation buffer:

```text
incoming WebSocket chunk
    ↓
append
    ↓
read declared uint32 packet length
    ↓
if incomplete: wait
if complete: decode packet
    ↓
repeat
```

---

# 7. Primitive codec

Confirmed primitives:

```text
int8
uint8
int16
uint16
int32
uint32
int64
uint64
number / Float64
string
```

All multi-byte numeric values are big-endian.

Strings:

```text
uint16 UTF-8 BYTE length
UTF-8 bytes
```

Arrays:

```text
0..254:
    uint8 length

255+:
    0xFF
    int16 actual length
```

Nested structures are recursively resolved through the protocol registry.

---

# 8. PacketCfg

The extracted `cq_0_e7cdc0f1(1).json` contains:

```text
PacketCfg_json
```

Extraction results:

```text
Total registry entries:           2035
Numeric opcode definitions:       1385
Named/nested type definitions:     650
With client->server schema:       1353
With server->client schema:       1382
With both:                        1350
Empty client schema:               431
Empty server schema:                 3
Opcode entries without m:            5
Distinct referenced types:         480
Unresolved type references:          0
```

The registry is now exported in:

```text
protocol-data/
    packetcfg.json
    opcodes.json
    types.json
    schemas/*.json
    protocol_report.json
```

---

# 9. Generic protocol engine

The server now uses the extracted registry rather than manually hardcoded
field definitions.

Outgoing:

```text
opcode
 ↓
opcodes[opcode].c
 ↓
recursive field encoder
 ↓
packet framing
 ↓
WebSocket
```

Incoming:

```text
packet
 ↓
opcode
 ↓
opcodes[opcode].c
 ↓
recursive decoder
 ↓
handler
```

Nested named types are resolved through:

```text
types.json
```

---

# 10. Initial boot/login opcodes

Known important opcodes:

```text
2001 ACCOUNT_LOGIN
2002 SERVER_LIST
2004 SERVER_CHOOSE
3001 GAME_LOGIN
3002 CREATE_ROLE
3003 SERVER_LOAD_SUCCESS
3004 CLIENT_LOAD_SUCCESS
3005 SERVER_TIME_INFO
3006 CLIENT_OFFLINE
3007 ERROR_NOTIFY
3008 PAY_CALLBACK_INFO
3010 HOME_ICON_INFO
3011 SERVER_PUSH_FINISH
3012 ENTRANCE_COUNTDOWN_LIST
3013 ENTRANCE_COUNTDOWN_CHANGE
3014 CONTROL_INFO
3015 RES_CONTROL
3016 UC_UPLOAD_INFO
3017 LANG_CHANGE
3018 DIANHUN_IOS_CHARGE_WAY
3019 SEND_ROLE_REG_TIMESTAMP
3020 CLIENT_CONFIG_LIST
3021 CLIENT_CONFIG_SET
3022 CLIENT_CONFIG_SET_ACC

3999 HEARTBEAT
```

The message-name table is present directly in the client bundle.

---

# 11. Known packet schemas

## 2001 ACCOUNT_LOGIN

Client:

```text
plat_id          int32
game_channel_id  string
acc_id           string
verify_time      int32
sign             string
channel          string
```

Server response includes:

```text
result
new_server[]
login_history[]
large_server_list[]
game_channel_id
```

Exact nested element types come from PacketCfg.

---

## 2002 SERVER_LIST

Client:

```text
large_server_id : int64
```

Server:

```text
large_server_id : int64
server_list[]   : server_info
```

---

## 2004 SERVER_CHOOSE

Client:

```text
server_id : int32
```

Server response includes:

```text
result
acc_id
md5
ip
port
plat_id
```

---

## 3001 GAME_LOGIN

Client:

```text
plat_id          int32
server_id        uint16
game_channel_id  string
acc_id           string
md5              string
os               int8
relogin          int8
version          int64
```

Server:

```text
result : int16
```

---

## 3003 SERVER_LOAD_SUCCESS

No request payload.

---

## 3004 CLIENT_LOAD_SUCCESS

Client sends no payload.

Server sends:

```text
role : simple_role
```

The client consumes this to initialize role and bag state.

---

## 3005 SERVER_TIME_INFO

Server:

```text
open_server_day : uint16
now_time        : int32
max_lev         : uint16
```

---

## 3011 SERVER_PUSH_FINISH

No payload.

This is used by the client as an initial-server-push completion gate.

---

## 3017 LANG_CHANGE

Client sends:

```text
lang : string
```

Server response includes:

```text
result : int16
lang   : string
```

---

## 3999 HEARTBEAT

Client request:

```text
empty
```

Server response:

```text
unix_time : uint32
```

---

# 12. `simple_role`

`3004` is the first large role synchronization object.

It recursively references a substantial part of the protocol type system.

Representative nested structures include:

```text
role_icon
fashion_use_info[]
attr_info[]
medal_simple[]
token_info[]
joint_team_dun_history[]
```

The replacement server now creates a schema-driven default object for
`simple_role`.

Current local values include:

```text
role_id = 1
name = "Local Trainer"
server ID = 1
server name = "Local Server"
level = 1
power = 0
VIP = 0
```

These are local replacement defaults, not reconstructed production values.

---

# 13. Confirmed post-3004 client behavior

The recovered client shows:

```text
3003
 ↓
client sends 3004
 ↓
client receives simple_role
 ↓
RoleModel.initRoleInfo(data.role)
 ↓
BagModel.updateItemChange(data.role.attr_list, [], [], [])
```

The `3004` response handler itself does not immediately issue the next normal
gameplay request.

The client uses:

```text
3011 SERVER_PUSH_FINISH
```

as an important startup gate.

After the push-finished condition and local resource conditions are satisfied,
the client sends:

```text
3017 LANG_CHANGE
```

Therefore the current minimum local boot chain is:

```text
2001
 ↓
2002
 ↓
2004
 ↓
3001
 ↓
3003
 ↓
3004
 ↓
3011
 ↓
3017
```

This is a minimal reconstruction path, not yet proof that the production server
sends no additional push packets between these stages.

---

# 14. Server push messages

A key remaining question is:

```text
Which server-push opcodes are actually required before 3011?
```

The current server uses the minimal:

```text
3011
```

completion packet.

The next research task is to enumerate the startup listeners and identify
which push packets the client consumes during initial synchronization.

Likely data classes may include:

```text
home
bag
mail
activity
configuration
countdowns
role extras
event state
```

but these must be confirmed from source, not guessed.

---

# 15. `MsgType` inventory

The client bundle contains a large integer opcode map.

Early range examples:

```text
1000 LOGIN
1001 GAME_SERVER_INFO
1002 LOGIN_CODE_RESULT
1004 LOGIN_NOTIFY
1005 NOTIFY_SERVER_STATUS
1006 NOTIFY_BLACK_WHITE_CHANGE

2001 ACCOUNT_LOGIN
2002 SERVER_LIST
2004 SERVER_CHOOSE
...

3001 GAME_LOGIN
...
3999 HEARTBEAT

4001 ROLE_CHANGE
4002 CHANGE_NAME
4003 CHANGE_FACE
...
4021 BAG_LIST
4022 GET_ITEM_LIST
4023 ITEM_USE_PREVIEW
4024 ITEM_USE
4025 ITEM_USE_WITH_CHOOSE
4026 ITEM_BUY
4027 ITEM_SELL
...
```

The complete registry is in the extracted `opcodes.json`.

---

# 16. Static game configuration

The supplied `cq_0` through `cq_9` files contain extensive static data.

Examples:

```text
hero_evolution_json
hero_talent_skill_json
dun_monster_json
underground_new_monster_json
cross_giant_battle_monster_json
guild_beast_privilege_json
guild_boss_basic_json
hero_weapon_box_json
fashion_suit_skill_json
held_item_group_collect_json
island_new_shop_json
new_egg_basic_json
cross_beast_park_pve_json
error_code_json
```

The static configuration covers:

```text
heroes
skills
evolution
items
shops
monsters
dungeons
events
guild systems
rewards
progression
economy
validation messages
```

---

# 17. Error code catalogue

The configuration contains approximately one thousand error messages.

Examples:

```text
4175  invalid parameter
4375  insufficient token
4961  insufficient stamina
4825  task incomplete
4732  formation required
442   insufficient level requirement
447   insufficient star requirement
444   insufficient class requirement
445   duplicate same-type pet
4824  reward already claimed
4373  cannot purchase
4907  team not registered
4965  left matchmaking
```

These give clues to server validation branches but do not themselves reveal the
server implementation.

---

# 18. Game configuration examples

The configuration includes extensive entries for:

```text
Gigantamax / special monster encounters
hero evolution
hero talent/skill relationships
dungeon monsters
underground monsters
guild privileges
guild bosses
shops
egg/draw costs
held-item collections
fashion suit skills
```

The data can eventually populate the replacement server's read-only game
configuration layer.

---

# 19. Runtime state vs static configuration

Static:

```text
hero definitions
skill definitions
monster definitions
shop costs
evolution rules
reward tables
error messages
dungeon templates
```

Runtime:

```text
account
session
role
hero instances
inventory
currency
progress
quests
guild membership
battle state
mail
cooldowns
```

Only the first category is substantially recovered from the configuration files.

---

# 20. Current server project

The latest project snapshot is:

```text
pokemonburst-replacement-server-v0.4.zip
```

Implemented:

```text
WebSocket server
packet reassembly
packet encoder
packet decoder
big-endian primitives
UTF-8 string codec
array codec
generic schema registry
recursive named-type resolver
session object
per-session stamp
2001 handler
2002 handler
2004 handler
3001 handler
3003 handler
3004 handler
3005 handler
3011 handler
3017 handler
3999 heartbeat handler
schema-derived simple_role defaults
```

---

# 21. Current repository package status

The project now contains the following major pieces:

```text
server/
    src/
        protocol/
        handlers/
        session/
        transport/
    config/
    README.md
    NEXT.md

protocol-data/
    packetcfg.json
    opcodes.json
    types.json
    schemas/
    protocol_report.json
    extract_packetcfg.py
```

---

# 22. Current maturity

Approximate engineering status:

```text
Client architecture          ████████████████████ 100%
Packet framing                ████████████████████ 100%
Primitive codec               ████████████████████ 100%
PacketCfg extraction          ████████████████████ 100%
Schema registry               ████████████████████ 100%

Local WebSocket server        ███████████████████░  90%
Boot/login skeleton           ███████████████░░░░░  75%
simple_role generation        ███████████░░░░░░░░░  55%
Startup push reconstruction   █████░░░░░░░░░░░░░░░  25%

Player runtime state          ███░░░░░░░░░░░░░░░░░  15%
Persistence                   ██░░░░░░░░░░░░░░░░░░  10%
Gameplay handlers             █░░░░░░░░░░░░░░░░░░░   5%
Battle engine                 ░░░░░░░░░░░░░░░░░░░░   0%
Original server validation    ░░░░░░░░░░░░░░░░░░░░   0%
```

These are engineering estimates.

---

# 23. Immediate next task

The next high-value target is:

```text
STARTUP PUSH GRAPH
```

Specifically:

1. Find every listener registered during initial startup.
2. Identify server-push opcodes handled before the client enters the home screen.
3. Determine which handlers actually mutate required models.
4. Determine which messages are optional UI/event data.
5. Implement only the mandatory startup set.

Desired result:

```text
CONNECT
 ↓
ACCOUNT_LOGIN
 ↓
SERVER_LIST
 ↓
SERVER_CHOOSE
 ↓
GAME_LOGIN
 ↓
SERVER_LOAD_SUCCESS
 ↓
CLIENT_LOAD_SUCCESS
 ↓
[REQUIRED PUSH SET]
 ↓
SERVER_PUSH_FINISH
 ↓
LANG_CHANGE
 ↓
HOME READY
```

---

# 24. After startup succeeds

Once the client reaches its home/game state:

```text
capture client requests
        ↓
map request opcode
        ↓
read exact c/s schema
        ↓
identify model consumer
        ↓
implement handler
        ↓
populate runtime state from static config
```

Prioritize:

```text
Role
Bag / inventory
Hero list
Currency
Home data
Main progression
```

Then expand:

```text
Shop
Battle
Dungeon
Guild
Arena
Events
Chat
Friends
Mail
```

---

# 25. Safety / scope boundary

The server implementation is intended for a local replacement/test environment.

Do not copy production secrets or bypass production authentication, payment
verification, anti-cheat, or authorization mechanisms.

Where production-only behavior is unknown, the replacement server should use an
explicit local implementation.

---

# 26. One-line project status

> **We have reconstructed the client protocol and its complete schema registry; we now have a functioning local WebSocket server skeleton and a partially reconstructed boot path, with the next major target being the mandatory initial server-push graph and a fully usable player state.**


---

# v0.6 update

## GitHub source checked

Repository:
`alonesitegamer/over-power-champion-quest`

The repository contains the original extracted client assets, including:

- `assets/index.html`
- `assets/js/main.min_d9762b67.js`
- `assets/js/socket.min_afab9be.js`
- `assets/versionAutoGen.2022111701.js`
- `assets/resource/`
- APK classes and Android packaging data

The raw main bundle is confirmed in the repository, but the connector's code-search
index returned no text hits for `SERVER_PUSH_FINISH` inside the minified file.
Therefore this pass did not fabricate a push ordering from an unsuccessful search.

## v0.6 protocol/boot conclusion

The client-side boot gate remains:

```text
3003
  ↓
3004 + simple_role
  ↓
server push phase
  ↓
3011 SERVER_PUSH_FINISH
  ↓
3017 LANG_CHANGE
```

The mandatory middle push set is still an explicit reverse-engineering target.

## Current recommendation

Keep the replacement server's push implementation minimal until those source
listeners/consumers are identified.


---

# v0.7 startup trace update

The extracted client bundle was searched locally rather than relying on the
GitHub content-search index. New client evidence establishes:

- `3014 CONTROL_INFO` and `3015 RES_CONTROL` are registered immediately around
  the game-server `3001 GAME_LOGIN` request. Their presence is confirmed, but
  their ordering relative to `3011` is not.
- `3010 HOME_ICON_INFO` and `3012 ENTRANCE_COUNTDOWN_LIST` are consumed by
  `MainPanelProxyCls`, but handler registration does not prove a mandatory
  first-login push.
- `3019 SEND_ROLE_REG_TIMESTAMP` has explicit request/response handling.
- `3020 CLIENT_CONFIG_LIST` is consumed by `ServerStoreCls`; its ordering before
  the push-finished gate is still unproven.

The server therefore remains at the minimum falsifiable `3011` push baseline.
No unobserved production packet ordering has been hard-coded.


---

# v1.9 local endpoint decision

For local replacement testing, the project uses:

```text
pokemonburst.test:30001
```

This is intentionally distinct from the former production endpoint
`mon-1.frstinta.com:30001`.

The replacement server still binds to:

```text
127.0.0.1:30001
```

The client reaches it through the local hostname mapping.

This is a local development choice, not a claim about any production endpoint.


---

# v2.0 real-client stage

Official local replacement endpoint:

```text
ryure:30001
```

Server bind:

```text
127.0.0.1:30001
```

Purpose:

- clear separation from the old production endpoint;
- easy local hostname mapping;
- client-facing endpoint for the real-client experiment.

The synthetic boot chain is already proven through `3017`; v2.0 shifts the
project toward observing the real client and implementing only the states it
actually requires.


---

# v2.3 routing fix

`2004 SERVER_CHOOSE` now returns:

```text
ip=ryure
port=30001
```

This matches the client logic that constructs `ip:port` and calls the game
server connector after server selection.
