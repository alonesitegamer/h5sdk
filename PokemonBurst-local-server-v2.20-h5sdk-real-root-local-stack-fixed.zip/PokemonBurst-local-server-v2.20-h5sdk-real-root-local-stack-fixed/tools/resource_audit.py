#!/usr/bin/env python3
"""
Audit the local extracted Pokémon Burst resource tree.

The game uses logical resource names in manifests and may resolve them to
hashed runtime filenames. This tool compares:
  1) manifest/resource references
  2) local files
  3) runtime hashed names seen in JS/HTML/logs

It deliberately does not rename or copy files.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Iterable


HASHED_RE = re.compile(
    r'([A-Za-z0-9][A-Za-z0-9_.-]*?)_([0-9a-f]{8})(\.[A-Za-z0-9]{1,8})'
)

REQUESTED_RE = re.compile(
    r'([A-Za-z0-9][A-Za-z0-9_.-]*?_[0-9a-f]{8}\.[A-Za-z0-9]{1,8})'
)


def iter_files(root: Path) -> Iterable[Path]:
    if not root.exists():
        return
    yield from (p for p in root.rglob("*") if p.is_file())


def collect_strings(obj):
    if isinstance(obj, dict):
        for v in obj.values():
            yield from collect_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from collect_strings(v)
    elif isinstance(obj, str):
        yield obj


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"[WARN] could not parse {path}: {exc}")
        return None


def manifest_urls(obj) -> set[str]:
    out: set[str] = set()
    if isinstance(obj, dict):
        url = obj.get("url")
        if isinstance(url, str):
            out.add(url)
        for v in obj.values():
            out |= manifest_urls(v)
    elif isinstance(obj, list):
        for v in obj:
            out |= manifest_urls(v)
    return out


def path_variants(url: str) -> list[str]:
    url = url.replace("\\", "/").lstrip("./")
    variants = {url}

    # Runtime resource trees conventionally begin under assets/.
    if not url.startswith("assets/"):
        variants.add("assets/" + url)

    return sorted(variants)


def search_runtime_refs(root: Path) -> dict[str, set[str]]:
    refs: dict[str, set[str]] = {}
    for path in iter_files(root):
        if path.suffix.lower() not in {".js", ".html", ".json", ".txt", ".log"}:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for match in REQUESTED_RE.finditer(text):
            name = match.group(1)
            refs.setdefault(name, set()).add(str(path))
    return refs


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("root", type=Path)
    ap.add_argument(
        "--manifest",
        action="append",
        default=[],
        help="JSON manifest path relative to root; may be repeated."
    )
    ap.add_argument(
        "--runtime-root",
        type=Path,
        default=None,
        help="Directory to search for hashed runtime references."
    )
    args = ap.parse_args()

    root = args.root.resolve()
    if not root.exists():
        raise SystemExit(f"Root does not exist: {root}")

    resource_root = root / "assets" / "resource"
    if not resource_root.exists():
        print(f"[WARN] no resource root at {resource_root}")

    local_files = {
        str(p.relative_to(root)).replace("\\", "/")
        for p in iter_files(root)
    }
    basename_map: dict[str, list[str]] = {}
    for rel in local_files:
        basename_map.setdefault(Path(rel).name, []).append(rel)

    expected: set[str] = set()

    manifests = args.manifest
    if not manifests:
        manifests = [
            "assets/resource/preload_210484c.json",
            "assets/resource/default.res_2a1787f7.json",
        ]

    print("=== POKÉMON BURST RESOURCE AUDIT v2.10 ===")
    print(f"ROOT: {root}")
    print(f"LOCAL FILES: {len(local_files)}")
    print()

    for rel in manifests:
        path = root / rel
        if not path.exists():
            print(f"[MISSING MANIFEST] {rel}")
            continue

        obj = load_json(path)
        if obj is None:
            continue

        urls = manifest_urls(obj)
        expected |= urls

        print(f"[MANIFEST] {rel}")
        print(f"  URLs: {len(urls)}")

        missing = []
        found = []
        for url in sorted(urls):
            candidates = path_variants(url)
            if any(c in local_files for c in candidates):
                found.append(url)
            else:
                missing.append(url)

        print(f"  FOUND:   {len(found)}")
        print(f"  MISSING: {len(missing)}")

        for url in missing[:80]:
            print(f"    MISS {url}")

        if len(missing) > 80:
            print(f"    ... {len(missing)-80} more")

        print()

    runtime_root = args.runtime_root.resolve() if args.runtime_root else root
    refs = search_runtime_refs(runtime_root)

    print("=== RUNTIME HASHED REFERENCES ===")
    print(f"REFERENCES: {len(refs)}")

    for name, sources in sorted(refs.items()):
        stem = Path(name).stem
        m = HASHED_RE.fullmatch(name)
        if not m:
            continue

        logical = m.group(1)
        hash8 = m.group(2)
        ext = m.group(3)

        unhash = logical[:-(len(hash8)+1)] + ext

        local_hashed = [
            r for r in local_files
            if Path(r).name == name
        ]
        local_plain = basename_map.get(unhash, [])

        print()
        print(f"{name}")
        print(f"  logical candidate: {unhash}")
        print(f"  hash: {hash8}")
        print(f"  hashed local: {'YES' if local_hashed else 'NO'}")
        print(f"  plain local:  {'YES' if local_plain else 'NO'}")
        for s in sorted(sources)[:5]:
            print(f"  seen in: {s}")

    print()
    print("=== TARGET CHECKS ===")

    targets = [
        "viAgeIcon_45bd60dd.png",
        "explore_bg_2ddff2dd.jpg",
    ]

    for target in targets:
        hits = [r for r in local_files if Path(r).name == target]
        print(f"{target}: {'FOUND' if hits else 'NOT FOUND'}")
        for h in hits:
            print(f"  {h}")

    print()
    print("No files were renamed or modified.")
    print("Use the findings to identify the hash/version mapping first.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
