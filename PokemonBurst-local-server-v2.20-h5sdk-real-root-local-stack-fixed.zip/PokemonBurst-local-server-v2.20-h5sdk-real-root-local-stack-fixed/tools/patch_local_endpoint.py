#!/usr/bin/env python3
import argparse
from pathlib import Path

def main():
    p = argparse.ArgumentParser(description="Patch a LOCAL copy of the client endpoint.")
    p.add_argument("source", type=Path)
    p.add_argument("dest", type=Path)
    p.add_argument("--old", default="mon-1.frstinta.com:30001")
    p.add_argument("--new", default="ryure:30001")
    args = p.parse_args()

    data = args.source.read_text(encoding="utf-8")
    if args.old not in data:
        raise SystemExit(
            f"Target not found: {args.old}\n"
            "Search the local client/bootstrap for its current endpoint first."
        )

    args.dest.parent.mkdir(parents=True, exist_ok=True)
    count = data.count(args.old)
    args.dest.write_text(data.replace(args.old, args.new), encoding="utf-8")
    print(f"Patched {count} occurrence(s): {args.old} -> {args.new}")

if __name__ == "__main__":
    main()
