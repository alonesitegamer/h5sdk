#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, re, shutil, subprocess, tempfile
from pathlib import Path

REPO_URL="https://github.com/alonesitegamer/over-power-champion-quest.git"
MAP_RE=re.compile(r'"(resource/[^"]+?)":"([0-9a-f]{8})"')
HASHED_NAME_RE=re.compile(r"^(?P<stem>.+)_(?P<hash>[0-9a-f]{8})(?P<ext>\.[^.]+)?$")

def run(cmd):
    print("$"," ".join(cmd))
    subprocess.run(cmd,check=True)

def clone():
    td=tempfile.TemporaryDirectory(prefix="pokemonburst-github-")
    repo=Path(td.name)/"repo"
    run(["git","clone","--depth","1","--branch","main",REPO_URL,str(repo)])
    return repo,td

def parse_map(path):
    s=path.read_text(encoding="utf-8",errors="ignore")
    return dict(MAP_RE.findall(s))

def inventory(root):
    out={}
    for p in (root/"assets/resource").rglob("*"):
        if not p.is_file(): continue
        rel=p.relative_to(root/"assets/resource").as_posix()
        out.setdefault(rel,[]).append(p)
    return out

def find_physical(repo_resource, logical_rel, expected_hash):
    # logical_rel begins resource/...
    rel=Path(logical_rel).relative_to("resource")
    direct=repo_resource/rel
    if direct.is_file():
        return direct

    parent=repo_resource/rel.parent
    wanted_stem=rel.stem
    wanted_ext=rel.suffix

    if not parent.exists(): return None

    # The GitHub repo stores physical assets with their own hash suffix.
    for p in parent.iterdir():
        if not p.is_file(): continue
        if p.suffix != wanted_ext: continue
        m=HASHED_NAME_RE.match(p.name)
        if not m: continue
        if m.group("stem")==wanted_stem:
            # Prefer exact versionAutoGen hash when present, otherwise the only
            # physical hashed variant.
            if m.group("hash")==expected_hash:
                return p

    candidates=[]
    for p in parent.iterdir():
        if p.is_file() and p.suffix==wanted_ext:
            m=HASHED_NAME_RE.match(p.name)
            if m and m.group("stem")==wanted_stem:
                candidates.append(p)

    if len(candidates)==1:
        return candidates[0]

    return None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--source-dir",type=Path)
    ap.add_argument("--target",type=Path,default=Path("/home/ryure/analyze-apk/output/apktool"))
    ap.add_argument("--dry-run",action="store_true")
    ap.add_argument("--overwrite",action="store_true")
    ap.add_argument("--report",type=Path,default=Path("resource_rebuild_report.json"))
    args=ap.parse_args()

    temp=None
    if args.source_dir:
        repo=args.source_dir.resolve()
    else:
        repo,temp=clone()

    try:
        version=repo/"assets/versionAutoGen.2022111701.js"
        resource=repo/"assets/resource"
        target= args.target.resolve()/"assets/resource"
        mapping=parse_map(version)

        if not resource.exists():
            raise SystemExit(f"Missing repo resource tree: {resource}")

        report={"mapping_entries":len(mapping),"resolved":0,"copied":0,
                "existing":0,"missing":0,"ambiguous":0,"entries":[]}

        for logical,expected_hash in sorted(mapping.items()):
            src=find_physical(resource,logical,expected_hash)
            if src is None:
                report["missing"]+=1
                report["entries"].append({"logical":logical,"hash":expected_hash,"status":"missing"})
                continue

            rel=Path(logical).relative_to("resource")
            desired=rel.parent/(rel.stem+"_"+expected_hash+rel.suffix)
            dst=target/desired

            if not args.dry_run:
                dst.parent.mkdir(parents=True,exist_ok=True)
                if dst.exists() and not args.overwrite:
                    status="existing"
                    report["existing"]+=1
                else:
                    shutil.copy2(src,dst)
                    status="copied"
                    report["copied"]+=1
            else:
                status="dry_run"

            report["resolved"]+=1
            report["entries"].append({
                "logical":logical,
                "hash":expected_hash,
                "source":str(src.relative_to(repo)).replace("\\","/"),
                "target":str((Path("assets/resource")/desired)).replace("\\","/"),
                "status":status
            })

        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")

        print("\n=== RESOURCE REBUILD v2.13 ===")
        for k in ["mapping_entries","resolved","copied","existing","missing"]:
            print(f"{k.title():18}: {report[k]}")
        print(f"Report: {args.report.resolve()}")

        checks=[
            target/"assets/gameui/0_login/viAgeIcon_45bd60dd.png",
            target/"assets/gameui/46_explore/explore_bg_2ddff2dd.jpg"
        ]
        print("\n=== REQUIRED TARGETS ===")
        for p in checks:
            print(f"{p}: {'FOUND' if p.exists() else 'MISSING'}")
    finally:
        if temp: temp.cleanup()

if __name__=="__main__":
    main()
