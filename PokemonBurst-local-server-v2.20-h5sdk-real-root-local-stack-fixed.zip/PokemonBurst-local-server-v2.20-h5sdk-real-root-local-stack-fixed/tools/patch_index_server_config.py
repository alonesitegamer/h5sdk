#!/usr/bin/env python3
import argparse,re
from pathlib import Path
ap=argparse.ArgumentParser()
ap.add_argument("source",type=Path); ap.add_argument("dest",type=Path)
ap.add_argument("--new-host",default="ryure"); ap.add_argument("--new-port",default="30001")
a=ap.parse_args()
d=a.source.read_text(encoding="utf-8")
m=re.search(r'window\.SERVER_CONFIG\s*=\s*\["[^"]+"\]',d)
if not m: raise SystemExit("window.SERVER_CONFIG not found")
d=d[:m.start()]+f'window.SERVER_CONFIG    = ["{a.new_host}:{a.new_port}"]'+d[m.end():]
d,n=re.subn(r'window\["SERVER"\s*\+\s*"_CONFIG"\]\s*=\s*\t?\["mon-1\.frstinta\.com:30002"\]',
            f'window["SERVER" + "_CONFIG"] = ["{a.new_host}:{a.new_port}"]',d)
a.dest.parent.mkdir(parents=True,exist_ok=True); a.dest.write_text(d,encoding="utf-8")
print(f"patched SERVER_CONFIG and {n} preview override(s) -> {a.new_host}:{a.new_port}")
