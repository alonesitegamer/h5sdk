# Direct CDN Mirror

This tool downloads the resources listed by the 2024 `versionAutoGen` map directly from the CDN.

It does **not** wait for the game to unlock a feature or request an asset.

## First: dry run

```bash
cd ~/pokemonburst-replacement-server-v2.13

python3 tools/mirror_cdn.py \
  --version-map /path/to/versionAutoGen.20241024736__v_20241024736.js \
  --output /path/to/cdn-mirror \
  --dry-run
```

## Full mirror

```bash
python3 tools/mirror_cdn.py \
  --version-map /path/to/versionAutoGen.20241024736__v_20241024736.js \
  --output /path/to/cdn-mirror \
  --workers 12 \
  --include-bootstrap
```

Default CDN:

```text
https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/
```

The tool reconstructs the physical hashed filename. For example:

```text
resource/assets_en/bones/effect/b3004_ske.dbbin
+ 81a1dfbc
+ 20241024736

↓

resource/assets_en/bones/effect/b3004_ske_81a1dfbc__v_20241024736.dbbin
```

This matches the physical naming scheme present in the supplied 2024 CDN snapshot.

## Useful filters

English resources only:

```bash
--only resource/assets_en/
```

Base resources only:

```bash
--only resource/assets/
```

Configuration only:

```bash
--only resource/config
--only resource/config_br
--only resource/i18n
```

Exclude a family:

```bash
--exclude resource/assets_ru/
```

## Resume behavior

The tool skips any existing non-empty file. Results are recorded in:

```text
.cdn-mirror-results.jsonl
.cdn-mirror-summary.json
```

So if the connection dies halfway through a 40k-file run, rerun the exact command. It will continue rather than starting over.

## Recommended first run

Because this is a large CDN, start conservatively:

```bash
--workers 8
```

After confirming the CDN is happy, increase to `12` or `16`. Do not hammer the server with hundreds of simultaneous requests.

## Important

The script mirrors resources listed by `versionAutoGen`. It does not claim that every possible file on the CDN is indexed there. Unmapped files require separate discovery.
