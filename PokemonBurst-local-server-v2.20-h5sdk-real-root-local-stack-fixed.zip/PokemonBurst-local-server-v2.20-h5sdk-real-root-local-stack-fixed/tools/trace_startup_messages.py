#!/usr/bin/env python3
"""Scan an extracted/minified client bundle for startup message consumers.

Usage:
  python tools/trace_startup_messages.py /path/to/main.min.js > trace.txt

This is deliberately a locator, not a decompiler. It prints compact context
around opcode names and handler method names so a human can verify ordering.
"""
from pathlib import Path
import re, sys

TERMS = [
    "SERVER_LOAD_SUCCESS", "CLIENT_LOAD_SUCCESS", "SERVER_PUSH_FINISH",
    "CONTROL_INFO", "RES_CONTROL", "HOME_ICON_INFO",
    "ENTRANCE_COUNTDOWN_LIST", "ENTRANCE_COUNTDOWN_CHANGE",
    "UC_UPLOAD_INFO", "LANG_CHANGE", "SEND_ROLE_REG_TIMESTAMP",
    "CLIENT_CONFIG_LIST", "CLIENT_CONFIG_SET", "CLIENT_CONFIG_SET_ACC",
]

if len(sys.argv) != 2:
    raise SystemExit(f"usage: {sys.argv[0]} <bundle.js>")

p = Path(sys.argv[1])
s = p.read_text(encoding="utf-8", errors="ignore")
print(f"FILE {p} BYTES {p.stat().st_size}")
for term in TERMS:
    hits = list(re.finditer(re.escape(term), s))
    print(f"\n## {term} count={len(hits)}")
    for n,m in enumerate(hits[:8],1):
        a=max(0,m.start()-450); b=min(len(s),m.end()+900)
        snippet=' '.join(s[a:b].split())
        print(f"[{n}] {snippet}")
