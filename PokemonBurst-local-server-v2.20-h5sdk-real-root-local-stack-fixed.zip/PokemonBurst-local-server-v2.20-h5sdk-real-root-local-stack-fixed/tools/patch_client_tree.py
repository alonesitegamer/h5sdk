#!/usr/bin/env python3
import argparse
from pathlib import Path
import shutil

TEXT_EXTS = {
    ".html",".htm",".js",".json",".txt",".xml",".cfg",".ini",".plist",
    ".ts",".css",".properties",".smali"
}

def main():
    ap = argparse.ArgumentParser(description="Patch a LOCAL COPY of the extracted client tree.")
    ap.add_argument("source", type=Path, help="client tree to copy")
    ap.add_argument("dest", type=Path, help="output client tree")
    ap.add_argument("--old", default="mon-1.frstinta.com:30001")
    ap.add_argument("--new", default="ryure:30001")
    args = ap.parse_args()

    if not args.source.exists():
        raise SystemExit(f"Source does not exist: {args.source}")

    if args.dest.exists():
        raise SystemExit(f"Destination already exists: {args.dest}")

    shutil.copytree(args.source, args.dest)
    changed = []
    scanned = 0

    for p in args.dest.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in TEXT_EXTS:
            continue
        try:
            data = p.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue

        scanned += 1
        count = data.count(args.old)
        if count:
            p.write_text(data.replace(args.old, args.new), encoding="utf-8")
            changed.append((str(p.relative_to(args.dest)), count))

    print(f"Scanned text files: {scanned}")
    print(f"Changed files: {len(changed)}")
    for rel, count in changed:
        print(f"  {rel}: {count} replacement(s)")

    if not changed:
        print("WARNING: old endpoint was not found in the copied tree.")
        print("Search for the current/new endpoint string before patching.")
    else:
        print(f"Patched LOCAL copy: {args.old} -> {args.new}")

if __name__ == "__main__":
    main()
