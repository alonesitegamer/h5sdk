#!/usr/bin/env python3
from pathlib import Path
import argparse

PROBE = r"""
<script>
(function () {
  if (window.__RYURE_LOGIN_PROBE__) return;
  window.__RYURE_LOGIN_PROBE__ = true;

  function out(...args) {
    try { console.log("[RYURE-LOGIN]", ...args); } catch (_) {}
  }

  out("PROBE_INSTALLED");

  function inspect() {
    try {
      const root = window.kdyg || window.Kdyg || window.game || window.Game;
      out("GLOBAL_KEYS", root ? Object.keys(root).slice(0,120) : []);
      const candidates = [
        root?.GameLaunch,
        window.GameLaunch,
        root?.GameLaunchCls,
      ];
      for (const c of candidates) {
        if (!c) continue;
        out("GAME_LAUNCH_FOUND", c, Object.getOwnPropertyNames(c.prototype || c));
        if (c.prototype?.startLogin) {
          const original = c.prototype.startLogin;
          if (!c.prototype.__RYURE_START_LOGIN_WRAPPED__) {
            c.prototype.__RYURE_START_LOGIN_WRAPPED__ = true;
            c.prototype.startLogin = function (...args) {
              out("START_LOGIN_CALLED", {
                isStartLogin: this._isStartLogin,
                isConnectLogin: this._isConnectLogin,
                isInitSDK: this._isInitSDK,
                accountId: this._accountData?.accountId
              });
              return original.apply(this, args);
            };
          }
        }
      }
    } catch (e) {
      out("INSPECT_ERROR", String(e));
    }
  }

  window.__RYURE_LOGIN_INSPECT__ = inspect;
  setTimeout(inspect, 1000);
  setTimeout(inspect, 3000);
  setTimeout(inspect, 6000);
})();
</script>
"""

ap=argparse.ArgumentParser()
ap.add_argument("source",type=Path)
ap.add_argument("dest",type=Path)
args=ap.parse_args()

data=args.source.read_text(encoding="utf-8")
idx=data.lower().find("</head>")
if idx<0:
    idx=data.lower().find("<body")
if idx<0:
    data=PROBE+data
else:
    data=data[:idx]+PROBE+data[idx:]
args.dest.parent.mkdir(parents=True,exist_ok=True)
args.dest.write_text(data,encoding="utf-8")
print(f"Wrote login probe page: {args.dest}")
