#!/usr/bin/env python3
from pathlib import Path
import argparse

PROBE = r"""
<script>
(function () {
  if (window.__RYURE_LOGIN_CALL_PROBE__) return;
  window.__RYURE_LOGIN_CALL_PROBE__ = true;

  function log(...a) {
    try { console.log("[RYURE-CALL]", ...a); } catch (_) {}
  }

  log("INSTALLED");

  function wrapGameLaunch() {
    try {
      const root = window.kdyg || window.Kdyg;
      const C = root && root.GameLaunch;
      if (!C || !C.prototype) {
        log("GAME_LAUNCH_NOT_READY");
        return false;
      }

      const names = [
        "_accountLogin",
        "startLogin",
        "_onConnectLoginServer",
        "init",
        "_initSDK"
      ];

      for (const name of names) {
        const fn = C.prototype[name];

        if (typeof fn !== "function") {
          log("MISSING", name);
          continue;
        }

        const mark = "__RYURE_WRAPPED_" + name;

        if (fn[mark]) {
          continue;
        }

        const wrapped = function (...args) {
          log("CALL", name, {
            isStartLogin: this._isStartLogin,
            isConnectLogin: this._isConnectLogin,
            isInitSDK: this._isInitSDK,
            isLoadPreload: this._isLoadPreload,
            isLoadDefaultRes: this._isLoadDefaultRes,
            isLoadPacket: this._isLoadPacket
          });

          const result = fn.apply(this, args);

          log("RETURN", name, {
            isStartLogin: this._isStartLogin,
            isConnectLogin: this._isConnectLogin,
            isInitSDK: this._isInitSDK
          });

          return result;
        };

        wrapped[mark] = true;
        C.prototype[name] = wrapped;

        log("WRAPPED", name);
      }

      return true;
    } catch (e) {
      log("WRAP_ERROR", String(e));
      return false;
    }
  }

  let tries = 0;
  const timer = setInterval(() => {
    tries++;

    if (wrapGameLaunch() || tries >= 30) {
      clearInterval(timer);
    }
  }, 500);

  window.__RYURE_WRAP_GAME_LOGIN__ = wrapGameLaunch;
})();
</script>
"""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source", type=Path)
    ap.add_argument("dest", type=Path)
    args = ap.parse_args()

    if not args.source.exists():
        raise SystemExit(f"Source does not exist: {args.source}")

    data = args.source.read_text(encoding="utf-8")
    marker = "</head>"
    idx = data.lower().find(marker)

    if idx >= 0:
        out = data[:idx] + PROBE + data[idx:]
    else:
        out = PROBE + data

    args.dest.parent.mkdir(parents=True, exist_ok=True)
    args.dest.write_text(out, encoding="utf-8")

    print(f"Wrote: {args.dest}")

if __name__ == "__main__":
    main()
