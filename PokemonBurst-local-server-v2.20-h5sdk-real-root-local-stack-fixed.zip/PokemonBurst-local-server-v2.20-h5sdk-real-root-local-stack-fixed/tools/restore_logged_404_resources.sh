#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
LIST_FILE="${1:-$ROOT_DIR/tools/resource-recovery/404-local-urls.txt}"
CDN_ROOT="${CDN_ROOT:-$HOME/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w}"
PUBLIC_BASE="${PUBLIC_BASE:-https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w}"

[[ -f "$LIST_FILE" ]] || { echo "missing list: $LIST_FILE" >&2; exit 1; }
mkdir -p "$CDN_ROOT"

ok=0
fail=0
while IFS= read -r local_url; do
  [[ -z "$local_url" ]] && continue
  path="${local_url#http://127.0.0.1:8090}"
  path="${path%%\?*}"
  [[ "$path" == /* ]] || continue
  dest="$CDN_ROOT$path"
  url="$PUBLIC_BASE$path"
  mkdir -p "$(dirname "$dest")"
  if [[ -s "$dest" ]]; then
    echo "[skip] $path"
    ok=$((ok+1))
    continue
  fi
  echo "[fetch] $url"
  if curl -fL --retry 2 --connect-timeout 10 --max-time 60 -o "$dest.tmp" "$url"; then
    mv "$dest.tmp" "$dest"
    ok=$((ok+1))
  else
    rm -f "$dest.tmp"
    echo "[FAIL] $path" >&2
    fail=$((fail+1))
  fi
done < "$LIST_FILE"

echo "[restore] ok=$ok failed=$fail"
(( fail == 0 ))
