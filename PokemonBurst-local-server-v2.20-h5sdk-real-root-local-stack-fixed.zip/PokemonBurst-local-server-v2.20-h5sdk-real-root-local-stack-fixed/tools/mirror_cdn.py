#!/usr/bin/env python3
"""
Mirror a complete Egret CDN resource tree from versionAutoGen.

Designed for the 2024 Pokémon Burst / Egret CDN layout where:

    logical: resource/assets_en/gameui/foo.png
    hash:    12345678

is served as:

    resource/assets_en/gameui/foo_12345678__v_20241024736.png

The script downloads the mapped resources directly from the CDN without
requiring the game to request/unlock each resource first.

Features:
- parses versionAutoGen automatically
- downloads ALL mapped resource entries
- preserves the logical directory tree
- reconstructs hashed CDN filenames
- bounded concurrency
- retries with exponential backoff
- skips files already present
- writes JSONL results for resumability/auditing
- supports --dry-run
- supports --only / --exclude prefix filters
- also mirrors root JS/manifest files when --include-bootstrap is used

No third-party Python package is required.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import re
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urljoin
from urllib.request import Request, urlopen


ENTRY_RE = re.compile(r'"([^"]+)":"([0-9a-f]{7,8})"')
DEFAULT_VERSION_RE = re.compile(r"versionAutoGen\.(\d+)")


def parse_args():
    p = argparse.ArgumentParser(
        description="Mirror all resources listed by an Egret versionAutoGen file."
    )
    p.add_argument(
        "--version-map",
        required=True,
        help="Path to versionAutoGen.*.js",
    )
    p.add_argument(
        "--cdn",
        default="https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w/",
        help="CDN root URL, ending in /",
    )
    p.add_argument(
        "--output",
        required=True,
        help="Local mirror root directory",
    )
    p.add_argument(
        "--workers",
        type=int,
        default=12,
        help="Concurrent downloads (default: 12)",
    )
    p.add_argument(
        "--retries",
        type=int,
        default=4,
        help="Retries per file after the first attempt (default: 4)",
    )
    p.add_argument(
        "--timeout",
        type=float,
        default=30,
        help="HTTP timeout in seconds (default: 30)",
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Print planned downloads without downloading",
    )
    p.add_argument(
        "--only",
        action="append",
        default=[],
        help="Only download logical paths beginning with this prefix. Repeatable.",
    )
    p.add_argument(
        "--exclude",
        action="append",
        default=[],
        help="Exclude logical paths beginning with this prefix. Repeatable.",
    )
    p.add_argument(
        "--include-bootstrap",
        action="store_true",
        help="Also download the JS/bootstrap files at the CDN root.",
    )
    p.add_argument(
        "--user-agent",
        default="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/150 Safari/537.36",
    )
    return p.parse_args()


def safe_rel(path: str) -> str:
    path = path.replace("\\", "/").lstrip("/")
    if "\x00" in path or ".." in Path(path).parts:
        raise ValueError(f"unsafe path: {path!r}")
    return path


def physical_path(logical: str, digest: str, version: str) -> str:
    """
    Convert:
        resource/assets_en/foo/bar.png
        12345678
    to:
        resource/assets_en/foo/bar_12345678__v_VERSION.png

    Also handles extensionless files.
    """
    logical = safe_rel(logical)
    parent, _, name = logical.rpartition("/")
    stem, dot, ext = name.rpartition(".")
    if dot:
        physical = f"{stem}_{digest}__v_{version}.{ext}"
    else:
        physical = f"{name}_{digest}__v_{version}"
    return f"{parent}/{physical}" if parent else physical


def extract_entries(text: str):
    entries = []
    seen = set()

    for logical, digest in ENTRY_RE.findall(text):
        if not logical.startswith("resource/"):
            continue
        if logical in seen:
            continue
        seen.add(logical)
        entries.append((logical, digest))

    return entries


def infer_version(version_map: Path, text: str) -> str:
    m = DEFAULT_VERSION_RE.search(version_map.name)
    if m:
        return m.group(1)

    # Fallback for differently named maps.
    m = re.search(r"__v_(\d+)", text[:1000])
    if m:
        return m.group(1)

    raise RuntimeError(
        "Could not infer build version. Rename the version map or extend infer_version()."
    )


def should_download(logical: str, only: list[str], exclude: list[str]) -> bool:
    if only and not any(logical.startswith(x) for x in only):
        return False
    if any(logical.startswith(x) for x in exclude):
        return False
    return True


def url_for(cdn: str, rel: str) -> str:
    # Quote each path segment but keep '/'.
    encoded = "/".join(quote(part, safe="") for part in rel.split("/"))
    return urljoin(cdn.rstrip("/") + "/", encoded)


def download_one(item, args, version, out_root, headers):
    logical, digest = item
    physical = physical_path(logical, digest, version)

    # Store files under the physical CDN filename, because that is what the
    # browser actually requests. The logical path remains in the result log.
    destination = out_root / physical
    destination.parent.mkdir(parents=True, exist_ok=True)

    if destination.exists() and destination.stat().st_size > 0:
        return {
            "logical": logical,
            "physical": physical,
            "status": "exists",
            "url": url_for(args.cdn, physical),
            "bytes": destination.stat().st_size,
        }

    if args.dry_run:
        return {
            "logical": logical,
            "physical": physical,
            "status": "planned",
            "url": url_for(args.cdn, physical),
        }

    tmp = destination.with_name(destination.name + ".part")

    last_error = None
    for attempt in range(args.retries + 1):
        try:
            req = Request(url_for(args.cdn, physical), headers=headers)
            with urlopen(req, timeout=args.timeout) as r:
                data = r.read()

            if not data:
                raise RuntimeError("empty response")

            with open(tmp, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())

            os.replace(tmp, destination)

            return {
                "logical": logical,
                "physical": physical,
                "status": "downloaded",
                "url": url_for(args.cdn, physical),
                "bytes": len(data),
            }

        except (HTTPError, URLError, TimeoutError, OSError, RuntimeError) as e:
            last_error = f"{type(e).__name__}: {e}"
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass

            if attempt < args.retries:
                time.sleep(min(2 ** attempt, 10))

    return {
        "logical": logical,
        "physical": physical,
        "status": "failed",
        "url": url_for(args.cdn, physical),
        "error": last_error,
    }


def write_result(log_path: Path, result: dict):
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(result, ensure_ascii=False) + "\n")


def main():
    args = parse_args()

    version_map = Path(args.version_map).expanduser().resolve()
    out_root = Path(args.output).expanduser().resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    if not version_map.is_file():
        print(f"[FATAL] version map not found: {version_map}", file=sys.stderr)
        return 2

    text = version_map.read_text(encoding="utf-8", errors="ignore")
    version = infer_version(version_map, text)
    entries = extract_entries(text)

    selected = [
        item for item in entries
        if should_download(item[0], args.only, args.exclude)
    ]

    print("=== CDN MIRROR ===")
    print(f"CDN       : {args.cdn}")
    print(f"VERSION   : {version}")
    print(f"MAP       : {len(entries):,} resource entries")
    print(f"SELECTED  : {len(selected):,}")
    print(f"OUTPUT    : {out_root}")
    print(f"WORKERS   : {args.workers}")
    print(f"DRY RUN   : {args.dry_run}")

    if not selected:
        print("[DONE] Nothing selected.")
        return 0

    result_log = out_root / ".cdn-mirror-results.jsonl"

    headers = {
        "User-Agent": args.user_agent,
        "Accept": "*/*",
        "Accept-Encoding": "identity",
        "Connection": "keep-alive",
    }

    if args.dry_run:
        for logical, digest in selected:
            physical = physical_path(logical, digest, version)
            print(f"{logical} -> {physical}")
        print(f"[DRY-RUN] {len(selected):,} files planned.")
        return 0

    counts = {"downloaded": 0, "exists": 0, "failed": 0}
    failures = []

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=max(1, args.workers)
    ) as pool:
        futures = [
            pool.submit(
                download_one,
                item,
                args,
                version,
                out_root,
                headers,
            )
            for item in selected
        ]

        total = len(futures)
        for i, future in enumerate(concurrent.futures.as_completed(futures), 1):
            result = future.result()
            write_result(result_log, result)

            status = result["status"]
            counts[status] = counts.get(status, 0) + 1

            if status == "failed":
                failures.append(result)
                print(
                    f"[{i}/{total}] FAIL {result['logical']} :: {result.get('error')}",
                    flush=True,
                )
            elif i % 100 == 0 or i == total:
                print(
                    f"[{i}/{total}] downloaded={counts.get('downloaded',0)} "
                    f"existing={counts.get('exists',0)} "
                    f"failed={counts.get('failed',0)}",
                    flush=True,
                )

    if args.include_bootstrap:
        bootstrap_names = [
            "versionAutoGen.20241024736__v_20241024736.js",
            "js/main.min_59e25df4__v_20241024736.js",
            "js/socket.min_afab9be__v_20241024736.js",
            "js/assetsmanager.min_2ef412b7__v_20241024736.js",
            "js/egret.min_836d668b__v_20241024736.js",
            "js/egret.web.min_d1451e99__v_20241024736.js",
            "js/eui.min_493403ce__v_20241024736.js",
            "js/game.min_a9c9e7a1__v_20241024736.js",
            "js/loading.min_970e4440__v_20241024736.js",
            "js/dragonBones.min_6252b9c4__v_20241024736.js",
            "js/tween.min_6c5a88f9__v_20241024736.js",
            "js/promise.min_83a6a5d__v_20241024736.js",
            "js/default.thm_ec588d6c__v_20241024736.js",
            "resource/default.res_18f57742__v_20241024736.json",
            "resource/config_ec56b6a1__v_20241024736.json",
            "resource/i18n/language_en_d149feb2__v_20241024736.json",
        ]

        print("\n=== BOOTSTRAP FILES ===")
        for rel in bootstrap_names:
            destination = out_root / rel
            if destination.exists() and destination.stat().st_size > 0:
                print(f"[EXISTS] {rel}")
                continue

            destination.parent.mkdir(parents=True, exist_ok=True)
            try:
                req = Request(url_for(args.cdn, rel), headers=headers)
                with urlopen(req, timeout=args.timeout) as r:
                    data = r.read()
                destination.write_bytes(data)
                print(f"[OK] {rel} ({len(data):,} bytes)")
            except Exception as e:
                print(f"[FAIL] {rel}: {type(e).__name__}: {e}")

    summary = {
        "version": version,
        "cdn": args.cdn,
        "map_entries": len(entries),
        "selected": len(selected),
        "counts": counts,
        "failures": failures,
    }
    (out_root / ".cdn-mirror-summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("\n=== COMPLETE ===")
    print(f"Downloaded : {counts.get('downloaded', 0):,}")
    print(f"Existing   : {counts.get('exists', 0):,}")
    print(f"Failed     : {counts.get('failed', 0):,}")
    print(f"Results    : {result_log}")
    print(f"Summary    : {out_root / '.cdn-mirror-summary.json'}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
