#!/usr/bin/env python3
from pathlib import Path
import argparse

TRACE = r"""
<script>
(function () {
  if (window.__RYURE_WS_TRACE__) return;
  window.__RYURE_WS_TRACE__ = true;

  const NativeWebSocket = window.WebSocket;

  function trace(...args) {
    try { console.log("[RYURE-WS]", ...args); } catch (_) {}
  }

  window.WebSocket = function(url, protocols) {
    trace("CONSTRUCT", url, protocols ?? "");
    let ws;
    try {
      ws = protocols === undefined
        ? new NativeWebSocket(url)
        : new NativeWebSocket(url, protocols);
    } catch (e) {
      trace("CONSTRUCT_ERROR", String(e));
      throw e;
    }

    trace("CREATED", ws.url);

    const nativeSend = ws.send.bind(ws);
    ws.send = function(data) {
      let desc;
      try {
        if (data instanceof ArrayBuffer) {
          const u = new Uint8Array(data);
          desc = "ArrayBuffer " + data.byteLength + " " + Array.from(u.slice(0,32)).map(x=>x.toString(16).padStart(2,"0")).join("");
        } else if (ArrayBuffer.isView(data)) {
          const u = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
          desc = "View " + data.byteLength + " " + Array.from(u.slice(0,32)).map(x=>x.toString(16).padStart(2,"0")).join("");
        } else if (typeof data === "string") {
          desc = "String " + data.length + " " + data.slice(0,120);
        } else {
          desc = Object.prototype.toString.call(data);
        }
      } catch (e) {
        desc = "send-inspect-error " + String(e);
      }
      trace("SEND", ws.url, desc);
      return nativeSend(data);
    };

    ws.addEventListener("open", () => trace("OPEN", ws.url));
    ws.addEventListener("error", (e) => trace("ERROR", ws.url, e));
    ws.addEventListener("close", (e) =>
      trace("CLOSE", ws.url, e.code, e.reason)
    );

    return ws;
  };

  window.WebSocket.prototype = NativeWebSocket.prototype;
  window.WebSocket.CONNECTING = NativeWebSocket.CONNECTING;
  window.WebSocket.OPEN = NativeWebSocket.OPEN;
  window.WebSocket.CLOSING = NativeWebSocket.CLOSING;
  window.WebSocket.CLOSED = NativeWebSocket.CLOSED;

  trace("INSTALLED");
})();
</script>
"""

ap=argparse.ArgumentParser()
ap.add_argument("source",type=Path)
ap.add_argument("dest",type=Path)
a=ap.parse_args()

data=a.source.read_text(encoding="utf-8")
if "RYURE-WS" in data:
    raise SystemExit("WebSocket trace already present")

idx=data.lower().find("</head>")
if idx >= 0:
    data=data[:idx]+TRACE+data[idx:]
else:
    idx=data.lower().find("<body")
    if idx >= 0:
        data=data[:idx]+TRACE+data[idx:]
    else:
        data=TRACE+data

a.dest.parent.mkdir(parents=True,exist_ok=True)
a.dest.write_text(data,encoding="utf-8")
print(f"Injected WebSocket trace into {a.dest}")
