# Logged CDN 404 recovery

`404-local-urls.txt` is the deduplicated set of local CDN URLs observed as 404s in the 2026-09-13 browser log.

Run:

```bash
./tools/restore_logged_404_resources.sh
```

The script restores only files observed missing in that log, into the captured local CDN tree. It does not proxy requests at runtime. Existing files are left untouched.

After restoring, restart nginx if needed and rerun the browser capture. Any newly observed 404s should be appended to a new list rather than guessed.
