#!/usr/bin/env bash
set -euo pipefail
CDN_ROOT="${CDN_ROOT:-$HOME/Downloads/h5sdk/cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w}"
PUBLIC_BASE="${PUBLIC_BASE:-https://cdn.xjlgmkk.com/monster_foreign_en_maiji_h5_ios_w}"
NAME="preload_b4ed6d75.json"
DEST="$CDN_ROOT/resource/$NAME"
mkdir -p "$(dirname "$DEST")"
if [[ -s "$DEST" ]]; then echo "[seed] already present: $DEST"; exit 0; fi
echo "[seed] fetching missing runtime manifest once..."
tmp="${DEST}.tmp"
curl -fL --retry 3 --connect-timeout 10 "$PUBLIC_BASE/resource/$NAME" -o "$tmp"
test -s "$tmp"
mv "$tmp" "$DEST"
echo "[seed] installed local: $DEST"
