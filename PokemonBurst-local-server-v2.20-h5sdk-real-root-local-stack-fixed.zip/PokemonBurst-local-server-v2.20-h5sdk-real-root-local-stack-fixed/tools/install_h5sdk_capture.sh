#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DEST="${1:-$BASE_DIR/h5sdk/capture}"
REPO_URL="${H5SDK_REPO_URL:-https://github.com/alonesitegamer/h5sdk.git}"
TREE="${H5SDK_TREE:-h5sdk.camjm.space}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
command -v git >/dev/null || { echo '[h5sdk] git is required' >&2; exit 1; }
git clone --depth 1 --filter=blob:none --sparse "$REPO_URL" "$TMP/repo"
cd "$TMP/repo"
git sparse-checkout set "$TREE"
rm -rf "$DEST"
mkdir -p "$DEST"
cp -a "$TREE"/. "$DEST"/
echo "[h5sdk] installed: $DEST"
echo "[h5sdk] files: $(find "$DEST" -type f | wc -l)"
echo "[h5sdk] bytes: $(du -sb "$DEST" | awk '{print $1}')"
