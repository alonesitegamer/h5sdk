# Client evidence used in v0.7

The local extracted client search dump contains these exact structural findings:

```text
GameLaunch._onMsgGameServerReady -> send CLIENT_LOAD_SUCCESS (3004)
GameLaunch._onMsgServerPushFinish -> _isPushFinish=true -> _enterGame()
_enterGame -> RoleProxy.reqLangChange(window.defaultLanguage)

GameLaunch._onNetConnectSucceed -> listen CONTROL_INFO and RES_CONTROL -> send GAME_LOGIN (3001)

MainPanelProxyCls.init -> listen HOME_ICON_INFO, ENTRANCE_COUNTDOWN_LIST, ENTRANCE_COUNTDOWN_CHANGE

RoleProxy.init -> listen CLIENT_LOAD_SUCCESS, LANG_CHANGE, SEND_ROLE_REG_TIMESTAMP, UC_UPLOAD_INFO
RoleProxy.reqSendRoleRegTimestamp -> send SEND_ROLE_REG_TIMESTAMP
RoleProxy.reqLangChange -> send LANG_CHANGE
RoleProxy.reqUcUploadInfo -> send UC_UPLOAD_INFO

ServerStoreCls.init -> listen ACC_CONFIG_LIST and CLIENT_CONFIG_LIST
```

These findings establish consumer relationships. They do not by themselves
establish every server push ordering on a production login, which is why v0.7
does not promote every consumed opcode into the mandatory startup burst.
