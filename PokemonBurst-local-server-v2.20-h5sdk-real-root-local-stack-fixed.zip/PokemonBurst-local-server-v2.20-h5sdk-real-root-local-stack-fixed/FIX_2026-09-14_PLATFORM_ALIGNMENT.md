# Fix 2026-09-14: 2004 platform alignment

## Why
The current 2024 target bootstrap is captured in the `alonesitegamer/h5sdk`
repository. Its CDN index explicitly declares `window.platform = 330` and
`sdkName = Maiji_330_H5_A`. The local server still defaulted 2004 to the old
`308` value inherited from the historical client/source notes.

## Changes
- `config/server.env`: `PLAT_ID=330`
- `server/src/handlers/dispatch.ts`: 2004 fallback changed from 308 to 330
- `server/test-route-2004.mjs`: validates returned `plat_id` against `PLAT_ID`
- `GITHUB_SOURCE_NOTES.md`: marked old 308 source as historical and recorded the
  current 2024 source evidence
- `/mnt/data/POKEMON_BURST_AI_RULES.md`: appended the active work entry
- `/mnt/data/POKEMON_BURST_EVIDENCE_LEDGER.md`: added E019-E021

## Validation
- `nginx/` was not modified.
- The complete `tsx`/`tsc` dependency tree is still unavailable in this
  container, so the live WebSocket route test has not been executed here.
- This change is therefore not a live-proven fix yet.

## Status
**STRONGLY SUPPORTED, NOT LIVE-PROVEN.** The decisive test is whether the real
browser accepts 2004 and emits 3001 after this change.
