# Pokémon Burst Evidence Ledger

| ID | Claim | Evidence | Status | Next test |
|---|---|---|---|---|
| E001 | Target client is 20241024736 | exact client/version files | PROVEN | none |
| E002 | Protocol inventory is 1,385 opcodes + 650 types | extracted protocol JSON | PROVEN | none |
| E003 | English mirror represents 3,296/3,298 candidates | Phase 7 report/DB | PROVEN | only revisit if runtime requests missing assets |
| E004 | Real browser sends 2001 | raw WS trace | PROVEN | inspect next transition |
| E005 | Real browser sends 2005 | raw WS trace | PROVEN | determine exact required response |
| E006 | Real browser sends 2020 | raw WS trace | PROVEN | determine exact required response |
| E007 | Real browser sends 2004 server_id=1 | raw WS bytes | PROVEN | capture exact response and close reason |
| E008 | Browser accepts current 2004 response | not observed | UNKNOWN | capture response + browser behavior |
| E009 | Real browser reaches 3001 | not observed | UNKNOWN | capture RX/TX |
| E010 | 30004 exact live semantics | only config/captured fixture | UNKNOWN | observe actual request |
| E011 | nginx changes are allowed | user explicitly prohibited | REJECTED | do not modify nginx |

## RULE

When new evidence contradicts an older claim, mark the old claim REJECTED and add the new claim. Do not silently erase the history.

| E012 | Local 2005 handler returns schema-valid empty notice_list | code + packetcfg schema | IMPLEMENTED / NOT PRODUCTION-PROVEN | capture real 2005 response payload and client effect |
| E013 | Local 2020 handler returns schema-valid empty config_list | code + packetcfg schema | IMPLEMENTED / NOT PRODUCTION-PROVEN | capture real 2020 response payload and client effect |
| E014 | Synthetic boot test now covers 2005 and 2020 | test code | IMPLEMENTED / NOT RUNTIME-VALIDATED | install dependencies and run test |
| E015 | 2004 route test no longer hard-codes ryure:30001 | test code | IMPLEMENTED / NOT RUNTIME-VALIDATED | run route test against active server |
| E016 | No nginx files changed during current fix pass | filesystem diff | PROVEN | keep nginx protected |
| E017 | Existing protocol test suite passes after current edits | `npm test` output | PROVEN | run TypeScript/live-server tests once tsx/tsc are available |
| E018 | TypeScript/live WebSocket runtime remains unvalidated | missing `tsx`/`tsc` | PROVEN | complete dependency installation or use a known-good node_modules tree |

| E019 | 2024 target client platform is 330 | captured current CDN `index.html`: `window.platform=330`, `sdkName=Maiji_330_H5_A` | PROVEN | observe whether 2004 response must carry 330 for client to proceed |
| E020 | Local 2004 default should align to platform 330 | E019 + old 308 identified as historical-client evidence | STRONGLY SUPPORTED | run real browser and observe 2004 acceptance / 3001 |
| E021 | 2004 route test validates platform ID | test code + config | IMPLEMENTED / NOT RUNTIME-VALIDATED | run route test with dependencies |


## E022-E024: 2026-09-14 live local validation

### E022
- Status: PROVEN
- Claim: `h5sdk/server.mjs` accepts the H5SDK login request when `ct` and `ac` are supplied in the POST form body.
- Evidence: local process on port 8081; `application/x-www-form-urlencoded` request returned `state:1` with the local guest session payload.
- Important correction: the previous handler read `ct`/`ac` only from the URL query, which caused the same request to return `fail#1`.

### E023
- Status: PROVEN
- Claim: the local H5SDK gate route returns a local CDN game URL for the captured game parameters.
- Evidence: GET `/?ct=gate&g=10336&p=smileonexjlbt_android_ios&dd=0000000000000&options=null` returned `state:1` and a `127.0.0.1:8090/index.html?...` target.

### E024
- Status: PROVEN
- Claim: protocol regression tests still pass after the current source changes.
- Evidence: `node --test tests/protocol.test.mjs` passed all 5 tests.
- Limitation: TypeScript build/runtime remains NOT RUNTIME-PROVEN because the extracted `node_modules` is incomplete (`@types/node` and `@types/ws` are missing) and `npm ci` timed out.

| E025 | Empty local 2001 server catalog is consistent with the browser's visible `undefined` server rows | screenshot + client source + schema | STRONGLY SUPPORTED | return one schema-valid local server and verify browser |
| E026 | Local 2001 now returns `Local Server` and 2002 returns the same server | code change | IMPLEMENTED / NOT BROWSER-PROVEN | launch browser and click Local Server |
