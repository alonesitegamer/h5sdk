# Pokémon Burst local replacement server v2.13-integrated

Clean v2.13 base plus the proven local runtime pieces from the live rebuild.

## Ports

- 8080: recovered game client/container HTTP server
- 8090: nginx local resource CDN
- 30001: replacement game WebSocket server
- 30098: stateMark telemetry
- 30099: error telemetry

## Included

- v2.13 protocol registry/codecs/session/handlers/tests
- real-browser raw WS logging
- 2001 account ID capture
- configurable 2004 local game endpoint, default `127.0.0.1:30001`
- v2.13 3001 -> 3003 -> 3004 -> 3011 -> 3017 startup path
- CORS-safe 30098/30099 HTTP telemetry
- nginx public CRC filename to local `__v_20241024736` mapping
- systemd auto-start and auto-restart for 30001 and 30098/30099
- local H5 parent bridge snippet
- v2.13 resource/protocol tools

## Install

The target directory is:

`/home/ryure/PokemonBurst-local-server-v2.13-integrated`

After copying this directory there:

```bash
cd /home/ryure/PokemonBurst-local-server-v2.13-integrated
./install-local-stack.sh
```

The installer expects nginx and the resource mirror at:

`/home/ryure/pokemonburst-versionmanager-mirror`

The 8080 client server is intentionally left separate because its final client-tree path is installation-specific.

## Service checks

```bash
sudo systemctl status pokemonburst-server --no-pager
sudo systemctl status pokemonburst-telemetry --no-pager
sudo systemctl status nginx --no-pager
ss -ltnp | grep -E ':8090|:30001|:30098|:30099'
```

Live logs:

```bash
journalctl -u pokemonburst-server -f
journalctl -u pokemonburst-telemetry -f
```
