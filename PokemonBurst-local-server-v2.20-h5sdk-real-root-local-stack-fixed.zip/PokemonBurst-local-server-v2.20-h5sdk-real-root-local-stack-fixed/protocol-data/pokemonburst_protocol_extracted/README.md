# PacketCfg Extraction — Pass 2

Source: `cq_0_e7cdc0f1(1).json`
SHA-256: `967ada177aae3defa8950041adb97961e9cf8fe203ca4c647367304af5658619`

## Results

- Total PacketCfg entries: **2035**
- Numeric opcode definitions: **1385**
- Named/nested type definitions: **650**
- Opcodes with `c`: **1353**
- Opcodes with `s`: **1382**
- Opcodes with both: **1350**
- Empty `c`: **431**
- Empty `s`: **3**
- Opcodes without `m`: **5**
- Distinct referenced type names: **480**
- Unresolved references: **0**

## Generated

- `packetcfg.json` — complete source registry
- `opcodes.json` — numeric opcode entries
- `types.json` — named/nested entries
- `schemas/*.json` — one file per numeric opcode
- `protocol_report.json` — structural/reference analysis
- `extract_packetcfg.py` — reproducible extractor

## Important correction

The supplied `cq_0` file directly contains `PacketCfg_json`. This makes extraction a mechanical data-processing step rather than a further reverse-engineering guess.

The protocol report's old statement that the actual PacketCfg data had not been pulled is therefore superseded by this extraction pass.

## Next engineering step

Use `opcodes.json` + `types.json` as the server's authoritative schema registry and validate recursive references before wiring handlers.
