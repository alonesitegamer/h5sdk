#!/usr/bin/env python3
import json, sys
from pathlib import Path

src = Path(sys.argv[1])
dest = Path(sys.argv[2])
data = json.loads(src.read_text(encoding="utf-8"))
cfg = data["PacketCfg_json"]

opcodes = {k:v for k,v in cfg.items() if str(k).isdigit()}
types = {k:v for k,v in cfg.items() if not str(k).isdigit()}

(dest / "schemas").mkdir(parents=True, exist_ok=True)
(dest / "packetcfg.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
(dest / "opcodes.json").write_text(json.dumps(opcodes, ensure_ascii=False, indent=2), encoding="utf-8")
(dest / "types.json").write_text(json.dumps(types, ensure_ascii=False, indent=2), encoding="utf-8")

for k,v in sorted(opcodes.items(), key=lambda kv:int(kv[0])):
    (dest / "schemas" / f"{k}.json").write_text(
        json.dumps(v, ensure_ascii=False, indent=2), encoding="utf-8"
    )

print(f"PacketCfg entries: {len(cfg)}")
print(f"Opcodes: {len(opcodes)}")
print(f"Named types: {len(types)}")
