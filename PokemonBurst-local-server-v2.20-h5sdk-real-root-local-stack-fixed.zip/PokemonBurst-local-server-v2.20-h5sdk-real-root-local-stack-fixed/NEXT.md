# v2.13 → v2.14

1. Run the v2.13 dry-run.
2. Confirm `resolved` is high and the two required targets are FOUND.
3. Run the real reconstruction.
4. Reload the local client.
5. Verify whether `viAgeIcon_45bd60dd.png` and `explore_bg_2ddff2dd.jpg` 404s disappear.
6. If they do, return to the real WebSocket/2001 test.
