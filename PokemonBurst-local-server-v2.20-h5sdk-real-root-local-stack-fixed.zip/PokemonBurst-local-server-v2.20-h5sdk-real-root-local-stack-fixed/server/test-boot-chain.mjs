import WebSocket from "ws";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve("..", "protocol-data", "pokemonburst_protocol_extracted");
const opcodes = JSON.parse(fs.readFileSync(path.join(root, "opcodes.json"), "utf8"));

function assert(cond,msg){if(!cond)throw new Error(msg);}
function primitivePayload(fields,values){
  const chunks=[];
  const u16=v=>{const b=Buffer.alloc(2);b.writeUInt16BE(v>>>0,0);chunks.push(b)};
  const i8=v=>{const b=Buffer.alloc(1);b.writeInt8(v,0);chunks.push(b)};
  const u16f=u16;
  const i32=v=>{const b=Buffer.alloc(4);b.writeInt32BE(v|0,0);chunks.push(b)};
  const i64=v=>{const b=Buffer.alloc(8);b.writeBigInt64BE(BigInt(v),0);chunks.push(b)};
  const str=v=>{const b=Buffer.from(String(v),"utf8");u16(b.length);chunks.push(b)};
  for(const [name,type] of fields??[]){
    const v=values[name];
    if(type==="int8")i8(v);
    else if(type==="uint16")u16f(v);
    else if(type==="int32")i32(v);
    else if(type==="int64")i64(v);
    else if(type==="string")str(v);
    else throw new Error(`unsupported request field ${name}:${type}`);
  }
  return Buffer.concat(chunks);
}
function packet(opcode,payload=Buffer.alloc(0),stamp=0){
  const b=Buffer.alloc(7+payload.length);b.writeUInt32BE(b.length,0);b.writeUInt16BE(opcode,4);b.writeUInt8(stamp&127,6);payload.copy(b,7);return b;
}
function parse(b){const x=Buffer.from(b);assert(x.length>=7,"short frame");assert(x.readUInt32BE(0)===x.length,"length mismatch");return {opcode:x.readUInt16BE(4),stamp:x.readUInt8(6),body:x.subarray(7)}}

const ws=new WebSocket(process.env.URL??"ws://127.0.0.1:9000");
let stamp=0;
const waiters=new Map();
const queued=new Map();

function deliver(p){
  const waiter=waiters.get(p.opcode);
  if(waiter){
    clearTimeout(waiter.timer);
    waiters.delete(p.opcode);
    waiter.resolve(p);
    return;
  }
  const q=queued.get(p.opcode)??[];
  q.push(p);
  queued.set(p.opcode,q);
}
function next(opcode,timeout=5000){
  const q=queued.get(opcode);
  if(q?.length){
    const p=q.shift();
    if(q.length===0) queued.delete(opcode);
    return Promise.resolve(p);
  }
  if(waiters.has(opcode)) throw new Error(`already waiting for opcode ${opcode}`);
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>{
      waiters.delete(opcode);
      reject(new Error(`timeout waiting for opcode ${opcode}`));
    },timeout);
    waiters.set(opcode,{resolve,reject,timer});
  });
}
function sendReq(opcode,values){
  const cfg=opcodes[String(opcode)];
  assert(cfg?.c,"missing c schema "+opcode);
  const body=primitivePayload(cfg.c,values);
  console.log(`[BOOT] TX ${opcode} ${cfg.m??""} bytes=${body.length}`);
  ws.send(packet(opcode,body,stamp++));
}

ws.on("open",async()=>{
  try{
    console.log("[BOOT] connected");

    sendReq(2001,{plat_id:308,game_channel_id:"local",acc_id:"test-account",verify_time:Math.floor(Date.now()/1000),sign:"local-test-sign",channel:"local"});
    let p=await next(2001); console.log(`[BOOT] RX 2001 bytes=${p.body.length}`);

    sendReq(2002,{large_server_id:1n}); p=await next(2002); console.log(`[BOOT] RX 2002 bytes=${p.body.length}`);

    sendReq(2005,{}); p=await next(2005); assert(p.body.length===2,"2005 empty notice_list response"); console.log(`[BOOT] RX 2005 login_notice_list bytes=${p.body.length}`);

    sendReq(2020,{}); p=await next(2020); assert(p.body.length===2,"2020 empty config_list response"); console.log(`[BOOT] RX 2020 acc_config_list bytes=${p.body.length}`);

    sendReq(2004,{server_id:1}); p=await next(2004); console.log(`[BOOT] RX 2004 bytes=${p.body.length}`);

    sendReq(3001,{plat_id:308,server_id:1,game_channel_id:"local",acc_id:"test-account",md5:"local",os:1,relogin:0,version:2022111701n});
    p=await next(3001); assert(p.body.length===2,"3001 result body"); assert(p.body.readInt16BE(0)===0,"3001 result");
    console.log("[BOOT] RX 3001 result=0");

    // 3003 is a server push after 3001.
    p=await next(3003); console.log("[BOOT] PUSH 3003 server_load_success");

    // Client sends 3004 after it has completed its local resource load.
    sendReq(3004,{}); p=await next(3004); console.log(`[BOOT] RX 3004 simple_role bytes=${p.body.length}`);

    // 3011 is another server push, not a client request.
    p=await next(3011); console.log("[BOOT] PUSH 3011 server_push_finish");

    sendReq(3017,{lang:"en"}); p=await next(3017); console.log(`[BOOT] RX 3017 bytes=${p.body.length}`);

    console.log("[BOOT] PASS: ordered local boot-chain through 3017");
    ws.close();
  }catch(e){
    console.error("[BOOT] FAIL:",e.message);process.exitCode=1;ws.close();
  }
});

ws.on("message",raw=>{ try { deliver(parse(raw)); } catch (e) { console.error("[BOOT] invalid frame:",e.message); process.exitCode=1; } });
ws.on("error",e=>{console.error("[BOOT] websocket error:",e.message);process.exitCode=1});
ws.on("close",c=>console.log(`[BOOT] closed code=${c}`));
