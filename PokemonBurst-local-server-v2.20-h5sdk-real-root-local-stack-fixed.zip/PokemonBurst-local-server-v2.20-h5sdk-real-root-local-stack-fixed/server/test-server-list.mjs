import WebSocket from "ws";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve("..", "protocol-data", "pokemonburst_protocol_extracted");
const opcodes = JSON.parse(fs.readFileSync(path.join(root, "opcodes.json"), "utf8"));

const cfg = opcodes["2002"];
if (!cfg?.c || !cfg?.s) throw new Error("2002 schema missing");

const chunks = [];
function u8(v){const b=Buffer.alloc(1);b.writeUInt8(v&255,0);chunks.push(b)}
function i8(v){const b=Buffer.alloc(1);b.writeInt8(v,0);chunks.push(b)}
function u16(v){const b=Buffer.alloc(2);b.writeUInt16BE(v>>>0,0);chunks.push(b)}
function i16(v){const b=Buffer.alloc(2);b.writeInt16BE(v,0);chunks.push(b)}
function u32(v){const b=Buffer.alloc(4);b.writeUInt32BE(v>>>0,0);chunks.push(b)}
function i32(v){const b=Buffer.alloc(4);b.writeInt32BE(v|0,0);chunks.push(b)}
function i64(v){const b=Buffer.alloc(8);b.writeBigInt64BE(BigInt(v),0);chunks.push(b)}
function u64(v){const b=Buffer.alloc(8);b.writeBigUInt64BE(BigInt(v),0);chunks.push(b)}
function f64(v){const b=Buffer.alloc(8);b.writeDoubleBE(Number(v),0);chunks.push(b)}
function str(v){const b=Buffer.from(v,"utf8");u16(b.length);chunks.push(b)}

for (const [name,type] of cfg.c) {
  // 2002 is expected to be a simple scalar request.
  if (type==="int8") i8(1);
  else if(type==="uint8") u8(1);
  else if(type==="int16") i16(1);
  else if(type==="uint16") u16(1);
  else if(type==="int32") i32(1);
  else if(type==="uint32") u32(1);
  else if(type==="int64") i64(1);
  else if(type==="uint64") u64(1);
  else if(type==="number") f64(1);
  else if(type==="string") str("local");
  else throw new Error(`Unsupported 2002 test type ${type}`);
}
const payload=Buffer.concat(chunks);
const packet=Buffer.alloc(7+payload.length);
packet.writeUInt32BE(packet.length,0);
packet.writeUInt16BE(2002,4);
packet.writeUInt8(0,6);
payload.copy(packet,7);

const ws=new WebSocket(process.env.URL??"ws://127.0.0.1:9000");
ws.on("open",()=>{console.log("[TEST] connected");console.log(`[TEST] sending 2002 SERVER_LIST payload=${payload.length} bytes`);ws.send(packet)});
ws.on("message",raw=>{
  const b=Buffer.from(raw), length=b.readUInt32BE(0), opcode=b.readUInt16BE(4), stamp=b.readUInt8(6);
  console.log(`[TEST] received length=${length} opcode=${opcode} stamp=${stamp} bytes=${b.length}`);
  if(opcode!==2002||length!==b.length){console.error("[TEST] FAIL: invalid 2002 response");process.exitCode=1}
  else {console.log(`[TEST] 2002 response schema fields: ${cfg.s.length}`);console.log("[TEST] PASS: 2002 structured round-trip")}
  ws.close();
});
ws.on("error",e=>{console.error("[TEST] error",e.message);process.exitCode=1});
