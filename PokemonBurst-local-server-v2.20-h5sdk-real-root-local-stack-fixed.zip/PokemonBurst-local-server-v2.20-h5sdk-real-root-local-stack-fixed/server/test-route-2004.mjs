import WebSocket from "ws";

const packet = Buffer.alloc(11);
packet.writeUInt32BE(packet.length, 0);
packet.writeUInt16BE(2004, 4);
packet.writeUInt8(0, 6);
packet.writeInt32BE(1, 7);

const ws = new WebSocket(process.env.URL ?? "ws://127.0.0.1:30001");

ws.on("open", () => {
  console.log("[ROUTE-TEST] connected");
  ws.send(packet);
});

ws.on("message", raw => {
  const b = Buffer.from(raw);
  const opcode = b.readUInt16BE(4);
  if (opcode !== 2004) {
    console.error(`[ROUTE-TEST] FAIL: opcode=${opcode}`);
    process.exitCode = 1;
    ws.close();
    return;
  }

  let o = 7;
  const result = b.readInt16BE(o); o += 2;

  const readString = () => {
    const n = b.readUInt16BE(o); o += 2;
    const s = b.subarray(o, o + n).toString("utf8");
    o += n;
    return s;
  };

  const accId = readString();
  const md5 = readString();
  const ip = readString();
  const port = b.readInt32BE(o); o += 4;
  const platId = b.readInt32BE(o); o += 4;

  console.log(`[ROUTE-TEST] result=${result} ip=${ip} port=${port} plat_id=${platId}`);

  const expectedHost = process.env.ADVERTISE_HOST ?? "127.0.0.1";
  const expectedPort = Number(process.env.ADVERTISE_PORT ?? 30001);
  const expectedPlatId = Number(process.env.PLAT_ID ?? 330);
  if (result === 0 && ip === expectedHost && port === expectedPort && platId === expectedPlatId) {
    console.log(`[ROUTE-TEST] PASS: 2004 routes client to ${expectedHost}:${expectedPort} with plat_id=${expectedPlatId}`);
  } else {
    console.error("[ROUTE-TEST] FAIL: unexpected route response");
    process.exitCode = 1;
  }
  ws.close();
});

ws.on("error", e => {
  console.error("[ROUTE-TEST] error:", e.message);
  process.exitCode = 1;
});
