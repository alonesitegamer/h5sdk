import WebSocket from "ws";
const url=process.env.URL??"ws://ryure:30001";

function connect(label){
  return new Promise((resolve,reject)=>{
    const ws=new WebSocket(url);
    const timer=setTimeout(()=>{ws.terminate();reject(new Error(`${label}: timeout`))},3000);
    ws.once("open",()=>{
      clearTimeout(timer);
      console.log(`[TWO-TEST] ${label} OPEN ${url}`);
      ws.close(1000,"test");
    });
    ws.once("close",()=>resolve());
    ws.once("error",e=>{
      clearTimeout(timer);
      reject(new Error(`${label}: ${e.message}`));
    });
  });
}

try{
  await connect("connection-1");
  await connect("connection-2");
  console.log("[TWO-TEST] PASS: two sequential WebSocket connections to ryure:30001");
}catch(e){
  console.error("[TWO-TEST] FAIL:",e.message);
  process.exitCode=1;
}
