import WebSocket from "ws";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve("..", "protocol-data", "pokemonburst_protocol_extracted");
const opcodes = JSON.parse(fs.readFileSync(path.join(root, "opcodes.json"), "utf8"));
const cfg = opcodes["3001"];
if (!cfg?.c || !cfg?.s) throw new Error("3001 schema missing");

const values = {
  plat_id: 308,
  server_id: 1,
  game_channel_id: "local",
  acc_id: "test-account",
  md5: "local",
  os: 1,
  relogin: 0,
  version: 2022111701n
};

const chunks=[];
function i8(v){const b=Buffer.alloc(1);b.writeInt8(v,0);chunks.push(b)}
function u16(v){const b=Buffer.alloc(2);b.writeUInt16BE(v>>>0,0);chunks.push(b)}
function i32(v){const b=Buffer.alloc(4);b.writeInt32BE(v|0,0);chunks.push(b)}
function i64(v){const b=Buffer.alloc(8);b.writeBigInt64BE(BigInt(v),0);chunks.push(b)}
function str(v){const b=Buffer.from(v,"utf8");u16(b.length);chunks.push(b)}

for(const [name,type] of cfg.c){
  const v=values[name];
  if(type==="int8") i8(v);
  else if(type==="uint16") u16(v);
  else if(type==="int32") i32(v);
  else if(type==="int64") i64(v);
  else if(type==="string") str(v);
  else throw new Error(`unsupported 3001 test field ${name}:${type}`);
}

const payload=Buffer.concat(chunks);
const packet=Buffer.alloc(7+payload.length);
packet.writeUInt32BE(packet.length,0);
packet.writeUInt16BE(3001,4);
packet.writeUInt8(0,6);
payload.copy(packet,7);

const ws=new WebSocket(process.env.URL??"ws://127.0.0.1:9000");
ws.on("open",()=>{
  console.log("[TEST] connected");
  console.log(`[TEST] sending 3001 GAME_LOGIN payload=${payload.length} bytes`);
  ws.send(packet);
});
ws.on("message",raw=>{
  const b=Buffer.from(raw);
  const length=b.readUInt32BE(0), opcode=b.readUInt16BE(4), stamp=b.readUInt8(6);
  console.log(`[TEST] received length=${length} opcode=${opcode} stamp=${stamp} bytes=${b.length}`);
  if(opcode!==3001||length!==b.length){
    console.error("[TEST] FAIL: invalid 3001 response header");
    process.exitCode=1; ws.close(); return;
  }
  if(b.length!==9){
    console.error(`[TEST] FAIL: expected 9-byte response, got ${b.length}`);
    process.exitCode=1; ws.close(); return;
  }
  const result=b.readInt16BE(7);
  console.log(`[TEST] result=${result}`);
  if(result!==0){
    console.error("[TEST] FAIL: result is not zero");
    process.exitCode=1;
  } else {
    console.log("[TEST] PASS: 3001 GAME_LOGIN structured round-trip");
  }
  ws.close();
});
ws.on("error",e=>{console.error("[TEST] error",e.message);process.exitCode=1});
ws.on("close",c=>console.log(`[TEST] closed code=${c}`));
