import WebSocket from "ws";

const url = process.env.URL ?? "ws://127.0.0.1:9000";
const ws = new WebSocket(url);

function encodeHeartbeat(stamp = 0) {
  // Recovered packet:
  // uint32 BE total length (7 bytes)
  // uint16 BE opcode 3999
  // uint8 stamp
  const b = Buffer.alloc(7);
  b.writeUInt32BE(7, 0);
  b.writeUInt16BE(3999, 4);
  b.writeUInt8(stamp, 6);
  return b;
}

ws.on("open", () => {
  console.log(`[TEST] connected to ${url}`);
  const packet = encodeHeartbeat(0);
  console.log(`[TEST] sending 3999 heartbeat: ${packet.toString("hex")}`);
  ws.send(packet);
});

ws.on("message", (data) => {
  const b = Buffer.from(data);
  console.log(`[TEST] received ${b.length} bytes: ${b.toString("hex")}`);

  if (b.length < 11) {
    console.error("[TEST] FAIL: heartbeat response is shorter than 11 bytes");
    process.exitCode = 1;
    ws.close();
    return;
  }

  const length = b.readUInt32BE(0);
  const opcode = b.readUInt16BE(4);
  const stamp = b.readUInt8(6);
  const unixTime = b.readUInt32BE(7);

  console.log(`[TEST] response length=${length} opcode=${opcode} stamp=${stamp} unix_time=${unixTime}`);

  if (length !== b.length || opcode !== 3999 || unixTime <= 0) {
    console.error("[TEST] FAIL: invalid heartbeat response");
    process.exitCode = 1;
  } else {
    console.log("[TEST] PASS: 3999 heartbeat round-trip");
  }
  ws.close();
});

ws.on("close", (code, reason) => {
  console.log(`[TEST] closed code=${code} reason=${reason.toString()}`);
});

ws.on("error", (err) => {
  console.error("[TEST] websocket error:", err.message);
  process.exitCode = 1;
});
