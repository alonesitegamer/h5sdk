import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

test("PacketCfg extraction is present and internally populated", () => {
  const root = resolve("..", "protocol-data", "pokemonburst_protocol_extracted");
  const opcodes = JSON.parse(readFileSync(resolve(root, "opcodes.json"), "utf8"));
  const types = JSON.parse(readFileSync(resolve(root, "types.json"), "utf8"));
  assert.equal(Object.keys(opcodes).length, 1385);
  assert.equal(Object.keys(types).length, 650);
  assert.ok(opcodes["3999"]);
  assert.ok(opcodes["3004"]);
});

test("packet framing constants are the recovered 7-byte format", () => {
  assert.equal(4 + 2 + 1, 7);
});

test("heartbeat 3999 request is exactly a 7-byte empty payload packet", () => {
  const b = Buffer.alloc(7);
  b.writeUInt32BE(7, 0);
  b.writeUInt16BE(3999, 4);
  b.writeUInt8(0, 6);
  assert.equal(b.toString("hex"), "000000070f9f00");
});

test("heartbeat 3999 response contains uint32 unix_time after the 7-byte header", () => {
  const unixTime = 1776739200;
  const b = Buffer.alloc(11);
  b.writeUInt32BE(11, 0);
  b.writeUInt16BE(3999, 4);
  b.writeUInt8(0, 6);
  b.writeUInt32BE(unixTime >>> 0, 7);
  assert.equal(b.readUInt32BE(0), 11);
  assert.equal(b.readUInt16BE(4), 3999);
  assert.equal(b.readUInt32BE(7), unixTime);
});

test("boot opcode inventory exists", () => {
  const root = resolve("..", "protocol-data", "pokemonburst_protocol_extracted");
  const opcodes = JSON.parse(readFileSync(resolve(root, "opcodes.json"), "utf8"));
  for (const op of [2001,2002,2004,3001,3003,3004,3005,3011,3017,3999]) {
    assert.ok(opcodes[String(op)], `missing opcode ${op}`);
  }
});
