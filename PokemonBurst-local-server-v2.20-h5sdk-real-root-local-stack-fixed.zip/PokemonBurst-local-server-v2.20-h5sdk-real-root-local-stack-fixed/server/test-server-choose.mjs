import WebSocket from "ws";

const packet = Buffer.alloc(11);
// 7-byte header + int32 server_id
packet.writeUInt32BE(11, 0);
packet.writeUInt16BE(2004, 4);
packet.writeUInt8(0, 6);
packet.writeInt32BE(1, 7);

const ws = new WebSocket(process.env.URL ?? "ws://127.0.0.1:9000");

ws.on("open", () => {
  console.log("[TEST] connected");
  console.log("[TEST] sending 2004 SERVER_CHOOSE server_id=1");
  ws.send(packet);
});

ws.on("message", raw => {
  const b = Buffer.from(raw);
  if (b.length < 7) {
    console.error("[TEST] FAIL: response shorter than packet header");
    process.exitCode = 1;
    ws.close();
    return;
  }

  const length = b.readUInt32BE(0);
  const opcode = b.readUInt16BE(4);
  const stamp = b.readUInt8(6);
  console.log(`[TEST] received length=${length} opcode=${opcode} stamp=${stamp} bytes=${b.length}`);

  if (opcode !== 2004 || length !== b.length) {
    console.error("[TEST] FAIL: invalid 2004 response header");
    process.exitCode = 1;
    ws.close();
    return;
  }

  // Validate the exact response primitive layout from PacketCfg[2004].s:
  // int16 result, string acc_id, string md5, string ip, int32 port, int32 plat_id
  let o = 7;
  const result = b.readInt16BE(o); o += 2;

  const readString = () => {
    const n = b.readUInt16BE(o); o += 2;
    const s = b.subarray(o, o + n).toString("utf8");
    o += n;
    return s;
  };

  const accId = readString();
  const md5 = readString();
  const ip = readString();
  const port = b.readInt32BE(o); o += 4;
  const platId = b.readInt32BE(o); o += 4;

  console.log(`[TEST] result=${result} acc_id=${accId} md5=${md5} ip=${ip} port=${port} plat_id=${platId}`);

  if (o !== b.length) {
    console.error(`[TEST] FAIL: ${b.length - o} trailing bytes`);
    process.exitCode = 1;
  } else if (result !== 0) {
    console.error("[TEST] FAIL: result is not zero");
    process.exitCode = 1;
  } else {
    console.log("[TEST] PASS: 2004 structured round-trip");
  }

  ws.close();
});

ws.on("error", err => {
  console.error("[TEST] error", err.message);
  process.exitCode = 1;
});

ws.on("close", code => console.log(`[TEST] closed code=${code}`));
