import type {WebSocket} from "ws";
import {encodeFields,decodeFields,loadRegistry} from "../protocol/codec.js";
import {encodePacket,Packet} from "../protocol/packet.js";
import {Session} from "../session/session.js";
import {buildDefaultObject} from "../protocol/defaults.js";

const {opcodes,types}=loadRegistry();

export function dispatch(ws:WebSocket,session:Session,p:Packet){
  const cfg=opcodes[String(p.opcode)];
  const name=cfg?.m??"UNKNOWN";
  console.log(`[RX] opcode=${p.opcode} ${name} stamp=${p.stamp} bytes=${p.payload.length}`);

  if(!cfg){console.warn(`[SKIP] unknown opcode ${p.opcode}`);return}

  let req:any={};
  if(cfg.c?.length) req=decodeFields(cfg.c,p.payload,types);

  switch(p.opcode){
    case 3999:
      return send(ws,session,3999,{unix_time:Math.floor(Date.now()/1000)});

    case 2001:
      session.state="ACCOUNT_LOGIN";
      session.accountId=String(req.acc_id ?? session.accountId);
      return send(ws,session,2001,{
        result:0,
        // The real client immediately opens its EntrancePanel from the 2001
        // response. An empty new_server/login_history leaves its server rows
        // without data and renders "undefined" in the UI. A single valid
        // new-server entry is the smallest schema-valid local server catalog.
        new_server:[{server_id:1,name:"Local Server",status:1}],
        login_history:[],
        large_server_list:[],
        game_channel_id:req.game_channel_id??""
      });

    case 2002:
      return send(ws,session,2002,{
        large_server_id:req.large_server_id??1n,
        server_list:[{server_id:1,name:"Local Server",status:1}]
      });

    case 2005:
      // Real browser traffic proves this request occurs before SERVER_CHOOSE.
      // The response shape is schema-verified, but its production contents are
      // not yet recovered, so keep the local response to a valid empty list.
      return send(ws,session,2005,{notice_list:[]});

    case 2020:
      // Same evidence boundary as 2005: request order is runtime-proven,
      // response contents are not. An empty schema-valid list is the smallest
      // reversible local implementation until browser response evidence exists.
      return send(ws,session,2020,{config_list:[]});

    case 2004:
      session.serverId=Number(req.server_id??1);
      const advertiseHost=process.env.ADVERTISE_HOST ?? "127.0.0.1";
      const advertisePort=Number(process.env.ADVERTISE_PORT ?? 30001);
      console.log(`[ROUTE] 2004 -> client game endpoint ${advertiseHost}:${advertisePort}`);
      session.state="SERVER_SELECTED";
      return send(ws,session,2004,{
        result:0,
        acc_id:session.accountId,
        md5:"local",
        ip:advertiseHost,
        port:advertisePort,
        plat_id:Number(process.env.PLAT_ID ?? 330)
      });

    case 3001:
      session.state="GAME_LOGIN";
      console.log(`[ROUTE] 3001 GAME_LOGIN reached game-server stage`);
      // 3001 is a client request with a normal response.
      send(ws,session,3001,{result:0});

      // 3003 is schema-defined as server -> client only (empty c/s), so
      // deliver it as an unsolicited server push after successful game login.
      send(ws,session,3003,{});
      return;

    case 3004: {
      // Client -> server has an empty c schema. The response carries simple_role.
      session.state="LOADED";
      const role=buildDefaultObject("simple_role",types);
      role.role_id=BigInt(session.playerId);
      role.name="Local Trainer";
      role.srv_id=session.serverId;
      role.srv_name="Local Server";
      role.lev=1;
      role.power=0n;
      role.vip_lev=0;
      role.guild_name="";
      role.team_name="";
      role.fashion_use_list=[];
      role.title_list=[];
      role.attr_list=[];
      role.medal_list=[];
      role.token_list=[];
      role.joint_team_dun=[];
      role.role_icon = role.role_icon ?? {};
      send(ws,session,3004,{role});
      // Minimal local startup gate: server declares initial push phase complete.
      send(ws,session,3011,{});
      return;
    }

    case 3017:
      return send(ws,session,3017,{result:0,lang:String(req.lang??"en")});

    default:
      // Server-push-only packets such as 3003/3011/3005 cannot arrive as
      // requests through the real client because their c schemas are empty.
      console.log(`[UNHANDLED] ${p.opcode} ${name}`);
  }
}

export function serverPush(ws:WebSocket,session:Session,opcode:number,obj:any={}){
  return send(ws,session,opcode,obj);
}

function send(ws:WebSocket,s:Session,opcode:number,obj:any){
  const cfg=opcodes[String(opcode)];
  if(!cfg?.s) return;
  const body=encodeFields(cfg.s,obj,types);
  ws.send(encodePacket(opcode,s.nextStamp(),body));
  console.log(`[TX] opcode=${opcode} ${cfg.m??""} bytes=${body.length}`);
}
