import type {Field} from "./codec.js";

export type SchemaDefaults = Record<string, any>;

const primitiveDefaults: Record<string, any> = {
  int8: 0, uint8: 0, int16: 0, uint16: 0,
  int32: 0, uint32: 0,
  int64: 0n, uint64: 0n,
  number: 0, float64: 0, double: 0,
  string: ""
};

export function buildDefaultObject(type: string, types: Record<string, Field[]>, stack: string[] = []): any {
  if (Object.prototype.hasOwnProperty.call(primitiveDefaults, type)) {
    return primitiveDefaults[type];
  }

  if (type === "array") return [];

  const fields = types[type];
  if (!fields) throw new Error(`No schema for default type ${type}`);

  if (stack.includes(type)) {
    throw new Error(`Recursive schema cycle while building ${type}: ${[...stack, type].join(" -> ")}`);
  }

  const out: SchemaDefaults = {};
  for (const [name, fieldType, ...extra] of fields) {
    if (fieldType === "array") {
      out[name] = [];
    } else {
      out[name] = buildDefaultObject(fieldType, types, [...stack, type]);
    }
  }
  return out;
}

export function patchObject(target: any, patch: Record<string, any>): any {
  if (!target || typeof target !== "object" || Array.isArray(target)) return patch;
  return Object.assign(target, patch);
}
