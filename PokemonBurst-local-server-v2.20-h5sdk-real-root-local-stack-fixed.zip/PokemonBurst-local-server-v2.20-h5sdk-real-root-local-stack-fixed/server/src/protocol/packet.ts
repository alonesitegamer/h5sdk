import {Reader,Writer} from "./codec.js";
export const HEADER=7;
export interface Packet{length:number;opcode:number;stamp:number;payload:Buffer}
export function encodePacket(opcode:number,stamp:number,payload:Buffer){
  const w=new Writer();w.u32(HEADER+payload.length);w.u16(opcode);w.u8(stamp);w.raw(payload);return w.out();
}
export function decodePacket(b:Buffer):Packet{
  if(b.length<HEADER)throw Error("packet shorter than header");
  const r=new Reader(b),length=r.u32(),opcode=r.u16(),stamp=r.u8();
  if(length!==b.length)throw Error(`declared length ${length} != actual ${b.length}`);
  return {length,opcode,stamp,payload:b.subarray(HEADER)};
}
export class Reassembler{
  private b=Buffer.alloc(0);
  push(chunk:Buffer){this.b=Buffer.concat([this.b,chunk]);const out:Packet[]=[];
    while(this.b.length>=4){const n=this.b.readUInt32BE(0);if(n<HEADER)throw Error(`invalid packet length ${n}`);if(this.b.length<n)break;
      out.push(decodePacket(this.b.subarray(0,n)));this.b=this.b.subarray(n)}
    return out}
}
