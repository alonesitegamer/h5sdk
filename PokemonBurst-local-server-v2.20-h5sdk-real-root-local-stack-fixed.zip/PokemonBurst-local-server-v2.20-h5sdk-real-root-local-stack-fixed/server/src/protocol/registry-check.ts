import { loadRegistry } from "./codec.js";

const { opcodes, types } = loadRegistry();
console.log(`PacketCfg OK: ${Object.keys(opcodes).length} opcodes, ${Object.keys(types).length} named types`);
console.log(`Boot opcode 3004: ${opcodes["3004"]?.m ?? "missing"}`);
console.log(`Heartbeat 3999: ${opcodes["3999"]?.m ?? "missing"}`);
