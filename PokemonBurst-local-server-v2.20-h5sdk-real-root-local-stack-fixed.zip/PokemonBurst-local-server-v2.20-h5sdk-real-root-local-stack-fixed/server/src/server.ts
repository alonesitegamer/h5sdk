import {WebSocketServer} from "ws";
import {Reassembler} from "./protocol/packet.js";
import {Session} from "./session/session.js";
import {dispatch} from "./handlers/dispatch.js";
import {logRawFrame} from "./transport/raw-logger.js";

const host=process.env.HOST??"0.0.0.0",port=Number(process.env.PORT??30001);
const wss=new WebSocketServer({host,port});
let connectionSeq=0;

wss.on("connection",(ws,req)=>{
  const connectionId=++connectionSeq;
  const session=new Session(), r=new Reassembler();
  console.log(`[+] connection id=${connectionId} from=${req.socket.remoteAddress} state=${session.state}`);

  ws.on("message",raw=>{
    try{
      const chunk=Buffer.from(raw as Buffer);
      console.log(`[WS RX RAW] connection=${connectionId} binary=${typeof raw !== "string"} bytes=${chunk.length} hex=${chunk.subarray(0,64).toString("hex")}`);
      if(typeof raw === "string") return;
      console.log(`[CHUNK] connection id=${connectionId} bytes=${chunk.length}`);
      logRawFrame(session,chunk);
      for(const p of r.push(chunk)){
        console.log(`[PACKET] connection id=${connectionId} opcode=${p.opcode}`);
        dispatch(ws,session,p);
      }
    }catch(e){
      console.error(`[!] protocol error connection id=${connectionId}`,e);
      ws.close(1002,"protocol error");
    }
  });

  ws.on("close",(code,reason)=>
    console.log(`[-] closed id=${connectionId} code=${code} state=${session.state} reason=${reason.toString()}`)
  );
});

console.log(`Pokémon Burst replacement server v2.20.1: ws://${host}:${port}`);
