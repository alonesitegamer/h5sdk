import type {Session} from "../session/session.js";
export function logRawFrame(session:Session,data:Buffer){
  const max=Math.min(data.length,64);
  console.log(`[RAW] state=${session.state} bytes=${data.length} hex=${data.subarray(0,max).toString("hex")}${data.length>max?"...":""}`);
}
