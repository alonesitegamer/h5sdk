export type ConnState="CONNECTED"|"ACCOUNT_LOGIN"|"SERVER_SELECTED"|"GAME_LOGIN"|"LOADED";
export class Session{
  stamp=0;state:ConnState="CONNECTED";accountId="local-account";serverId=1;playerId=1;
  nextStamp(){const s=this.stamp;this.stamp=this.stamp>=127?0:this.stamp+1;return s}
}
