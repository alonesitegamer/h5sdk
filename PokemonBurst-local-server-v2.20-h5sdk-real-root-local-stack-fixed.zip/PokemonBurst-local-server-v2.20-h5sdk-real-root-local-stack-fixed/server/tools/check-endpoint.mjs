import net from "node:net";
import dns from "node:dns";

const host = process.env.HOSTNAME_TO_CHECK ?? "ryure";
const port = Number(process.env.PORT_TO_CHECK ?? 30001);

console.log(`[ENDPOINT] checking ${host}:${port}`);

try {
  const addresses = await dns.promises.lookup(host, { all: true });
  console.log("[ENDPOINT] DNS:", addresses);
} catch (e) {
  console.error(`[ENDPOINT] DNS lookup failed for ${host}: ${e.message}`);
  process.exitCode = 1;
}

await new Promise((resolve) => {
  const socket = net.createConnection({ host, port });

  socket.setTimeout(2500);

  socket.on("connect", () => {
    console.log(`[ENDPOINT] TCP reachable: ${host}:${port}`);
    socket.destroy();
    resolve();
  });

  socket.on("timeout", () => {
    console.error(`[ENDPOINT] TCP timeout: ${host}:${port}`);
    socket.destroy();
    process.exitCode = 1;
    resolve();
  });

  socket.on("error", (e) => {
    console.error(`[ENDPOINT] TCP failed: ${e.message}`);
    process.exitCode = 1;
    resolve();
  });
});
