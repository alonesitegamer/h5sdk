import WebSocket from "ws";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve("..", "protocol-data", "pokemonburst_protocol_extracted");
const opcodes = JSON.parse(fs.readFileSync(path.join(root, "opcodes.json"), "utf8"));
const loginSchema = opcodes["2001"];

if (!loginSchema?.c || !loginSchema?.s) {
  console.error("[TEST] 2001 schema missing");
  process.exit(1);
}

const values = {
  plat_id: 308,
  game_channel_id: "local",
  acc_id: "test-account",
  verify_time: Math.floor(Date.now()/1000),
  sign: "local-test-sign",
  channel: "local"
};

const chunks = [];
function u16(v){const b=Buffer.alloc(2);b.writeUInt16BE(v,0);chunks.push(b)}
function i32(v){const b=Buffer.alloc(4);b.writeInt32BE(v,0);chunks.push(b)}
function str(v){const b=Buffer.from(v,"utf8");u16(b.length);chunks.push(b)}
for (const [name,type] of loginSchema.c) {
  const v=values[name];
  if(type==="int32") i32(v);
  else if(type==="string") str(v);
  else throw new Error(`unsupported 2001 field type ${type}`);
}
const payload=Buffer.concat(chunks);
const packet=Buffer.alloc(7+payload.length);
packet.writeUInt32BE(packet.length,0);
packet.writeUInt16BE(2001,4);
packet.writeUInt8(0,6);
payload.copy(packet,7);

const ws=new WebSocket(process.env.URL??"ws://127.0.0.1:9000");
ws.on("open",()=>{
  console.log("[TEST] connected");
  console.log(`[TEST] sending 2001 ACCOUNT_LOGIN payload=${payload.length} bytes`);
  ws.send(packet);
});
ws.on("message",(raw)=>{
  const b=Buffer.from(raw);
  const length=b.readUInt32BE(0);
  const opcode=b.readUInt16BE(4);
  const stamp=b.readUInt8(6);
  console.log(`[TEST] received length=${length} opcode=${opcode} stamp=${stamp} bytes=${b.length}`);
  if(opcode!==2001){console.error("[TEST] FAIL: expected opcode 2001");process.exitCode=1;ws.close();return;}
  if(length!==b.length){console.error("[TEST] FAIL: length mismatch");process.exitCode=1;ws.close();return;}
  console.log(`[TEST] 2001 response schema fields: ${loginSchema.s.length}`);
  console.log("[TEST] PASS: 2001 structured round-trip reached server response");
  ws.close();
});
ws.on("error",(e)=>{console.error("[TEST] error",e.message);process.exitCode=1});
ws.on("close",(c)=>console.log(`[TEST] closed code=${c}`));
