# Merge manifest

Base: v2.13 replacement server archive.

Merged from the live local rebuild:

- 30001 default runtime port
- raw browser WS logging
- 2001 account ID capture
- configurable 2004 local endpoint
- 30098 stateMark telemetry and 30099 error endpoint
- CORS for cross-origin browser telemetry
- 8090 nginx resource mapping
- systemd auto-start/auto-restart units
- local H5 `mjlogin` bridge snippet

Deliberately excluded:

- stale v2.13 `node_modules`
- generated `dist`
- production service endpoints
- 8080 daemonization, pending final client-tree path
