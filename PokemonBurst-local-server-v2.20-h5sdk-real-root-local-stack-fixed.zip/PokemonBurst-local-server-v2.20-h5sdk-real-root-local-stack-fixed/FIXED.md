# v0.9 Fix

## What was broken

The server tried to load:

```text
../protocol-data/opcodes.json
```

But the extracted registry is actually located at:

```text
../protocol-data/pokemonburst_protocol_extracted/opcodes.json
```

The test suite passed because it only checked the files directly and did not
start the registry loader.

## What is fixed

The loader now checks the actual extracted registry location and a couple of
safe fallback locations.

## Run

From `server/`:

```bash
npm install
npm test
npm run check:registry
npm run dev
```

Expected registry check:

```text
PacketCfg OK: 1385 opcodes, 650 named types
PacketCfg 3004: CLIENT_LOAD_SUCCESS
Heartbeat 3999: HEARTBEAT
```

Then in another terminal:

```bash
npm run smoke
```
