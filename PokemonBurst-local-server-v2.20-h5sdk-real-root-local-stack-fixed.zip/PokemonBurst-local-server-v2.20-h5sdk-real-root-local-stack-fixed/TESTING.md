# Testing Plan v0.8

## What can be tested right now

### Protocol-level
Immediately after:

```bash
cd server
npm install
npm test
```

This checks that:

- the extracted 2,035-entry registry is present;
- the expected 1,385 opcodes and 650 named types are present;
- key boot opcodes exist;
- the recovered 7-byte packet framing is represented;
- array boundary behavior is represented.

### Transport-level
Start:

```bash
npm run dev
```

Then, in another terminal:

```bash
npm run smoke
```

This confirms a local WebSocket connection can be established.

## What is NOT test-complete yet

A real game-client login test is not yet the same thing as a unit test.

The client still expects the correct startup push/state behavior around:

```text
3004
  ↓
required server pushes
  ↓
3011
  ↓
3017
```

We should not call the full client "working" until the actual client progresses through that boundary.

## Earliest useful client test

As soon as the mandatory push set has been established, use:

```text
real client
   ↓
ws://127.0.0.1:9000
   ↓
replacement server
```

and record every request/response until the first unimplemented opcode.

That first unimplemented opcode becomes the next handler.
