# Startup Push Trace, v0.7

## Scope

This trace is based on the extracted client bundle represented in
`/mnt/data/pb_inputs/protocol_search.txt` and the extracted protocol registry in
`protocol-data/pokemonburst_protocol_extracted/`. It distinguishes what the
client actually consumes from what is merely a registered message type.

## Proven boot gate

```text
3003 SERVER_LOAD_SUCCESS
        ↓
client sends 3004 CLIENT_LOAD_SUCCESS
        ↓
server-side push phase
        ↓
3011 SERVER_PUSH_FINISH
        ↓
_enterGame() gate passes after local resource/config flags
        ↓
RoleProxy.reqLangChange(window.defaultLanguage)
        ↓
client sends 3017 LANG_CHANGE
```

The relevant client code explicitly sends `3004` after `3003`, and its
`_onMsgServerPushFinish` handler sets `_isPushFinish=true`. The later
`_enterGame` branch calls `RoleProxy.reqLangChange(window.defaultLanguage)`.

## Packet-by-packet classification

| Opcode | Name | Client evidence | v0.7 classification |
|---:|---|---|---|
| 3010 | HOME_ICON_INFO | `MainPanelProxyCls` registers a handler that stores the icon list | **consumed, but not proven startup-mandatory** |
| 3011 | SERVER_PUSH_FINISH | `GameLaunch` listens for it and uses it as the push-complete gate | **proven startup gate** |
| 3012 | ENTRANCE_COUNTDOWN_LIST | `MainPanelProxyCls` registers a handler and updates countdown state | **consumed, but not proven startup-mandatory** |
| 3013 | ENTRANCE_COUNTDOWN_CHANGE | Same proxy handles incremental countdown changes | **runtime push/update** |
| 3014 | CONTROL_INFO | `GameLaunch._onNetConnectSucceed` registers a listener immediately after game-server connection | **game-login control response, not proven pre-3011** |
| 3015 | RES_CONTROL | Same connection setup registers a listener immediately after game-server connection | **game-login control response, not proven pre-3011** |
| 3016 | UC_UPLOAD_INFO | `RoleProxy` registers a handler; request method exists | **reusable role/account feature, not proven startup-mandatory** |
| 3017 | LANG_CHANGE | Sent by the client after `_isPushFinish` and local load flags pass | **post-gate client request/response** |
| 3018 | DIANHUN_IOS_CHARGE_WAY | Registry entry exists; no startup consumer found in this trace | **unproven / optional** |
| 3019 | SEND_ROLE_REG_TIMESTAMP | `ServerConnect` listens for it, and `RoleProxy` has both request + response handling | **reusable server-time/role metadata response** |
| 3020 | CLIENT_CONFIG_LIST | `ServerStoreCls` consumes it and dispatches `CLIENT_CONFIG_LIST` | **important config response, but ordering before 3011 is not proven** |
| 3021 | CLIENT_CONFIG_SET | Client sends it when role config values change | **client request, not startup push** |
| 3022 | CLIENT_CONFIG_SET_ACC | Client sends it when account config values change | **client request, not startup push** |

## Important discovery

`3014 CONTROL_INFO` and `3015 RES_CONTROL` are wired in
`GameLaunch._onNetConnectSucceed`, directly around the `3001 GAME_LOGIN` send.
That means their presence in the early login path is established, but their exact
relative ordering against `3011` is **not** established by the client snippet
alone. They should not be inserted before `3011` merely because their opcode
numbers are close.

Likewise, `3010` and `3012` are registered by `MainPanelProxyCls`, but the
handlers only update main-panel state. Registration proves they are consumed, not
that the server always sends them during the first push phase.

`3019` is especially clear: there is a dedicated `ServerConnect` listener that
updates the role creation timestamp, and `RoleProxy` exposes an explicit
`reqSendRoleRegTimestamp()` request. This makes it a normal request/response
feature rather than proof of a mandatory initial push.

## Protocol schemas extracted for these messages

```text
3010: s=[data_list: array<home_icon_element>]
3011: s=[]
3012: s=[data_list: array<home_entrance_countdown>]
3013: s=[data: home_entrance_countdown]
3014: s=[control_list: array<uint8>]
3015: s=[resource_type: int8]
3016: s=[result: uint16], c=[sys_platform:string, sys_info:string]
3017: s=[result:int16, lang:string], c=[lang:string]
3018: s=[charge_way:uint32]
3019: s=[role_reg_timestamp:uint32]
3020: s=[config_list: array<client_config>]
3021: s=[result:int16, config_list:array<client_config>], c=[config:array<client_config>]
3022: s=[result:int16], c=[config:array<client_config>]
```

## v0.7 implementation decision

The replacement server continues to emit only the **proven** `3011` gate after
`3004`. No speculative 3010/3012/3014/3015/3019/3020 push burst is added.
This preserves a falsifiable baseline: if the client reaches `3017` and the home
state is incomplete, each additional packet can be introduced one at a time and
observed.

## Next highest-value trace

The next target is not another opcode. It is the **server-side ordering evidence**:
inspect packet traffic or server code for the exact sequence between `3004` and
`3011`. Once that sequence is observed, the already-extracted schemas are enough
to implement it without guessing field layouts.
