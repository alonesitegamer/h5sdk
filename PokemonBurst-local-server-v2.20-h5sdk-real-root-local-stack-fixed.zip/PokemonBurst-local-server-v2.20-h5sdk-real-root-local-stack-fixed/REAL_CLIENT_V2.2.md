# v2.2 — Real client hook

Patch only a LOCAL copy of `assets/index.html`:

```bash
python3 tools/patch_index_server_config.py \
  /path/to/client/assets/index.html \
  /path/to/client-ryure/assets/index.html
```

It changes the known `SERVER_CONFIG` and the `30002` preview override to:

`ryure:30001`

Run server:

```bash
cd ~/pokemonburst-replacement-server-v2.2/server
npm install
npm test
npm run check:registry
npm run dev:local
```

Launch the patched local client. The server now logs both `[RAW]` WebSocket
chunks and decoded `[RX] opcode=...` messages.
