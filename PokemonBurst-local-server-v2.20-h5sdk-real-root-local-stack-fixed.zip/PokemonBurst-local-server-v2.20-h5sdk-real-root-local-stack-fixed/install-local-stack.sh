#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"

# Install and validate the replacement game server.
cd "$BASE_DIR/server"
npm install
npm run build

# Install both local HTTP virtual hosts. The old installer only installed
# pokemonburst-local.conf, which left h5sdk.camjm.space on nginx's default site.
sudo cp "$BASE_DIR/nginx/pokemonburst-local.conf" /etc/nginx/conf.d/pokemonburst-local.conf
sudo cp "$BASE_DIR/nginx/h5sdk-local.conf" /etc/nginx/conf.d/h5sdk-local.conf

sudo nginx -t
sudo systemctl daemon-reload
sudo systemctl enable --now pokemonburst-server
sudo systemctl enable --now pokemonburst-telemetry
sudo systemctl enable nginx
sudo systemctl reload nginx

echo "[stack] installed pokemonburst + h5sdk nginx hosts"
